return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -2.4, frequency = 70, Q = 0.82},
    {name = "eq", gain = -4.9, frequency = 185, Q = 0.51},
    {name = "eq", gain = 3.3, frequency = 873, Q = 0.79},
    {name = "eq", gain = 4.6, frequency = 6002, Q = 4.41},
    {name = "eq", gain = 6.7, frequency = 9147, Q = 2.15},
    {name = "eq", gain = 3.3, frequency = 4392, Q = 1.59},
    {name = "eq", gain = -6.5, frequency = 4508, Q = 4.87},
    {name = "eq", gain = 3.2, frequency = 11445, Q = 2.10},
    {name = "eq", gain = 2.3, frequency = 13521, Q = 1.49},
    {name = "eq", gain = -14.9, frequency = 19713, Q = 0.43},
}
