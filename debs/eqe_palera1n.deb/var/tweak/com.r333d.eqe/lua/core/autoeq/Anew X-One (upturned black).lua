return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.8, frequency = 32, Q = 0.44},
    {name = "eq", gain = -2.1, frequency = 852, Q = 0.07},
    {name = "eq", gain = 6.4, frequency = 3905, Q = 3.12},
    {name = "eq", gain = 5.6, frequency = 5597, Q = 2.48},
    {name = "eq", gain = 2.8, frequency = 10810, Q = 0.56},
    {name = "eq", gain = -0.9, frequency = 233, Q = 1.93},
    {name = "eq", gain = 1.4, frequency = 858, Q = 1.26},
    {name = "eq", gain = -1.1, frequency = 1545, Q = 1.34},
    {name = "eq", gain = 0.7, frequency = 19367, Q = 1.25},
}
