return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -1.8, frequency = 94, Q = 0.98},
    {name = "eq", gain = -5.2, frequency = 239, Q = 0.57},
    {name = "eq", gain = -2.6, frequency = 1442, Q = 2.60},
    {name = "eq", gain = 6.0, frequency = 5688, Q = 0.49},
    {name = "eq", gain = 4.1, frequency = 12778, Q = 1.39},
    {name = "eq", gain = 0.8, frequency = 19, Q = 1.35},
    {name = "eq", gain = 1.6, frequency = 2443, Q = 4.52},
    {name = "eq", gain = -2.9, frequency = 3228, Q = 3.73},
    {name = "eq", gain = 2.1, frequency = 3715, Q = 4.01},
    {name = "eq", gain = -0.3, frequency = 5868, Q = 3.24},
}
