return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 8.2, frequency = 38, Q = 0.46},
    {name = "eq", gain = -5.9, frequency = 81, Q = 0.83},
    {name = "eq", gain = 4.5, frequency = 1133, Q = 1.38},
    {name = "eq", gain = -5.0, frequency = 2360, Q = 0.52},
    {name = "eq", gain = 6.8, frequency = 3893, Q = 1.45},
    {name = "eq", gain = -0.6, frequency = 42, Q = 1.79},
    {name = "eq", gain = 1.1, frequency = 45, Q = 4.26},
    {name = "eq", gain = 0.3, frequency = 3729, Q = 1.46},
    {name = "eq", gain = 1.4, frequency = 7814, Q = 1.73},
    {name = "eq", gain = -1.1, frequency = 15746, Q = 0.19},
}
