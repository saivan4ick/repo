return {
    {name = "preamp", gain = -5.5},
    {name = "eq", gain = -4.6, frequency = 26, Q = 0.86},
    {name = "eq", gain = -2.0, frequency = 155, Q = 1.31},
    {name = "eq", gain = 6.2, frequency = 4364, Q = 3.38},
    {name = "eq", gain = -2.8, frequency = 5441, Q = 2.31},
    {name = "eq", gain = 2.6, frequency = 11359, Q = 1.17},
    {name = "eq", gain = -0.8, frequency = 44, Q = 3.17},
    {name = "eq", gain = 1.1, frequency = 65, Q = 3.75},
    {name = "eq", gain = 1.7, frequency = 2080, Q = 3.10},
    {name = "eq", gain = -1.5, frequency = 2400, Q = 1.08},
    {name = "eq", gain = 0.7, frequency = 3774, Q = 1.80},
}
