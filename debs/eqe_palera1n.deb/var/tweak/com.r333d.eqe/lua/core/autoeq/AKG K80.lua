return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 45, Q = 0.22},
    {name = "eq", gain = -8.5, frequency = 1729, Q = 1.75},
    {name = "eq", gain = -6.7, frequency = 3878, Q = 4.11},
    {name = "eq", gain = 4.3, frequency = 6017, Q = 3.17},
    {name = "eq", gain = 6.3, frequency = 18808, Q = 0.37},
    {name = "eq", gain = 1.2, frequency = 125, Q = 2.99},
    {name = "eq", gain = -1.0, frequency = 228, Q = 3.03},
    {name = "eq", gain = -1.6, frequency = 2127, Q = 4.88},
    {name = "eq", gain = 3.6, frequency = 2831, Q = 4.10},
    {name = "eq", gain = -1.9, frequency = 3296, Q = 4.17},
}
