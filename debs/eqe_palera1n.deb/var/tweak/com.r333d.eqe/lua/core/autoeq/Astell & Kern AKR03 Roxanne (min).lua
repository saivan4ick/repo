return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 4.1, frequency = 17, Q = 0.44},
    {name = "eq", gain = -0.8, frequency = 163, Q = 0.48},
    {name = "eq", gain = -6.1, frequency = 292, Q = 0.29},
    {name = "eq", gain = 7.2, frequency = 2949, Q = 0.62},
    {name = "eq", gain = 5.9, frequency = 10078, Q = 1.76},
    {name = "eq", gain = -1.8, frequency = 1383, Q = 4.05},
    {name = "eq", gain = 2.2, frequency = 1949, Q = 5.53},
    {name = "eq", gain = 1.6, frequency = 8112, Q = 4.66},
    {name = "eq", gain = 4.9, frequency = 13045, Q = 1.73},
    {name = "eq", gain = -15.5, frequency = 19875, Q = 0.49},
}
