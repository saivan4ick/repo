return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 5.6, frequency = 16, Q = 0.55},
    {name = "eq", gain = -2.5, frequency = 102, Q = 0.37},
    {name = "eq", gain = -8.1, frequency = 310, Q = 0.32},
    {name = "eq", gain = 4.3, frequency = 2026, Q = 1.20},
    {name = "eq", gain = 6.1, frequency = 14038, Q = 0.08},
    {name = "eq", gain = 0.5, frequency = 895, Q = 4.04},
    {name = "eq", gain = -2.0, frequency = 1365, Q = 2.30},
    {name = "eq", gain = 2.3, frequency = 1836, Q = 1.40},
    {name = "eq", gain = -1.9, frequency = 2204, Q = 2.77},
}
