return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 3.2, frequency = 29, Q = 0.32},
    {name = "eq", gain = -4.7, frequency = 263, Q = 0.33},
    {name = "eq", gain = -9.3, frequency = 2828, Q = 4.19},
    {name = "eq", gain = 7.2, frequency = 3777, Q = 0.78},
    {name = "eq", gain = 4.5, frequency = 9734, Q = 1.37},
    {name = "eq", gain = -3.4, frequency = 1268, Q = 3.37},
    {name = "eq", gain = 1.6, frequency = 1310, Q = 1.28},
    {name = "eq", gain = 1.3, frequency = 13442, Q = 1.69},
    {name = "eq", gain = -4.6, frequency = 19846, Q = 0.51},
}
