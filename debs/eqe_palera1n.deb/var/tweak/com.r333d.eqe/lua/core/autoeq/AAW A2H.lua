return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 5.5, frequency = 14, Q = 0.87},
    {name = "eq", gain = 5.0, frequency = 41, Q = 0.78},
    {name = "eq", gain = -3.8, frequency = 472, Q = 0.56},
    {name = "eq", gain = 6.1, frequency = 3228, Q = 1.42},
    {name = "eq", gain = 5.3, frequency = 18827, Q = 0.19},
    {name = "eq", gain = 0.2, frequency = 1568, Q = 1.31},
    {name = "eq", gain = -2.0, frequency = 5098, Q = 4.38},
    {name = "eq", gain = 3.7, frequency = 6397, Q = 4.22},
    {name = "eq", gain = -1.9, frequency = 7359, Q = 2.13},
    {name = "eq", gain = 0.5, frequency = 19906, Q = 3.69},
}
