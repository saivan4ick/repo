return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -2.8, frequency = 83, Q = 0.73},
    {name = "eq", gain = -6.6, frequency = 237, Q = 0.52},
    {name = "eq", gain = 5.1, frequency = 2131, Q = 0.70},
    {name = "eq", gain = 5.4, frequency = 8019, Q = 1.23},
    {name = "eq", gain = 5.2, frequency = 12632, Q = 2.03},
    {name = "eq", gain = 0.9, frequency = 2219, Q = 3.61},
    {name = "eq", gain = -2.1, frequency = 2951, Q = 3.33},
    {name = "eq", gain = 3.7, frequency = 3749, Q = 3.55},
    {name = "eq", gain = -4.0, frequency = 5011, Q = 2.80},
    {name = "eq", gain = 3.6, frequency = 5874, Q = 4.81},
}
