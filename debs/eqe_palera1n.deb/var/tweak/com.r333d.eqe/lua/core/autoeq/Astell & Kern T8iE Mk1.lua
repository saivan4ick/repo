return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -4.5, frequency = 38, Q = 0.25},
    {name = "eq", gain = -4.4, frequency = 178, Q = 0.63},
    {name = "eq", gain = 6.1, frequency = 3035, Q = 1.09},
    {name = "eq", gain = 3.8, frequency = 12780, Q = 0.74},
    {name = "eq", gain = 5.6, frequency = 19595, Q = 0.34},
    {name = "eq", gain = 1.7, frequency = 875, Q = 2.10},
    {name = "eq", gain = -0.9, frequency = 1477, Q = 2.54},
    {name = "eq", gain = 2.5, frequency = 4126, Q = 4.14},
    {name = "eq", gain = -3.7, frequency = 5008, Q = 2.50},
    {name = "eq", gain = 4.0, frequency = 5886, Q = 5.38},
}
