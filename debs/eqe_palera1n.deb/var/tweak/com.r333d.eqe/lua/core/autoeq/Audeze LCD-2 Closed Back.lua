return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 2.0, frequency = 21, Q = 0.86},
    {name = "eq", gain = -2.8, frequency = 159, Q = 1.09},
    {name = "eq", gain = 5.7, frequency = 3890, Q = 3.35},
    {name = "eq", gain = 4.8, frequency = 10754, Q = 1.86},
    {name = "eq", gain = -14.7, frequency = 19642, Q = 0.45},
    {name = "eq", gain = 1.5, frequency = 440, Q = 2.22},
    {name = "eq", gain = -2.0, frequency = 1559, Q = 1.33},
    {name = "eq", gain = 0.7, frequency = 2731, Q = 1.10},
    {name = "eq", gain = -6.1, frequency = 6084, Q = 3.94},
    {name = "eq", gain = 1.8, frequency = 6243, Q = 1.08},
}
