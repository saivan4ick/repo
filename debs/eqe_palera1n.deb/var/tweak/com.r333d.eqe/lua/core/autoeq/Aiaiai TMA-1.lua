return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = 7.9, frequency = 21, Q = 0.84},
    {name = "eq", gain = -4.4, frequency = 86, Q = 0.33},
    {name = "eq", gain = -4.3, frequency = 314, Q = 0.60},
    {name = "eq", gain = 7.1, frequency = 2646, Q = 1.19},
    {name = "eq", gain = 7.0, frequency = 11993, Q = 1.31},
    {name = "eq", gain = 2.9, frequency = 727, Q = 4.65},
    {name = "eq", gain = -2.6, frequency = 1043, Q = 3.39},
    {name = "eq", gain = 3.5, frequency = 4090, Q = 4.04},
    {name = "eq", gain = -4.5, frequency = 6330, Q = 2.11},
    {name = "eq", gain = 3.5, frequency = 8878, Q = 3.36},
}
