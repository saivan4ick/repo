return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 30, Q = 0.52},
    {name = "eq", gain = 2.5, frequency = 724, Q = 1.39},
    {name = "eq", gain = -3.5, frequency = 2272, Q = 1.65},
    {name = "eq", gain = 4.8, frequency = 3928, Q = 1.31},
    {name = "eq", gain = -7.2, frequency = 6104, Q = 1.70},
    {name = "eq", gain = -1.1, frequency = 201, Q = 2.17},
    {name = "eq", gain = 0.2, frequency = 4944, Q = 2.28},
    {name = "eq", gain = 1.2, frequency = 10695, Q = 2.79},
    {name = "eq", gain = 0.6, frequency = 13092, Q = 1.75},
    {name = "eq", gain = -5.5, frequency = 19892, Q = 0.39},
}
