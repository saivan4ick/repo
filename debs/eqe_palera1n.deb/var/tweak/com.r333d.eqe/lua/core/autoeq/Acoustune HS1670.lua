return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = -3.2, frequency = 146, Q = 1.08},
    {name = "eq", gain = -2.8, frequency = 2219, Q = 2.23},
    {name = "eq", gain = 6.1, frequency = 3734, Q = 2.60},
    {name = "eq", gain = 3.8, frequency = 9788, Q = 1.46},
    {name = "eq", gain = -10.7, frequency = 19374, Q = 0.48},
    {name = "eq", gain = 1.7, frequency = 22, Q = 1.35},
    {name = "eq", gain = 1.9, frequency = 542, Q = 1.91},
    {name = "eq", gain = 2.0, frequency = 4631, Q = 4.56},
    {name = "eq", gain = -4.2, frequency = 5706, Q = 3.76},
    {name = "eq", gain = 2.1, frequency = 6944, Q = 3.38},
}
