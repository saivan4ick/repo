return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 1.1, frequency = 21, Q = 2.71},
    {name = "eq", gain = -4.4, frequency = 539, Q = 1.17},
    {name = "eq", gain = -2.1, frequency = 1534, Q = 1.32},
    {name = "eq", gain = 2.7, frequency = 4329, Q = 2.38},
    {name = "eq", gain = 5.0, frequency = 8622, Q = 0.54},
    {name = "eq", gain = -0.9, frequency = 53, Q = 1.15},
    {name = "eq", gain = 1.2, frequency = 141, Q = 1.78},
    {name = "eq", gain = -1.6, frequency = 6312, Q = 3.35},
    {name = "eq", gain = 2.2, frequency = 9536, Q = 0.92},
    {name = "eq", gain = -3.1, frequency = 11139, Q = 2.17},
}
