return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = 1.6, frequency = 20, Q = 0.82},
    {name = "eq", gain = -6.1, frequency = 255, Q = 0.40},
    {name = "eq", gain = -10.3, frequency = 1633, Q = 0.78},
    {name = "eq", gain = 9.5, frequency = 2114, Q = 0.23},
    {name = "eq", gain = 1.4, frequency = 11906, Q = 2.22},
    {name = "eq", gain = 0.7, frequency = 786, Q = 3.63},
    {name = "eq", gain = -1.6, frequency = 1149, Q = 3.71},
    {name = "eq", gain = 1.0, frequency = 2069, Q = 0.76},
    {name = "eq", gain = -1.8, frequency = 2301, Q = 3.10},
    {name = "eq", gain = -1.0, frequency = 8196, Q = 4.77},
}
