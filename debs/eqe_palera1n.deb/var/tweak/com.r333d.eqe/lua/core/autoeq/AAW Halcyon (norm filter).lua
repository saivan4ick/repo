return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 2.2, frequency = 22, Q = 0.82},
    {name = "eq", gain = -5.3, frequency = 189, Q = 0.64},
    {name = "eq", gain = 6.3, frequency = 2897, Q = 2.08},
    {name = "eq", gain = 4.9, frequency = 4270, Q = 4.02},
    {name = "eq", gain = 2.9, frequency = 8684, Q = 3.28},
    {name = "eq", gain = 1.2, frequency = 846, Q = 1.74},
    {name = "eq", gain = -1.4, frequency = 1422, Q = 3.06},
    {name = "eq", gain = 1.1, frequency = 9221, Q = 1.14},
    {name = "eq", gain = 3.3, frequency = 11471, Q = 1.29},
    {name = "eq", gain = -15.5, frequency = 19722, Q = 0.36},
}
