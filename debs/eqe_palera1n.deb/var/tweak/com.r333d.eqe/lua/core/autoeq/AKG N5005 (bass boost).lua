return {
    {name = "preamp", gain = -5.7},
    {name = "eq", gain = -3.7, frequency = 22, Q = 0.28},
    {name = "eq", gain = -1.8, frequency = 814, Q = 0.10},
    {name = "eq", gain = 5.6, frequency = 3096, Q = 2.70},
    {name = "eq", gain = 5.9, frequency = 7122, Q = 0.86},
    {name = "eq", gain = 2.8, frequency = 22050, Q = 2.21},
    {name = "eq", gain = 1.6, frequency = 953, Q = 2.35},
    {name = "eq", gain = -1.5, frequency = 1698, Q = 2.46},
    {name = "eq", gain = -2.6, frequency = 7849, Q = 4.03},
    {name = "eq", gain = 1.3, frequency = 8621, Q = 0.96},
    {name = "eq", gain = -2.7, frequency = 19646, Q = 0.72},
}
