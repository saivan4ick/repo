return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 2.7, frequency = 21, Q = 1.54},
    {name = "eq", gain = -3.1, frequency = 133, Q = 0.82},
    {name = "eq", gain = -3.6, frequency = 2279, Q = 2.32},
    {name = "eq", gain = 6.1, frequency = 4088, Q = 4.20},
    {name = "eq", gain = 3.4, frequency = 9164, Q = 1.84},
    {name = "eq", gain = 1.7, frequency = 689, Q = 1.50},
    {name = "eq", gain = 1.3, frequency = 4719, Q = 4.06},
    {name = "eq", gain = 1.0, frequency = 4942, Q = 3.21},
    {name = "eq", gain = -4.2, frequency = 5764, Q = 2.52},
    {name = "eq", gain = 3.2, frequency = 6852, Q = 3.83},
}
