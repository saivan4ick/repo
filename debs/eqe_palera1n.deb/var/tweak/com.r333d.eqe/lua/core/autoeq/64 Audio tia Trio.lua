return {
    {name = "preamp", gain = -6.1},
    {name = "eq", gain = -3.1, frequency = 41, Q = 0.22},
    {name = "eq", gain = -2.2, frequency = 351, Q = 0.14},
    {name = "eq", gain = 6.0, frequency = 1104, Q = 1.69},
    {name = "eq", gain = 4.6, frequency = 3676, Q = 2.04},
    {name = "eq", gain = 5.3, frequency = 5771, Q = 3.58},
    {name = "eq", gain = 2.0, frequency = 420, Q = 1.26},
    {name = "eq", gain = -1.9, frequency = 615, Q = 0.63},
    {name = "eq", gain = 1.8, frequency = 897, Q = 3.48},
    {name = "eq", gain = 0.9, frequency = 1594, Q = 2.37},
}
