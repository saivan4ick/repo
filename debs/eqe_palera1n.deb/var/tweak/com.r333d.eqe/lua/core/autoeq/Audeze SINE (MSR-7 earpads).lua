return {
    {name = "preamp", gain = -5.2},
    {name = "eq", gain = 5.0, frequency = 19, Q = 0.33},
    {name = "eq", gain = -2.6, frequency = 184, Q = 1.11},
    {name = "eq", gain = 7.0, frequency = 5753, Q = 1.28},
    {name = "eq", gain = 7.5, frequency = 9786, Q = 0.87},
    {name = "eq", gain = -14.0, frequency = 19368, Q = 0.11},
    {name = "eq", gain = 1.8, frequency = 700, Q = 1.87},
    {name = "eq", gain = -1.2, frequency = 1222, Q = 2.59},
    {name = "eq", gain = -0.6, frequency = 2132, Q = 2.12},
    {name = "eq", gain = -1.7, frequency = 3121, Q = 2.01},
    {name = "eq", gain = -4.2, frequency = 19892, Q = 1.12},
}
