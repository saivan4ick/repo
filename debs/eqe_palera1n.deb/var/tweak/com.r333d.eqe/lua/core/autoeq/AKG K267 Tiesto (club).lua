return {
    {name = "preamp", gain = -6.1},
    {name = "eq", gain = -2.2, frequency = 197, Q = 1.42},
    {name = "eq", gain = 3.3, frequency = 334, Q = 4.25},
    {name = "eq", gain = -4.9, frequency = 1336, Q = 1.60},
    {name = "eq", gain = 4.7, frequency = 4099, Q = 5.23},
    {name = "eq", gain = 1.3, frequency = 5472, Q = 0.24},
    {name = "eq", gain = 1.8, frequency = 67, Q = 1.40},
    {name = "eq", gain = -1.3, frequency = 122, Q = 2.63},
    {name = "eq", gain = -3.4, frequency = 5336, Q = 5.57},
    {name = "eq", gain = 3.4, frequency = 6526, Q = 1.99},
    {name = "eq", gain = -2.2, frequency = 8491, Q = 1.74},
}
