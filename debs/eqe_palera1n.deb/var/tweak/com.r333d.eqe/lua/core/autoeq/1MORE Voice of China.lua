return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 5.5, frequency = 16, Q = 0.61},
    {name = "eq", gain = -5.1, frequency = 163, Q = 0.43},
    {name = "eq", gain = 3.5, frequency = 887, Q = 1.12},
    {name = "eq", gain = 3.1, frequency = 1907, Q = 3.10},
    {name = "eq", gain = 6.4, frequency = 13308, Q = 0.54},
    {name = "eq", gain = 1.2, frequency = 2417, Q = 2.59},
    {name = "eq", gain = -2.2, frequency = 3000, Q = 2.74},
    {name = "eq", gain = -5.7, frequency = 5199, Q = 3.30},
    {name = "eq", gain = 2.8, frequency = 6745, Q = 1.16},
    {name = "eq", gain = -1.2, frequency = 13537, Q = 2.15},
}
