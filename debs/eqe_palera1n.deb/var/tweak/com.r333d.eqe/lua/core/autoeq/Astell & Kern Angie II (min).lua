return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -4.0, frequency = 85, Q = 0.53},
    {name = "eq", gain = -6.3, frequency = 259, Q = 0.61},
    {name = "eq", gain = 6.4, frequency = 2256, Q = 0.86},
    {name = "eq", gain = 4.8, frequency = 4922, Q = 2.05},
    {name = "eq", gain = 1.0, frequency = 5466, Q = 0.89},
    {name = "eq", gain = 2.5, frequency = 9111, Q = 2.20},
    {name = "eq", gain = 1.8, frequency = 11279, Q = 1.67},
    {name = "eq", gain = -9.3, frequency = 19168, Q = 0.25},
    {name = "eq", gain = -9.1, frequency = 19555, Q = 0.52},
}
