return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -4.9, frequency = 209, Q = 0.46},
    {name = "eq", gain = 4.2, frequency = 752, Q = 1.90},
    {name = "eq", gain = 3.1, frequency = 1405, Q = 2.10},
    {name = "eq", gain = 4.7, frequency = 3242, Q = 2.97},
    {name = "eq", gain = 6.3, frequency = 11076, Q = 1.83},
    {name = "eq", gain = 2.0, frequency = 22, Q = 2.18},
    {name = "eq", gain = 2.1, frequency = 4447, Q = 2.72},
    {name = "eq", gain = -4.4, frequency = 5520, Q = 2.99},
    {name = "eq", gain = 0.4, frequency = 8946, Q = 3.33},
    {name = "eq", gain = 1.0, frequency = 9153, Q = 4.09},
}
