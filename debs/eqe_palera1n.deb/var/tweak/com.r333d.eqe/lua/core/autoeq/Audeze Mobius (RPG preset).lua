return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -3.3, frequency = 140, Q = 0.90},
    {name = "eq", gain = -2.8, frequency = 3086, Q = 3.10},
    {name = "eq", gain = -4.0, frequency = 3204, Q = 0.78},
    {name = "eq", gain = 5.7, frequency = 4351, Q = 1.55},
    {name = "eq", gain = 6.2, frequency = 6942, Q = 1.62},
    {name = "eq", gain = 1.4, frequency = 32, Q = 4.16},
    {name = "eq", gain = -2.5, frequency = 247, Q = 2.05},
    {name = "eq", gain = 3.0, frequency = 708, Q = 0.48},
    {name = "eq", gain = -3.0, frequency = 1244, Q = 1.10},
    {name = "eq", gain = -0.2, frequency = 3709, Q = 2.25},
}
