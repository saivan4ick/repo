return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -4.7, frequency = 236, Q = 0.60},
    {name = "eq", gain = 4.1, frequency = 2822, Q = 1.59},
    {name = "eq", gain = 3.9, frequency = 5877, Q = 1.81},
    {name = "eq", gain = 5.8, frequency = 16200, Q = 0.29},
    {name = "eq", gain = 5.2, frequency = 20717, Q = 1.08},
    {name = "eq", gain = 3.4, frequency = 22, Q = 1.22},
    {name = "eq", gain = 0.9, frequency = 1728, Q = 6.19},
    {name = "eq", gain = 1.3, frequency = 3531, Q = 4.49},
    {name = "eq", gain = -3.4, frequency = 4342, Q = 3.94},
    {name = "eq", gain = 3.1, frequency = 4755, Q = 6.17},
}
