return {
    {name = "preamp", gain = -5.8},
    {name = "eq", gain = -2.9, frequency = 221, Q = 0.41},
    {name = "eq", gain = 4.2, frequency = 930, Q = 0.82},
    {name = "eq", gain = 4.6, frequency = 2077, Q = 2.28},
    {name = "eq", gain = -4.8, frequency = 5770, Q = 4.57},
    {name = "eq", gain = -16.8, frequency = 19274, Q = 0.49},
    {name = "eq", gain = 1.8, frequency = 2653, Q = 4.39},
    {name = "eq", gain = -3.0, frequency = 3456, Q = 2.50},
    {name = "eq", gain = 2.5, frequency = 4214, Q = 4.52},
    {name = "eq", gain = 1.9, frequency = 10797, Q = 2.91},
    {name = "eq", gain = -0.9, frequency = 16090, Q = 2.48},
}
