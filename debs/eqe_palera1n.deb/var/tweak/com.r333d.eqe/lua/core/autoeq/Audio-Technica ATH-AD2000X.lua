return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 7.2, frequency = 29, Q = 0.34},
    {name = "eq", gain = -3.5, frequency = 504, Q = 0.08},
    {name = "eq", gain = 8.4, frequency = 2473, Q = 2.29},
    {name = "eq", gain = 6.5, frequency = 6394, Q = 0.91},
    {name = "eq", gain = 3.8, frequency = 22050, Q = 2.10},
    {name = "eq", gain = 1.0, frequency = 418, Q = 1.98},
    {name = "eq", gain = -1.4, frequency = 1095, Q = 3.03},
    {name = "eq", gain = 2.3, frequency = 3099, Q = 4.20},
    {name = "eq", gain = -3.5, frequency = 3821, Q = 3.27},
    {name = "eq", gain = 2.9, frequency = 4953, Q = 5.14},
}
