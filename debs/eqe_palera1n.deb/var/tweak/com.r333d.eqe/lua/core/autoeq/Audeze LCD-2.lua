return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 3.0, frequency = 18, Q = 0.27},
    {name = "eq", gain = -2.6, frequency = 281, Q = 0.35},
    {name = "eq", gain = 6.2, frequency = 4099, Q = 3.43},
    {name = "eq", gain = 2.5, frequency = 7460, Q = 3.95},
    {name = "eq", gain = 2.3, frequency = 9323, Q = 3.76},
    {name = "eq", gain = 1.5, frequency = 394, Q = 2.70},
    {name = "eq", gain = -0.7, frequency = 877, Q = 0.27},
    {name = "eq", gain = 3.1, frequency = 2007, Q = 3.45},
    {name = "eq", gain = 3.4, frequency = 11368, Q = 1.13},
    {name = "eq", gain = -12.7, frequency = 19808, Q = 0.35},
}
