return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.0, frequency = 21, Q = 0.76},
    {name = "eq", gain = -4.0, frequency = 159, Q = 1.65},
    {name = "eq", gain = 3.4, frequency = 3711, Q = 2.76},
    {name = "eq", gain = 4.1, frequency = 9656, Q = 1.39},
    {name = "eq", gain = -11.7, frequency = 19605, Q = 0.45},
    {name = "eq", gain = 2.6, frequency = 473, Q = 1.97},
    {name = "eq", gain = -2.0, frequency = 2383, Q = 0.40},
    {name = "eq", gain = 2.3, frequency = 2943, Q = 3.45},
    {name = "eq", gain = 4.1, frequency = 5428, Q = 1.70},
    {name = "eq", gain = -7.2, frequency = 5687, Q = 6.74},
}
