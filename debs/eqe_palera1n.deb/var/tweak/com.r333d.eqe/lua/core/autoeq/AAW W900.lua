return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 1.8, frequency = 19, Q = 0.42},
    {name = "eq", gain = -3.7, frequency = 224, Q = 0.32},
    {name = "eq", gain = -2.8, frequency = 1065, Q = 1.27},
    {name = "eq", gain = -1.7, frequency = 1950, Q = 4.35},
    {name = "eq", gain = 7.1, frequency = 4855, Q = 0.80},
    {name = "eq", gain = 0.1, frequency = 422, Q = 3.02},
    {name = "eq", gain = 0.6, frequency = 2739, Q = 3.96},
    {name = "eq", gain = 4.8, frequency = 9307, Q = 1.30},
    {name = "eq", gain = -16.1, frequency = 19623, Q = 0.35},
}
