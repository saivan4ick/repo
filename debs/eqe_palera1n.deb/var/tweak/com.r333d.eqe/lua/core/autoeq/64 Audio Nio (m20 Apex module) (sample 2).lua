return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -5.5, frequency = 45, Q = 0.17},
    {name = "eq", gain = -1.8, frequency = 1745, Q = 2.80},
    {name = "eq", gain = 5.6, frequency = 3315, Q = 1.84},
    {name = "eq", gain = 3.8, frequency = 6040, Q = 3.48},
    {name = "eq", gain = 5.7, frequency = 10034, Q = 1.84},
    {name = "eq", gain = 1.1, frequency = 905, Q = 1.65},
    {name = "eq", gain = -0.9, frequency = 1366, Q = 3.94},
    {name = "eq", gain = -0.8, frequency = 5083, Q = 8.23},
    {name = "eq", gain = 2.1, frequency = 13142, Q = 1.51},
    {name = "eq", gain = -8.0, frequency = 19702, Q = 0.53},
}
