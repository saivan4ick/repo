return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -3.9, frequency = 106, Q = 0.75},
    {name = "eq", gain = -3.4, frequency = 234, Q = 1.22},
    {name = "eq", gain = 4.8, frequency = 2180, Q = 3.79},
    {name = "eq", gain = 4.6, frequency = 2879, Q = 2.97},
    {name = "eq", gain = 3.1, frequency = 4667, Q = 1.44},
    {name = "eq", gain = 1.1, frequency = 19, Q = 1.60},
    {name = "eq", gain = 1.7, frequency = 811, Q = 2.07},
    {name = "eq", gain = -2.9, frequency = 1373, Q = 3.94},
    {name = "eq", gain = -1.3, frequency = 5699, Q = 7.29},
    {name = "eq", gain = 1.2, frequency = 9445, Q = 2.83},
}
