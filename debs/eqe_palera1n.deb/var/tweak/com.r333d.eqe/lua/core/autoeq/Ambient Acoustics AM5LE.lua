return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = -4.1, frequency = 94, Q = 0.50},
    {name = "eq", gain = -3.7, frequency = 234, Q = 1.15},
    {name = "eq", gain = 5.7, frequency = 2958, Q = 1.50},
    {name = "eq", gain = 5.0, frequency = 5069, Q = 2.88},
    {name = "eq", gain = 7.1, frequency = 18901, Q = 1.06},
    {name = "eq", gain = -0.9, frequency = 406, Q = 2.63},
    {name = "eq", gain = 3.0, frequency = 919, Q = 2.38},
    {name = "eq", gain = 3.0, frequency = 6633, Q = 3.27},
    {name = "eq", gain = -3.1, frequency = 9027, Q = 1.13},
    {name = "eq", gain = 1.6, frequency = 16357, Q = 2.03},
}
