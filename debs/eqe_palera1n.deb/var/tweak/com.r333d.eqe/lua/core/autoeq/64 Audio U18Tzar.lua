return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -4.8, frequency = 167, Q = 0.43},
    {name = "eq", gain = 1.2, frequency = 822, Q = 2.12},
    {name = "eq", gain = 3.7, frequency = 3496, Q = 1.08},
    {name = "eq", gain = 2.8, frequency = 4482, Q = 2.56},
    {name = "eq", gain = 6.4, frequency = 9530, Q = 2.32},
    {name = "eq", gain = 1.5, frequency = 18, Q = 1.79},
    {name = "eq", gain = 1.7, frequency = 7848, Q = 3.69},
    {name = "eq", gain = 2.8, frequency = 11416, Q = 3.18},
    {name = "eq", gain = 3.3, frequency = 13361, Q = 1.63},
    {name = "eq", gain = -15.7, frequency = 19643, Q = 0.43},
}
