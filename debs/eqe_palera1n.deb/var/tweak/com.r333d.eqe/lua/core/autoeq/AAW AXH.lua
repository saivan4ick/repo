return {
    {name = "preamp", gain = -7.5},
    {name = "eq", gain = 2.6, frequency = 25, Q = 0.51},
    {name = "eq", gain = -2.0, frequency = 313, Q = 0.60},
    {name = "eq", gain = -0.3, frequency = 578, Q = 1.98},
    {name = "eq", gain = 7.9, frequency = 3391, Q = 2.08},
    {name = "eq", gain = -12.4, frequency = 20264, Q = 0.14},
    {name = "eq", gain = -1.2, frequency = 1337, Q = 3.74},
    {name = "eq", gain = 0.9, frequency = 1827, Q = 2.29},
    {name = "eq", gain = 2.0, frequency = 4194, Q = 6.80},
    {name = "eq", gain = -6.2, frequency = 6669, Q = 3.72},
    {name = "eq", gain = 2.0, frequency = 10954, Q = 1.33},
}
