return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -10.5, frequency = 13, Q = 0.30},
    {name = "eq", gain = -11.8, frequency = 142, Q = 0.26},
    {name = "eq", gain = 6.7, frequency = 2218, Q = 0.47},
    {name = "eq", gain = 3.6, frequency = 6654, Q = 1.32},
    {name = "eq", gain = 4.5, frequency = 10130, Q = 2.57},
    {name = "eq", gain = -1.1, frequency = 258, Q = 2.02},
    {name = "eq", gain = 0.4, frequency = 415, Q = 0.28},
    {name = "eq", gain = -1.0, frequency = 1259, Q = 3.60},
    {name = "eq", gain = 0.8, frequency = 4753, Q = 3.11},
    {name = "eq", gain = -0.5, frequency = 5382, Q = 2.01},
}
