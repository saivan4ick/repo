return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 5.0, frequency = 30, Q = 0.47},
    {name = "eq", gain = -15.4, frequency = 1003, Q = 0.43},
    {name = "eq", gain = -7.9, frequency = 1468, Q = 2.28},
    {name = "eq", gain = 15.3, frequency = 2195, Q = 0.29},
    {name = "eq", gain = -7.8, frequency = 11254, Q = 0.79},
    {name = "eq", gain = 0.7, frequency = 537, Q = 2.33},
    {name = "eq", gain = 1.9, frequency = 2363, Q = 3.23},
    {name = "eq", gain = -0.5, frequency = 2833, Q = 1.54},
    {name = "eq", gain = -0.8, frequency = 4192, Q = 0.57},
    {name = "eq", gain = 2.3, frequency = 5843, Q = 3.29},
}
