return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -5.9, frequency = 205, Q = 0.52},
    {name = "eq", gain = 1.7, frequency = 961, Q = 1.90},
    {name = "eq", gain = 4.0, frequency = 2322, Q = 1.68},
    {name = "eq", gain = 4.3, frequency = 3427, Q = 2.23},
    {name = "eq", gain = 4.3, frequency = 6021, Q = 1.78},
    {name = "eq", gain = 2.6, frequency = 21, Q = 1.39},
    {name = "eq", gain = -2.4, frequency = 7270, Q = 5.73},
    {name = "eq", gain = 1.5, frequency = 9828, Q = 3.13},
    {name = "eq", gain = 4.4, frequency = 11089, Q = 0.97},
    {name = "eq", gain = -14.1, frequency = 19664, Q = 0.36},
}
