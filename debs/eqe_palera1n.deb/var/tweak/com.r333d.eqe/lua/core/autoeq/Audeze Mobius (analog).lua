return {
    {name = "preamp", gain = -7.5},
    {name = "eq", gain = -5.1, frequency = 42, Q = 1.04},
    {name = "eq", gain = -4.1, frequency = 122, Q = 1.29},
    {name = "eq", gain = -3.9, frequency = 228, Q = 2.24},
    {name = "eq", gain = 7.2, frequency = 6785, Q = 1.52},
    {name = "eq", gain = 2.3, frequency = 1522, Q = 2.24},
    {name = "eq", gain = -4.5, frequency = 3320, Q = 2.37},
    {name = "eq", gain = 4.2, frequency = 4755, Q = 4.41},
    {name = "eq", gain = 3.1, frequency = 10289, Q = 1.78},
    {name = "eq", gain = -10.8, frequency = 19649, Q = 0.45},
}
