return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = 3.0, frequency = 20, Q = 1.02},
    {name = "eq", gain = -4.5, frequency = 224, Q = 0.77},
    {name = "eq", gain = 3.0, frequency = 1195, Q = 0.61},
    {name = "eq", gain = -6.1, frequency = 2270, Q = 2.24},
    {name = "eq", gain = 6.9, frequency = 3715, Q = 3.51},
    {name = "eq", gain = 1.8, frequency = 908, Q = 1.38},
    {name = "eq", gain = -3.0, frequency = 942, Q = 2.88},
    {name = "eq", gain = 1.0, frequency = 4352, Q = 4.85},
    {name = "eq", gain = -3.4, frequency = 5517, Q = 5.96},
    {name = "eq", gain = 2.2, frequency = 9961, Q = 4.01},
}
