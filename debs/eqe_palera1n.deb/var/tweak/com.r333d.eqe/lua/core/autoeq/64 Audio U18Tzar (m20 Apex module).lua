return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = -5.0, frequency = 160, Q = 0.44},
    {name = "eq", gain = 1.5, frequency = 815, Q = 2.14},
    {name = "eq", gain = 5.9, frequency = 4009, Q = 1.02},
    {name = "eq", gain = 3.5, frequency = 9276, Q = 2.63},
    {name = "eq", gain = 2.1, frequency = 22050, Q = 2.59},
    {name = "eq", gain = 1.7, frequency = 19, Q = 1.81},
    {name = "eq", gain = -1.5, frequency = 2458, Q = 1.82},
    {name = "eq", gain = 3.0, frequency = 2677, Q = 4.76},
    {name = "eq", gain = 3.0, frequency = 11919, Q = 0.95},
    {name = "eq", gain = -11.5, frequency = 19785, Q = 0.38},
}
