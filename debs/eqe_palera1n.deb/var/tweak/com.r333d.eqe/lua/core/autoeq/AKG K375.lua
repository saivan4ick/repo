return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -6.1, frequency = 182, Q = 0.47},
    {name = "eq", gain = 5.5, frequency = 1607, Q = 0.75},
    {name = "eq", gain = 4.9, frequency = 4455, Q = 2.91},
    {name = "eq", gain = -7.7, frequency = 6277, Q = 2.41},
    {name = "eq", gain = 7.1, frequency = 11101, Q = 1.14},
    {name = "eq", gain = 2.5, frequency = 21, Q = 1.71},
    {name = "eq", gain = 1.4, frequency = 2157, Q = 5.00},
    {name = "eq", gain = -1.6, frequency = 2861, Q = 5.22},
    {name = "eq", gain = 2.0, frequency = 14463, Q = 1.99},
    {name = "eq", gain = -6.7, frequency = 19851, Q = 0.73},
}
