return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -7.1, frequency = 147, Q = 0.80},
    {name = "eq", gain = 12.2, frequency = 355, Q = 0.79},
    {name = "eq", gain = -10.4, frequency = 1258, Q = 0.47},
    {name = "eq", gain = 9.5, frequency = 3644, Q = 1.07},
    {name = "eq", gain = -6.0, frequency = 6564, Q = 3.95},
    {name = "eq", gain = 1.7, frequency = 467, Q = 7.44},
    {name = "eq", gain = -1.2, frequency = 634, Q = 4.56},
    {name = "eq", gain = -2.5, frequency = 1919, Q = 3.01},
    {name = "eq", gain = 1.8, frequency = 2305, Q = 1.22},
    {name = "eq", gain = -1.9, frequency = 3286, Q = 5.67},
}
