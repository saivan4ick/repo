return {
    {name = "preamp", gain = -4.3},
    {name = "eq", gain = -5.4, frequency = 14, Q = 0.48},
    {name = "eq", gain = -5.3, frequency = 80, Q = 0.29},
    {name = "eq", gain = 4.9, frequency = 772, Q = 0.59},
    {name = "eq", gain = -4.2, frequency = 1856, Q = 2.27},
    {name = "eq", gain = 2.3, frequency = 4636, Q = 2.50},
    {name = "eq", gain = -1.1, frequency = 2302, Q = 4.75},
    {name = "eq", gain = 1.9, frequency = 2854, Q = 2.97},
    {name = "eq", gain = 2.6, frequency = 5850, Q = 4.26},
    {name = "eq", gain = -2.6, frequency = 18363, Q = 0.13},
    {name = "eq", gain = -0.8, frequency = 19381, Q = 0.44},
}
