return {
    {name = "preamp", gain = -5.5},
    {name = "eq", gain = 5.8, frequency = 14, Q = 0.42},
    {name = "eq", gain = -2.4, frequency = 202, Q = 0.46},
    {name = "eq", gain = 5.0, frequency = 3398, Q = 2.76},
    {name = "eq", gain = 3.5, frequency = 6158, Q = 3.19},
    {name = "eq", gain = 3.9, frequency = 9925, Q = 2.89},
    {name = "eq", gain = -2.2, frequency = 1621, Q = 2.54},
    {name = "eq", gain = 1.2, frequency = 2719, Q = 4.99},
    {name = "eq", gain = 1.3, frequency = 12183, Q = 0.69},
    {name = "eq", gain = 1.7, frequency = 12452, Q = 2.14},
    {name = "eq", gain = -10.5, frequency = 19802, Q = 0.42},
}
