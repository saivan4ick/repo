return {
    {name = "preamp", gain = -4.1},
    {name = "eq", gain = -3.0, frequency = 29, Q = 0.30},
    {name = "eq", gain = -1.2, frequency = 312, Q = 1.36},
    {name = "eq", gain = 3.1, frequency = 3258, Q = 3.53},
    {name = "eq", gain = 3.3, frequency = 6123, Q = 4.17},
    {name = "eq", gain = 2.9, frequency = 9401, Q = 2.88},
    {name = "eq", gain = 1.7, frequency = 1004, Q = 2.29},
    {name = "eq", gain = 0.1, frequency = 1417, Q = 1.83},
    {name = "eq", gain = -1.4, frequency = 1494, Q = 1.17},
    {name = "eq", gain = 1.7, frequency = 4449, Q = 1.90},
    {name = "eq", gain = -3.8, frequency = 4728, Q = 5.74},
}
