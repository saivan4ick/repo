return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -2.5, frequency = 228, Q = 1.23},
    {name = "eq", gain = -5.5, frequency = 1083, Q = 0.70},
    {name = "eq", gain = 5.0, frequency = 1986, Q = 1.40},
    {name = "eq", gain = 6.2, frequency = 3934, Q = 2.63},
    {name = "eq", gain = 5.3, frequency = 8737, Q = 2.00},
    {name = "eq", gain = 1.9, frequency = 27, Q = 0.71},
    {name = "eq", gain = 0.3, frequency = 4414, Q = 3.31},
    {name = "eq", gain = 3.0, frequency = 11644, Q = 1.55},
    {name = "eq", gain = 2.3, frequency = 12183, Q = 0.72},
    {name = "eq", gain = -16.2, frequency = 19726, Q = 0.36},
}
