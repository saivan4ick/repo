return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 3.3, frequency = 20, Q = 0.75},
    {name = "eq", gain = 5.4, frequency = 3423, Q = 0.88},
    {name = "eq", gain = -5.6, frequency = 5796, Q = 0.02},
    {name = "eq", gain = 9.2, frequency = 6448, Q = 0.89},
    {name = "eq", gain = 5.0, frequency = 10801, Q = 1.52},
    {name = "eq", gain = 1.4, frequency = 89, Q = 0.85},
    {name = "eq", gain = 3.5, frequency = 565, Q = 0.48},
    {name = "eq", gain = -3.7, frequency = 1469, Q = 1.45},
    {name = "eq", gain = 1.8, frequency = 2162, Q = 2.69},
    {name = "eq", gain = -1.5, frequency = 3528, Q = 4.13},
}
