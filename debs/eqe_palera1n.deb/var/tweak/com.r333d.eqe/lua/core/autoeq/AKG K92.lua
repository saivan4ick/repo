return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -7.7, frequency = 27, Q = 0.87},
    {name = "eq", gain = -10.7, frequency = 168, Q = 1.18},
    {name = "eq", gain = -4.7, frequency = 511, Q = 2.25},
    {name = "eq", gain = 6.9, frequency = 1917, Q = 0.69},
    {name = "eq", gain = -7.2, frequency = 6390, Q = 4.27},
    {name = "eq", gain = 4.8, frequency = 80, Q = 4.85},
    {name = "eq", gain = -2.9, frequency = 123, Q = 4.78},
    {name = "eq", gain = 2.2, frequency = 3218, Q = 4.54},
    {name = "eq", gain = -4.4, frequency = 4394, Q = 5.00},
    {name = "eq", gain = 4.5, frequency = 11066, Q = 1.76},
}
