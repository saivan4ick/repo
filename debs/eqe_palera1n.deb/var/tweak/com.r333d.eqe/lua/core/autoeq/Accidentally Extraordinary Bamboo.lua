return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = 6.5, frequency = 26, Q = 0.88},
    {name = "eq", gain = -6.6, frequency = 195, Q = 0.82},
    {name = "eq", gain = 6.9, frequency = 3844, Q = 1.73},
    {name = "eq", gain = -6.0, frequency = 6457, Q = 4.79},
    {name = "eq", gain = 4.1, frequency = 10426, Q = 1.78},
    {name = "eq", gain = -1.7, frequency = 368, Q = 1.81},
    {name = "eq", gain = 4.5, frequency = 901, Q = 1.37},
    {name = "eq", gain = -3.4, frequency = 1899, Q = 1.59},
    {name = "eq", gain = 2.3, frequency = 2936, Q = 4.10},
}
