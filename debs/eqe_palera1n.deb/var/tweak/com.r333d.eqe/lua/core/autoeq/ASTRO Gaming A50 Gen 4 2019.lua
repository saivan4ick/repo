return {
    {name = "preamp", gain = -4.8},
    {name = "eq", gain = 4.7, frequency = 22, Q = 1.11},
    {name = "eq", gain = -3.4, frequency = 124, Q = 0.69},
    {name = "eq", gain = 3.3, frequency = 676, Q = 2.03},
    {name = "eq", gain = 5.0, frequency = 5385, Q = 1.37},
    {name = "eq", gain = -11.8, frequency = 5936, Q = 4.35},
    {name = "eq", gain = 1.6, frequency = 365, Q = 4.46},
    {name = "eq", gain = 2.9, frequency = 820, Q = 5.09},
    {name = "eq", gain = -3.3, frequency = 1161, Q = 1.46},
    {name = "eq", gain = 3.5, frequency = 1848, Q = 1.80},
    {name = "eq", gain = -2.5, frequency = 3203, Q = 4.46},
}
