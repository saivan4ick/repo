return {
    {name = "preamp", gain = -4.5},
    {name = "eq", gain = -5.4, frequency = 17, Q = 0.57},
    {name = "eq", gain = -5.0, frequency = 84, Q = 0.35},
    {name = "eq", gain = 5.2, frequency = 831, Q = 0.62},
    {name = "eq", gain = -5.2, frequency = 2008, Q = 1.42},
    {name = "eq", gain = 2.5, frequency = 3024, Q = 1.37},
    {name = "eq", gain = 1.8, frequency = 5528, Q = 2.59},
    {name = "eq", gain = 1.1, frequency = 5982, Q = 3.87},
    {name = "eq", gain = -1.8, frequency = 7027, Q = 2.06},
    {name = "eq", gain = -2.2, frequency = 19723, Q = 0.15},
}
