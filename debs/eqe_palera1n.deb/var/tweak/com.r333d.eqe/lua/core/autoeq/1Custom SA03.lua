return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -3.4, frequency = 111, Q = 0.74},
    {name = "eq", gain = -4.5, frequency = 265, Q = 0.89},
    {name = "eq", gain = 5.6, frequency = 2327, Q = 1.00},
    {name = "eq", gain = 3.5, frequency = 3752, Q = 2.35},
    {name = "eq", gain = -5.6, frequency = 20121, Q = 0.28},
    {name = "eq", gain = 1.2, frequency = 15, Q = 1.49},
    {name = "eq", gain = 1.4, frequency = 904, Q = 4.08},
    {name = "eq", gain = -5.2, frequency = 6435, Q = 5.79},
    {name = "eq", gain = 2.6, frequency = 6909, Q = 1.39},
    {name = "eq", gain = -2.9, frequency = 7873, Q = 3.59},
}
