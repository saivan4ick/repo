return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 6.4, frequency = 23, Q = 1.20},
    {name = "eq", gain = -3.7, frequency = 160, Q = 1.14},
    {name = "eq", gain = 4.6, frequency = 2078, Q = 2.89},
    {name = "eq", gain = 2.8, frequency = 10115, Q = 1.36},
    {name = "eq", gain = 3.2, frequency = 16602, Q = 0.55},
    {name = "eq", gain = 1.5, frequency = 360, Q = 3.30},
    {name = "eq", gain = -3.7, frequency = 1037, Q = 1.74},
    {name = "eq", gain = 1.8, frequency = 1434, Q = 1.22},
    {name = "eq", gain = -3.4, frequency = 5094, Q = 2.73},
    {name = "eq", gain = 3.0, frequency = 6735, Q = 4.38},
}
