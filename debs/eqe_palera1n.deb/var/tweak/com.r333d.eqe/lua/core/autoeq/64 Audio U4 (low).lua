return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -21.9, frequency = 15, Q = 0.21},
    {name = "eq", gain = -21.6, frequency = 183, Q = 0.15},
    {name = "eq", gain = 6.7, frequency = 434, Q = 0.02},
    {name = "eq", gain = 7.3, frequency = 1523, Q = 0.59},
    {name = "eq", gain = 4.0, frequency = 15241, Q = 1.08},
    {name = "eq", gain = 0.1, frequency = 50, Q = 0.03},
    {name = "eq", gain = -0.3, frequency = 4201, Q = 2.00},
    {name = "eq", gain = 0.8, frequency = 5533, Q = 1.42},
    {name = "eq", gain = -1.6, frequency = 5945, Q = 4.99},
    {name = "eq", gain = 0.5, frequency = 10492, Q = 2.08},
}
