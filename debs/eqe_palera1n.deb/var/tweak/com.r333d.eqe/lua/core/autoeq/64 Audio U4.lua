return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -5.3, frequency = 110, Q = 0.29},
    {name = "eq", gain = 5.1, frequency = 2095, Q = 1.98},
    {name = "eq", gain = 4.6, frequency = 4029, Q = 1.80},
    {name = "eq", gain = 3.8, frequency = 11252, Q = 1.12},
    {name = "eq", gain = 4.0, frequency = 16639, Q = 0.42},
    {name = "eq", gain = -0.6, frequency = 711, Q = 0.46},
    {name = "eq", gain = 1.5, frequency = 816, Q = 1.50},
    {name = "eq", gain = 2.7, frequency = 6478, Q = 6.21},
    {name = "eq", gain = -1.7, frequency = 7146, Q = 2.89},
    {name = "eq", gain = 0.7, frequency = 9600, Q = 5.04},
}
