return {
    {name = "preamp", gain = -6.1},
    {name = "eq", gain = -2.9, frequency = 103, Q = 2.99},
    {name = "eq", gain = -2.5, frequency = 1445, Q = 1.36},
    {name = "eq", gain = -7.6, frequency = 5163, Q = 1.26},
    {name = "eq", gain = 10.7, frequency = 7863, Q = 1.20},
    {name = "eq", gain = -14.5, frequency = 19559, Q = 0.35},
    {name = "eq", gain = 1.4, frequency = 41, Q = 1.47},
    {name = "eq", gain = 2.5, frequency = 328, Q = 1.64},
    {name = "eq", gain = -1.2, frequency = 3246, Q = 3.22},
    {name = "eq", gain = 2.2, frequency = 4271, Q = 3.71},
    {name = "eq", gain = -2.3, frequency = 4791, Q = 7.00},
}
