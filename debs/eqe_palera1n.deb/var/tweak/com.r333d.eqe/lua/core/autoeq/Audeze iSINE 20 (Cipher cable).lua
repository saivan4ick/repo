return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = -2.7, frequency = 64, Q = 0.55},
    {name = "eq", gain = -3.2, frequency = 1734, Q = 1.34},
    {name = "eq", gain = 1.6, frequency = 6072, Q = 1.81},
    {name = "eq", gain = 4.5, frequency = 6911, Q = 1.18},
    {name = "eq", gain = 2.4, frequency = 22050, Q = 2.50},
    {name = "eq", gain = -0.4, frequency = 31, Q = 3.84},
    {name = "eq", gain = -1.6, frequency = 2605, Q = 4.40},
    {name = "eq", gain = 0.8, frequency = 2827, Q = 1.02},
    {name = "eq", gain = 2.2, frequency = 10868, Q = 0.65},
    {name = "eq", gain = -2.5, frequency = 18012, Q = 0.14},
}
