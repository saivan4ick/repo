return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 4.2, frequency = 19, Q = 0.68},
    {name = "eq", gain = -5.5, frequency = 204, Q = 0.49},
    {name = "eq", gain = 6.2, frequency = 3511, Q = 1.28},
    {name = "eq", gain = 4.3, frequency = 11430, Q = 0.73},
    {name = "eq", gain = 5.7, frequency = 19267, Q = 0.37},
    {name = "eq", gain = 1.9, frequency = 959, Q = 2.12},
    {name = "eq", gain = -2.0, frequency = 1679, Q = 1.18},
    {name = "eq", gain = 1.7, frequency = 2462, Q = 2.45},
    {name = "eq", gain = 2.7, frequency = 6080, Q = 5.95},
    {name = "eq", gain = -2.3, frequency = 6671, Q = 4.94},
}
