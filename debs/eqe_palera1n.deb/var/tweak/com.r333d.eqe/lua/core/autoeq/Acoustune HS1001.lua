return {
    {name = "preamp", gain = -5.4},
    {name = "eq", gain = -5.4, frequency = 15, Q = 0.32},
    {name = "eq", gain = -6.6, frequency = 129, Q = 0.35},
    {name = "eq", gain = 5.4, frequency = 884, Q = 0.82},
    {name = "eq", gain = 3.8, frequency = 2303, Q = 1.77},
    {name = "eq", gain = 3.8, frequency = 3900, Q = 3.88},
    {name = "eq", gain = 0.2, frequency = 3772, Q = 0.96},
    {name = "eq", gain = 2.4, frequency = 4776, Q = 4.17},
    {name = "eq", gain = -5.6, frequency = 5792, Q = 3.64},
    {name = "eq", gain = 1.9, frequency = 10665, Q = 1.90},
}
