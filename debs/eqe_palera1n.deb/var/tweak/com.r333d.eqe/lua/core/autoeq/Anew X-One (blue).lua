return {
    {name = "preamp", gain = -4.2},
    {name = "eq", gain = -5.2, frequency = 17, Q = 0.57},
    {name = "eq", gain = -5.2, frequency = 83, Q = 0.32},
    {name = "eq", gain = 4.9, frequency = 820, Q = 0.63},
    {name = "eq", gain = -5.5, frequency = 2034, Q = 1.46},
    {name = "eq", gain = 3.6, frequency = 3217, Q = 1.32},
    {name = "eq", gain = 0.2, frequency = 2857, Q = 3.82},
    {name = "eq", gain = 2.4, frequency = 5707, Q = 3.07},
    {name = "eq", gain = -1.6, frequency = 7052, Q = 1.78},
    {name = "eq", gain = -2.6, frequency = 19204, Q = 0.30},
}
