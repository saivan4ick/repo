return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -3.9, frequency = 17, Q = 0.26},
    {name = "eq", gain = -5.0, frequency = 274, Q = 0.36},
    {name = "eq", gain = 6.3, frequency = 2557, Q = 1.74},
    {name = "eq", gain = 5.9, frequency = 6691, Q = 1.47},
    {name = "eq", gain = 5.5, frequency = 10728, Q = 2.37},
    {name = "eq", gain = 0.3, frequency = 796, Q = 4.31},
    {name = "eq", gain = 0.3, frequency = 1973, Q = 3.60},
    {name = "eq", gain = 1.1, frequency = 8691, Q = 2.01},
    {name = "eq", gain = 4.6, frequency = 13098, Q = 1.70},
    {name = "eq", gain = -15.4, frequency = 19589, Q = 0.49},
}
