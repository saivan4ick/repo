return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 3.1, frequency = 19, Q = 0.23},
    {name = "eq", gain = -2.2, frequency = 163, Q = 1.22},
    {name = "eq", gain = -1.7, frequency = 532, Q = 0.68},
    {name = "eq", gain = 6.7, frequency = 3494, Q = 3.00},
    {name = "eq", gain = -3.3, frequency = 9965, Q = 1.99},
    {name = "eq", gain = -2.1, frequency = 675, Q = 4.53},
    {name = "eq", gain = 3.1, frequency = 771, Q = 7.56},
    {name = "eq", gain = -1.6, frequency = 5283, Q = 4.48},
    {name = "eq", gain = 1.3, frequency = 6757, Q = 5.39},
    {name = "eq", gain = 5.9, frequency = 19359, Q = 0.91},
}
