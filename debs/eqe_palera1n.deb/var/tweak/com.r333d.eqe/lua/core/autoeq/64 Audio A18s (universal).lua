return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -2.9, frequency = 126, Q = 0.10},
    {name = "eq", gain = 5.6, frequency = 3343, Q = 2.19},
    {name = "eq", gain = 4.9, frequency = 5936, Q = 1.81},
    {name = "eq", gain = 5.3, frequency = 9269, Q = 2.65},
    {name = "eq", gain = 4.1, frequency = 22050, Q = 2.52},
    {name = "eq", gain = 1.7, frequency = 802, Q = 0.83},
    {name = "eq", gain = -2.0, frequency = 1495, Q = 0.87},
    {name = "eq", gain = 0.9, frequency = 2733, Q = 2.89},
    {name = "eq", gain = 0.3, frequency = 2747, Q = 2.06},
    {name = "eq", gain = 0.2, frequency = 7914, Q = 2.35},
}
