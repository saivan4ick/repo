return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -3.6, frequency = 104, Q = 0.43},
    {name = "eq", gain = -1.9, frequency = 237, Q = 0.20},
    {name = "eq", gain = 5.7, frequency = 4303, Q = 1.07},
    {name = "eq", gain = 3.7, frequency = 13011, Q = 1.17},
    {name = "eq", gain = 6.0, frequency = 19043, Q = 0.41},
    {name = "eq", gain = 1.6, frequency = 1936, Q = 3.94},
    {name = "eq", gain = -1.2, frequency = 2710, Q = 2.84},
    {name = "eq", gain = -3.9, frequency = 5675, Q = 5.92},
    {name = "eq", gain = 3.4, frequency = 6477, Q = 1.95},
    {name = "eq", gain = -2.8, frequency = 7877, Q = 3.36},
}
