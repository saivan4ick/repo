return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -4.8, frequency = 227, Q = 0.16},
    {name = "eq", gain = 5.5, frequency = 502, Q = 0.73},
    {name = "eq", gain = 4.9, frequency = 6182, Q = 1.61},
    {name = "eq", gain = 4.9, frequency = 9186, Q = 0.87},
    {name = "eq", gain = -14.9, frequency = 19759, Q = 0.28},
    {name = "eq", gain = 0.7, frequency = 99, Q = 2.96},
    {name = "eq", gain = -1.0, frequency = 197, Q = 4.49},
    {name = "eq", gain = -4.7, frequency = 3026, Q = 4.00},
    {name = "eq", gain = 2.8, frequency = 3731, Q = 1.41},
    {name = "eq", gain = -2.1, frequency = 5079, Q = 3.38},
}
