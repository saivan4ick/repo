return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -7.5, frequency = 27, Q = 0.11},
    {name = "eq", gain = 2.4, frequency = 687, Q = 1.34},
    {name = "eq", gain = 6.1, frequency = 2954, Q = 1.51},
    {name = "eq", gain = 7.6, frequency = 5421, Q = 1.84},
    {name = "eq", gain = -5.8, frequency = 8158, Q = 1.11},
    {name = "eq", gain = -3.1, frequency = 1575, Q = 1.89},
    {name = "eq", gain = 2.0, frequency = 1833, Q = 0.90},
    {name = "eq", gain = -1.5, frequency = 2986, Q = 5.26},
    {name = "eq", gain = -1.8, frequency = 12780, Q = 1.42},
    {name = "eq", gain = 6.1, frequency = 19713, Q = 0.52},
}
