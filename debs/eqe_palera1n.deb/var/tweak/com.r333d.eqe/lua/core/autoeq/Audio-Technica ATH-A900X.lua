return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 7.8, frequency = 13, Q = 0.47},
    {name = "eq", gain = -4.5, frequency = 144, Q = 0.36},
    {name = "eq", gain = 2.8, frequency = 2513, Q = 3.10},
    {name = "eq", gain = 5.3, frequency = 3465, Q = 2.85},
    {name = "eq", gain = 6.7, frequency = 9230, Q = 2.15},
    {name = "eq", gain = 2.3, frequency = 296, Q = 3.86},
    {name = "eq", gain = -2.6, frequency = 1391, Q = 1.08},
    {name = "eq", gain = 2.1, frequency = 1910, Q = 1.65},
    {name = "eq", gain = 3.3, frequency = 12278, Q = 1.55},
    {name = "eq", gain = -10.8, frequency = 19602, Q = 0.46},
}
