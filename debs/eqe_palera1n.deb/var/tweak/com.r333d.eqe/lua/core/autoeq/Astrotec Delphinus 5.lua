return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 3.8, frequency = 14, Q = 0.31},
    {name = "eq", gain = -4.1, frequency = 268, Q = 0.35},
    {name = "eq", gain = -6.8, frequency = 1056, Q = 1.61},
    {name = "eq", gain = 5.0, frequency = 3442, Q = 0.53},
    {name = "eq", gain = 6.1, frequency = 17918, Q = 0.17},
    {name = "eq", gain = 1.4, frequency = 1986, Q = 3.82},
    {name = "eq", gain = -3.4, frequency = 2623, Q = 4.00},
    {name = "eq", gain = 2.3, frequency = 2931, Q = 4.31},
    {name = "eq", gain = -3.0, frequency = 6991, Q = 5.20},
    {name = "eq", gain = 1.3, frequency = 7274, Q = 1.78},
}
