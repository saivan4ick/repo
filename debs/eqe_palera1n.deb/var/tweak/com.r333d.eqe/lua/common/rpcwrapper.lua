return function(f)
    local t = setmetatable({udata = f()}, {__jsontype = 'object'})
    return require 'dkjson'.encode(t)
end
