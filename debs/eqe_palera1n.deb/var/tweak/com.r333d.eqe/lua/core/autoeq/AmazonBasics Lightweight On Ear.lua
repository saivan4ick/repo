return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -6.8, frequency = 58, Q = 0.51},
    {name = "eq", gain = -4.0, frequency = 748, Q = 1.35},
    {name = "eq", gain = 5.1, frequency = 2171, Q = 1.99},
    {name = "eq", gain = 6.0, frequency = 4230, Q = 3.43},
    {name = "eq", gain = 3.9, frequency = 11186, Q = 1.81},
    {name = "eq", gain = -1.0, frequency = 135, Q = 1.64},
    {name = "eq", gain = 2.7, frequency = 309, Q = 2.04},
    {name = "eq", gain = -1.7, frequency = 521, Q = 3.56},
    {name = "eq", gain = -4.6, frequency = 6461, Q = 3.33},
    {name = "eq", gain = 1.8, frequency = 6831, Q = 1.19},
}
