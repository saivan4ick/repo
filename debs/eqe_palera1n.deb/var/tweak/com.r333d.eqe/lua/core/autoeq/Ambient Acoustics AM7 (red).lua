return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -6.0, frequency = 113, Q = 0.42},
    {name = "eq", gain = -5.4, frequency = 3448, Q = 4.73},
    {name = "eq", gain = 4.7, frequency = 3634, Q = 2.07},
    {name = "eq", gain = 4.2, frequency = 4845, Q = 2.64},
    {name = "eq", gain = 6.8, frequency = 10941, Q = 1.37},
    {name = "eq", gain = 4.2, frequency = 996, Q = 1.46},
    {name = "eq", gain = -6.7, frequency = 1992, Q = 4.38},
    {name = "eq", gain = 2.5, frequency = 2626, Q = 5.04},
    {name = "eq", gain = 3.3, frequency = 13977, Q = 1.86},
    {name = "eq", gain = -10.0, frequency = 19746, Q = 0.60},
}
