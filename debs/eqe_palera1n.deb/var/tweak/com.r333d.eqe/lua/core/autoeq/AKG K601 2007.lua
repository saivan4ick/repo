return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.5, frequency = 34, Q = 0.46},
    {name = "eq", gain = -4.0, frequency = 2463, Q = 2.04},
    {name = "eq", gain = 2.4, frequency = 2660, Q = 0.34},
    {name = "eq", gain = -7.3, frequency = 6077, Q = 3.17},
    {name = "eq", gain = -3.3, frequency = 19815, Q = 0.10},
    {name = "eq", gain = 1.7, frequency = 65, Q = 5.66},
    {name = "eq", gain = -1.1, frequency = 194, Q = 2.16},
    {name = "eq", gain = 1.8, frequency = 6877, Q = 5.82},
    {name = "eq", gain = -2.0, frequency = 7975, Q = 2.65},
    {name = "eq", gain = 0.8, frequency = 11921, Q = 1.22},
}
