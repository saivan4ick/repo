return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 4.4, frequency = 22, Q = 0.51},
    {name = "eq", gain = -5.9, frequency = 191, Q = 0.75},
    {name = "eq", gain = 6.0, frequency = 2818, Q = 2.33},
    {name = "eq", gain = 5.3, frequency = 4111, Q = 3.39},
    {name = "eq", gain = 2.7, frequency = 8852, Q = 3.91},
    {name = "eq", gain = 1.1, frequency = 809, Q = 1.68},
    {name = "eq", gain = -1.4, frequency = 1412, Q = 3.20},
    {name = "eq", gain = 2.2, frequency = 10153, Q = 1.08},
    {name = "eq", gain = 2.7, frequency = 11832, Q = 1.07},
    {name = "eq", gain = -16.0, frequency = 19687, Q = 0.32},
}
