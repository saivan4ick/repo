return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.8, frequency = 33, Q = 0.63},
    {name = "eq", gain = 2.7, frequency = 385, Q = 4.49},
    {name = "eq", gain = 3.8, frequency = 1873, Q = 2.61},
    {name = "eq", gain = -3.1, frequency = 3177, Q = 2.32},
    {name = "eq", gain = -3.1, frequency = 5758, Q = 5.73},
    {name = "eq", gain = -1.0, frequency = 35, Q = 2.93},
    {name = "eq", gain = 1.9, frequency = 65, Q = 2.04},
    {name = "eq", gain = -3.4, frequency = 150, Q = 2.15},
    {name = "eq", gain = -0.6, frequency = 986, Q = 3.43},
    {name = "eq", gain = 1.7, frequency = 9303, Q = 3.09},
}
