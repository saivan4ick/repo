return {
    {name = "preamp", gain = -7.5},
    {name = "eq", gain = 7.3, frequency = 32, Q = 0.26},
    {name = "eq", gain = -4.3, frequency = 1009, Q = 0.11},
    {name = "eq", gain = 7.2, frequency = 1029, Q = 3.32},
    {name = "eq", gain = 6.5, frequency = 2779, Q = 1.07},
    {name = "eq", gain = 7.5, frequency = 8384, Q = 3.11},
    {name = "eq", gain = -0.4, frequency = 44, Q = 2.02},
    {name = "eq", gain = -2.8, frequency = 92, Q = 0.51},
    {name = "eq", gain = 4.7, frequency = 8932, Q = 0.82},
    {name = "eq", gain = 6.1, frequency = 11624, Q = 0.93},
    {name = "eq", gain = -23.8, frequency = 19675, Q = 0.24},
}
