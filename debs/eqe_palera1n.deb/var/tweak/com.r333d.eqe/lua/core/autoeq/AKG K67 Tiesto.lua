return {
    {name = "preamp", gain = -5.1},
    {name = "eq", gain = -7.8, frequency = 126, Q = 0.36},
    {name = "eq", gain = 10.9, frequency = 288, Q = 0.77},
    {name = "eq", gain = -7.2, frequency = 2065, Q = 0.37},
    {name = "eq", gain = 8.6, frequency = 2526, Q = 1.16},
    {name = "eq", gain = 6.3, frequency = 4019, Q = 2.45},
    {name = "eq", gain = 1.9, frequency = 62, Q = 3.39},
    {name = "eq", gain = -1.5, frequency = 124, Q = 3.89},
    {name = "eq", gain = 3.0, frequency = 4947, Q = 5.42},
    {name = "eq", gain = -5.5, frequency = 5605, Q = 5.88},
    {name = "eq", gain = 2.5, frequency = 9339, Q = 2.90},
}
