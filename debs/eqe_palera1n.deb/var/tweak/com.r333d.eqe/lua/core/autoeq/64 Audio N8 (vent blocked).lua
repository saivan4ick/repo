return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.9, frequency = 56, Q = 0.20},
    {name = "eq", gain = -6.1, frequency = 290, Q = 0.59},
    {name = "eq", gain = -3.9, frequency = 1687, Q = 1.51},
    {name = "eq", gain = 3.9, frequency = 3356, Q = 2.11},
    {name = "eq", gain = 6.5, frequency = 6470, Q = 2.62},
    {name = "eq", gain = 1.1, frequency = 93, Q = 5.07},
    {name = "eq", gain = 2.0, frequency = 9472, Q = 1.44},
    {name = "eq", gain = -7.7, frequency = 19716, Q = 0.29},
}
