return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 5.5, frequency = 18, Q = 0.58},
    {name = "eq", gain = 1.9, frequency = 47, Q = 0.93},
    {name = "eq", gain = -5.1, frequency = 675, Q = 0.33},
    {name = "eq", gain = -7.0, frequency = 1679, Q = 2.02},
    {name = "eq", gain = 9.4, frequency = 3193, Q = 0.69},
    {name = "eq", gain = 0.9, frequency = 494, Q = 2.08},
    {name = "eq", gain = -1.0, frequency = 752, Q = 4.12},
    {name = "eq", gain = 3.3, frequency = 2446, Q = 6.50},
    {name = "eq", gain = 8.2, frequency = 7084, Q = 0.97},
    {name = "eq", gain = -7.5, frequency = 18472, Q = 0.08},
}
