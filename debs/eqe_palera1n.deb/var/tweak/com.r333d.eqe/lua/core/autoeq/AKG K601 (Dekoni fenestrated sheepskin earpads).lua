return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.1, frequency = 21, Q = 0.83},
    {name = "eq", gain = -4.1, frequency = 207, Q = 0.68},
    {name = "eq", gain = 3.8, frequency = 710, Q = 1.66},
    {name = "eq", gain = -4.1, frequency = 2393, Q = 2.64},
    {name = "eq", gain = 7.1, frequency = 3786, Q = 3.04},
    {name = "eq", gain = 0.4, frequency = 1719, Q = 2.80},
    {name = "eq", gain = 1.4, frequency = 4296, Q = 4.40},
    {name = "eq", gain = 5.0, frequency = 10085, Q = 1.17},
    {name = "eq", gain = 4.1, frequency = 14383, Q = 0.78},
    {name = "eq", gain = -8.5, frequency = 19162, Q = 0.14},
}
