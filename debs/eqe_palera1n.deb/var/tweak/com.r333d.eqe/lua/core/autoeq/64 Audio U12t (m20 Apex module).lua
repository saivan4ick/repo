return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -5.3, frequency = 17, Q = 0.08},
    {name = "eq", gain = 6.4, frequency = 3453, Q = 2.56},
    {name = "eq", gain = 3.0, frequency = 5979, Q = 2.33},
    {name = "eq", gain = 4.9, frequency = 10164, Q = 1.11},
    {name = "eq", gain = -12.0, frequency = 19557, Q = 0.42},
    {name = "eq", gain = -2.2, frequency = 546, Q = 1.09},
    {name = "eq", gain = 1.7, frequency = 1259, Q = 0.17},
    {name = "eq", gain = -3.6, frequency = 1972, Q = 0.74},
    {name = "eq", gain = 2.9, frequency = 2747, Q = 4.33},
    {name = "eq", gain = -0.9, frequency = 6977, Q = 5.07},
}
