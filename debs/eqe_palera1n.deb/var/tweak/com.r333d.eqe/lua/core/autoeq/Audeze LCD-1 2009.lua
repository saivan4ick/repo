return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.3, frequency = 32, Q = 0.37},
    {name = "eq", gain = 2.4, frequency = 422, Q = 1.33},
    {name = "eq", gain = -0.9, frequency = 448, Q = 2.60},
    {name = "eq", gain = -6.3, frequency = 5280, Q = 2.02},
    {name = "eq", gain = -6.2, frequency = 19776, Q = 0.38},
    {name = "eq", gain = -0.8, frequency = 2707, Q = 4.12},
    {name = "eq", gain = -2.3, frequency = 5905, Q = 5.31},
    {name = "eq", gain = 2.8, frequency = 6780, Q = 2.23},
    {name = "eq", gain = -1.5, frequency = 7539, Q = 4.66},
    {name = "eq", gain = -1.3, frequency = 7873, Q = 4.05},
}
