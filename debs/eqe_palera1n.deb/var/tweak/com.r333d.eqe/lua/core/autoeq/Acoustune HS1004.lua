return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -2.6, frequency = 74, Q = 0.72},
    {name = "eq", gain = -3.3, frequency = 188, Q = 0.67},
    {name = "eq", gain = 1.4, frequency = 733, Q = 2.35},
    {name = "eq", gain = 7.1, frequency = 3549, Q = 1.53},
    {name = "eq", gain = -3.3, frequency = 6250, Q = 3.76},
    {name = "eq", gain = 1.2, frequency = 1016, Q = 2.18},
    {name = "eq", gain = -2.0, frequency = 1565, Q = 1.32},
    {name = "eq", gain = 2.4, frequency = 2663, Q = 4.85},
    {name = "eq", gain = 1.7, frequency = 11192, Q = 1.67},
    {name = "eq", gain = -6.6, frequency = 19748, Q = 0.52},
}
