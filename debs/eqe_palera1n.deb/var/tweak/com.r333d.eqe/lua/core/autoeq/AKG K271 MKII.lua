return {
    {name = "preamp", gain = -7.5},
    {name = "eq", gain = 6.4, frequency = 33, Q = 0.40},
    {name = "eq", gain = 4.3, frequency = 145, Q = 2.51},
    {name = "eq", gain = -4.2, frequency = 4025, Q = 0.08},
    {name = "eq", gain = 10.0, frequency = 4171, Q = 1.26},
    {name = "eq", gain = 9.4, frequency = 18214, Q = 0.86},
    {name = "eq", gain = 3.5, frequency = 904, Q = 4.67},
    {name = "eq", gain = -3.9, frequency = 1795, Q = 3.36},
    {name = "eq", gain = 3.6, frequency = 3049, Q = 1.04},
    {name = "eq", gain = -5.3, frequency = 3616, Q = 3.91},
    {name = "eq", gain = -2.6, frequency = 9538, Q = 1.75},
}
