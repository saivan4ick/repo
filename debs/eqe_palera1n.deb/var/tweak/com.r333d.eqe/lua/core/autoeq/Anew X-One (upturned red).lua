return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.7, frequency = 32, Q = 0.42},
    {name = "eq", gain = -2.2, frequency = 761, Q = 0.09},
    {name = "eq", gain = 6.8, frequency = 4663, Q = 1.33},
    {name = "eq", gain = 2.5, frequency = 11246, Q = 0.47},
    {name = "eq", gain = 3.9, frequency = 20531, Q = 2.08},
    {name = "eq", gain = 3.5, frequency = 803, Q = 0.85},
    {name = "eq", gain = -2.2, frequency = 1071, Q = 0.30},
    {name = "eq", gain = 3.9, frequency = 3874, Q = 3.48},
    {name = "eq", gain = -2.8, frequency = 4707, Q = 2.42},
    {name = "eq", gain = 3.0, frequency = 5715, Q = 4.71},
}
