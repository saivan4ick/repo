return {
    {name = "preamp", gain = -5.3},
    {name = "eq", gain = 2.0, frequency = 2157, Q = 3.50},
    {name = "eq", gain = 4.3, frequency = 4216, Q = 2.09},
    {name = "eq", gain = 3.7, frequency = 7699, Q = 1.09},
    {name = "eq", gain = -9.6, frequency = 19491, Q = 0.39},
    {name = "eq", gain = -6.7, frequency = 23, Q = 0.64},
    {name = "eq", gain = -2.6, frequency = 36, Q = 1.61},
    {name = "eq", gain = -2.3, frequency = 126, Q = 0.70},
    {name = "eq", gain = -1.6, frequency = 258, Q = 1.54},
    {name = "eq", gain = -2.5, frequency = 917, Q = 1.69},
}
