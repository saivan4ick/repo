return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -5.6, frequency = 174, Q = 0.47},
    {name = "eq", gain = 5.1, frequency = 2156, Q = 3.73},
    {name = "eq", gain = 5.2, frequency = 3002, Q = 2.50},
    {name = "eq", gain = 4.1, frequency = 4772, Q = 2.81},
    {name = "eq", gain = 3.0, frequency = 9084, Q = 1.14},
    {name = "eq", gain = 1.3, frequency = 19, Q = 1.64},
    {name = "eq", gain = 1.5, frequency = 874, Q = 2.04},
    {name = "eq", gain = -3.0, frequency = 1449, Q = 2.39},
    {name = "eq", gain = 2.1, frequency = 1883, Q = 4.86},
}
