return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -2.4, frequency = 172, Q = 1.68},
    {name = "eq", gain = -3.0, frequency = 1140, Q = 1.71},
    {name = "eq", gain = 3.4, frequency = 5030, Q = 3.46},
    {name = "eq", gain = 5.8, frequency = 17156, Q = 0.25},
    {name = "eq", gain = 2.7, frequency = 20476, Q = 1.38},
    {name = "eq", gain = 1.7, frequency = 24, Q = 0.94},
    {name = "eq", gain = 1.0, frequency = 51, Q = 2.23},
    {name = "eq", gain = 2.8, frequency = 2073, Q = 5.29},
    {name = "eq", gain = -0.6, frequency = 2688, Q = 0.61},
    {name = "eq", gain = 1.2, frequency = 7241, Q = 4.12},
}
