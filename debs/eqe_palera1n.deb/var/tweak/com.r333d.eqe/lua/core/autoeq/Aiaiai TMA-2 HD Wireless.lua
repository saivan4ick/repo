return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -6.8, frequency = 181, Q = 0.52},
    {name = "eq", gain = 3.2, frequency = 737, Q = 2.15},
    {name = "eq", gain = 4.6, frequency = 2378, Q = 1.22},
    {name = "eq", gain = 2.1, frequency = 3198, Q = 2.04},
    {name = "eq", gain = 6.6, frequency = 9947, Q = 1.53},
    {name = "eq", gain = 2.1, frequency = 20, Q = 2.31},
    {name = "eq", gain = -1.3, frequency = 1180, Q = 6.03},
    {name = "eq", gain = 2.2, frequency = 4890, Q = 4.70},
    {name = "eq", gain = -2.3, frequency = 6822, Q = 1.67},
    {name = "eq", gain = 2.8, frequency = 7891, Q = 3.77},
}
