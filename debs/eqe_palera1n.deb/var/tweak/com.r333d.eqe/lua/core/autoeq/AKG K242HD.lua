return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.6, frequency = 29, Q = 0.67},
    {name = "eq", gain = -3.6, frequency = 189, Q = 0.83},
    {name = "eq", gain = -6.1, frequency = 2643, Q = 4.22},
    {name = "eq", gain = 5.8, frequency = 4761, Q = 2.80},
    {name = "eq", gain = 4.1, frequency = 6515, Q = 3.51},
    {name = "eq", gain = -1.6, frequency = 404, Q = 1.93},
    {name = "eq", gain = 2.9, frequency = 545, Q = 3.85},
    {name = "eq", gain = 3.5, frequency = 1527, Q = 1.82},
    {name = "eq", gain = -2.5, frequency = 2217, Q = 4.09},
    {name = "eq", gain = -2.1, frequency = 10759, Q = 3.26},
}
