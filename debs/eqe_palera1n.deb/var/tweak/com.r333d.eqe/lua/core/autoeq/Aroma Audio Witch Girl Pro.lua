return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -1.8, frequency = 79, Q = 0.47},
    {name = "eq", gain = -4.8, frequency = 260, Q = 0.43},
    {name = "eq", gain = -3.8, frequency = 1490, Q = 1.74},
    {name = "eq", gain = 6.3, frequency = 2758, Q = 0.84},
    {name = "eq", gain = 6.2, frequency = 14562, Q = 0.32},
    {name = "eq", gain = -0.6, frequency = 3153, Q = 4.32},
    {name = "eq", gain = 1.3, frequency = 5140, Q = 2.60},
    {name = "eq", gain = 1.3, frequency = 5471, Q = 4.09},
    {name = "eq", gain = -7.2, frequency = 6152, Q = 4.98},
    {name = "eq", gain = 2.3, frequency = 6989, Q = 2.41},
}
