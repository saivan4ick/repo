return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -2.8, frequency = 21, Q = 0.74},
    {name = "eq", gain = -1.9, frequency = 56, Q = 0.48},
    {name = "eq", gain = -4.8, frequency = 291, Q = 0.38},
    {name = "eq", gain = 6.0, frequency = 2541, Q = 1.83},
    {name = "eq", gain = 6.9, frequency = 8126, Q = 0.99},
    {name = "eq", gain = 1.8, frequency = 3396, Q = 3.68},
    {name = "eq", gain = -3.9, frequency = 4412, Q = 2.67},
    {name = "eq", gain = 4.2, frequency = 5231, Q = 3.84},
    {name = "eq", gain = 5.8, frequency = 12373, Q = 1.68},
    {name = "eq", gain = -15.3, frequency = 19617, Q = 0.48},
}
