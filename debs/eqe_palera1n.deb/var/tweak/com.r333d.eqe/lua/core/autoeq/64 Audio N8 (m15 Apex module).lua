return {
    {name = "preamp", gain = -5.5},
    {name = "eq", gain = -4.7, frequency = 58, Q = 0.18},
    {name = "eq", gain = 1.1, frequency = 825, Q = 1.91},
    {name = "eq", gain = 5.1, frequency = 3151, Q = 1.74},
    {name = "eq", gain = 3.1, frequency = 6161, Q = 3.31},
    {name = "eq", gain = 3.7, frequency = 9665, Q = 3.01},
    {name = "eq", gain = -0.7, frequency = 1432, Q = 5.42},
    {name = "eq", gain = -2.3, frequency = 5014, Q = 7.27},
    {name = "eq", gain = 1.0, frequency = 5171, Q = 1.86},
    {name = "eq", gain = 2.8, frequency = 12164, Q = 1.40},
    {name = "eq", gain = -10.9, frequency = 19681, Q = 0.46},
}
