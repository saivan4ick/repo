return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 7.4, frequency = 49, Q = 0.32},
    {name = "eq", gain = -4.5, frequency = 304, Q = 0.34},
    {name = "eq", gain = 3.9, frequency = 3486, Q = 3.22},
    {name = "eq", gain = 5.6, frequency = 6536, Q = 2.64},
    {name = "eq", gain = 5.1, frequency = 8973, Q = 2.97},
    {name = "eq", gain = 1.3, frequency = 84, Q = 4.35},
    {name = "eq", gain = 2.7, frequency = 922, Q = 1.35},
    {name = "eq", gain = -3.2, frequency = 1562, Q = 0.98},
    {name = "eq", gain = 1.8, frequency = 2767, Q = 2.41},
}
