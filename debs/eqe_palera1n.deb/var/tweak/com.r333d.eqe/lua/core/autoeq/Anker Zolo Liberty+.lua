return {
    {name = "preamp", gain = -4.3},
    {name = "eq", gain = -6.6, frequency = 92, Q = 0.69},
    {name = "eq", gain = -3.5, frequency = 176, Q = 1.70},
    {name = "eq", gain = 2.5, frequency = 936, Q = 0.10},
    {name = "eq", gain = 4.8, frequency = 5177, Q = 2.49},
    {name = "eq", gain = -4.3, frequency = 8296, Q = 0.62},
    {name = "eq", gain = -1.8, frequency = 1385, Q = 2.58},
    {name = "eq", gain = 1.8, frequency = 2452, Q = 1.94},
    {name = "eq", gain = -1.6, frequency = 3394, Q = 3.93},
    {name = "eq", gain = -3.2, frequency = 6911, Q = 5.46},
    {name = "eq", gain = 1.5, frequency = 7344, Q = 2.01},
}
