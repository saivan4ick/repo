return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -3.7, frequency = 113, Q = 0.76},
    {name = "eq", gain = -4.3, frequency = 265, Q = 0.98},
    {name = "eq", gain = 4.6, frequency = 2288, Q = 0.92},
    {name = "eq", gain = 3.2, frequency = 3211, Q = 2.63},
    {name = "eq", gain = 3.4, frequency = 9866, Q = 3.22},
    {name = "eq", gain = 1.7, frequency = 21, Q = 1.89},
    {name = "eq", gain = 1.5, frequency = 921, Q = 2.82},
    {name = "eq", gain = -1.0, frequency = 1563, Q = 3.45},
    {name = "eq", gain = 2.9, frequency = 12261, Q = 1.35},
    {name = "eq", gain = -10.9, frequency = 19739, Q = 0.42},
}
