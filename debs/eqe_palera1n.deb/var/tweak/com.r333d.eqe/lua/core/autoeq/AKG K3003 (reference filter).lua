return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.3, frequency = 18, Q = 0.48},
    {name = "eq", gain = -4.8, frequency = 235, Q = 0.43},
    {name = "eq", gain = 2.0, frequency = 848, Q = 0.43},
    {name = "eq", gain = 5.5, frequency = 3452, Q = 1.88},
    {name = "eq", gain = 1.0, frequency = 11887, Q = 2.03},
    {name = "eq", gain = -1.1, frequency = 1319, Q = 3.85},
    {name = "eq", gain = 0.4, frequency = 3513, Q = 0.24},
    {name = "eq", gain = -2.7, frequency = 5277, Q = 3.94},
    {name = "eq", gain = 3.5, frequency = 6455, Q = 4.47},
    {name = "eq", gain = -1.5, frequency = 7558, Q = 2.73},
}
