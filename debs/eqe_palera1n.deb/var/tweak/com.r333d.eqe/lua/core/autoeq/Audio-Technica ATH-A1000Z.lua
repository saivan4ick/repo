return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.2, frequency = 22, Q = 1.05},
    {name = "eq", gain = -4.8, frequency = 133, Q = 0.78},
    {name = "eq", gain = 5.9, frequency = 3127, Q = 4.63},
    {name = "eq", gain = 5.0, frequency = 8349, Q = 4.30},
    {name = "eq", gain = 4.3, frequency = 10244, Q = 3.08},
    {name = "eq", gain = -1.6, frequency = 1002, Q = 1.72},
    {name = "eq", gain = -4.5, frequency = 2039, Q = 3.74},
    {name = "eq", gain = 1.8, frequency = 2283, Q = 1.20},
    {name = "eq", gain = -2.2, frequency = 6132, Q = 7.94},
    {name = "eq", gain = -10.4, frequency = 19452, Q = 0.83},
}
