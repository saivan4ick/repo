return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -1.7, frequency = 16, Q = 0.11},
    {name = "eq", gain = -5.3, frequency = 200, Q = 0.44},
    {name = "eq", gain = 1.4, frequency = 747, Q = 1.25},
    {name = "eq", gain = 7.6, frequency = 3579, Q = 0.73},
    {name = "eq", gain = -3.5, frequency = 5957, Q = 1.11},
    {name = "eq", gain = -0.4, frequency = 2007, Q = 1.50},
    {name = "eq", gain = 1.0, frequency = 2791, Q = 1.51},
    {name = "eq", gain = -1.2, frequency = 3198, Q = 4.02},
    {name = "eq", gain = -0.9, frequency = 8146, Q = 4.21},
    {name = "eq", gain = 1.0, frequency = 20032, Q = 0.22},
}
