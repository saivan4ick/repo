return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -4.7, frequency = 203, Q = 0.92},
    {name = "eq", gain = -2.3, frequency = 485, Q = 3.13},
    {name = "eq", gain = -4.0, frequency = 822, Q = 1.20},
    {name = "eq", gain = 5.0, frequency = 1534, Q = 2.90},
    {name = "eq", gain = 7.0, frequency = 4786, Q = 1.12},
    {name = "eq", gain = 1.3, frequency = 20, Q = 1.33},
    {name = "eq", gain = 3.1, frequency = 1803, Q = 4.75},
    {name = "eq", gain = -4.0, frequency = 2384, Q = 1.98},
    {name = "eq", gain = 1.2, frequency = 2834, Q = 3.11},
    {name = "eq", gain = 3.0, frequency = 3253, Q = 4.15},
}
