return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 7.0, frequency = 48, Q = 0.27},
    {name = "eq", gain = -4.6, frequency = 487, Q = 0.26},
    {name = "eq", gain = -4.1, frequency = 1331, Q = 1.53},
    {name = "eq", gain = 5.0, frequency = 2990, Q = 0.89},
    {name = "eq", gain = 2.9, frequency = 3770, Q = 0.92},
    {name = "eq", gain = 1.2, frequency = 84, Q = 4.94},
    {name = "eq", gain = 1.5, frequency = 6853, Q = 4.76},
    {name = "eq", gain = 2.0, frequency = 9353, Q = 2.00},
    {name = "eq", gain = -8.2, frequency = 19529, Q = 0.36},
}
