return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -2.2, frequency = 103, Q = 0.58},
    {name = "eq", gain = -3.8, frequency = 248, Q = 0.66},
    {name = "eq", gain = -10.6, frequency = 1811, Q = 1.67},
    {name = "eq", gain = 13.9, frequency = 4587, Q = 0.33},
    {name = "eq", gain = -13.1, frequency = 7717, Q = 0.71},
    {name = "eq", gain = 1.8, frequency = 2609, Q = 6.30},
    {name = "eq", gain = 5.3, frequency = 5411, Q = 3.98},
    {name = "eq", gain = -4.5, frequency = 6310, Q = 1.36},
    {name = "eq", gain = 3.6, frequency = 7995, Q = 2.60},
    {name = "eq", gain = -0.9, frequency = 12382, Q = 3.73},
}
