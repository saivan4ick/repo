return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -5.3, frequency = 50, Q = 0.18},
    {name = "eq", gain = 5.7, frequency = 3351, Q = 2.15},
    {name = "eq", gain = 3.5, frequency = 6114, Q = 3.42},
    {name = "eq", gain = 5.3, frequency = 10475, Q = 1.17},
    {name = "eq", gain = -9.3, frequency = 19779, Q = 0.52},
    {name = "eq", gain = 1.8, frequency = 959, Q = 1.50},
    {name = "eq", gain = -1.8, frequency = 1479, Q = 1.28},
    {name = "eq", gain = 1.0, frequency = 2566, Q = 3.36},
    {name = "eq", gain = -0.1, frequency = 5124, Q = 3.04},
    {name = "eq", gain = -0.6, frequency = 17386, Q = 2.11},
}
