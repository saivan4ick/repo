return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = 7.2, frequency = 33, Q = 0.40},
    {name = "eq", gain = -2.0, frequency = 3165, Q = 0.03},
    {name = "eq", gain = 7.2, frequency = 3855, Q = 2.97},
    {name = "eq", gain = 6.0, frequency = 6966, Q = 2.41},
    {name = "eq", gain = 3.5, frequency = 9770, Q = 1.42},
    {name = "eq", gain = -1.4, frequency = 149, Q = 1.15},
    {name = "eq", gain = -1.7, frequency = 1381, Q = 3.36},
    {name = "eq", gain = 1.7, frequency = 2104, Q = 4.58},
    {name = "eq", gain = -2.1, frequency = 7678, Q = 5.60},
    {name = "eq", gain = 1.3, frequency = 12860, Q = 2.59},
}
