return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -3.5, frequency = 60, Q = 0.46},
    {name = "eq", gain = -5.1, frequency = 177, Q = 0.55},
    {name = "eq", gain = 4.5, frequency = 3583, Q = 1.65},
    {name = "eq", gain = 5.4, frequency = 7029, Q = 1.19},
    {name = "eq", gain = 5.1, frequency = 11360, Q = 2.16},
    {name = "eq", gain = -1.1, frequency = 1491, Q = 3.80},
    {name = "eq", gain = -0.6, frequency = 2111, Q = 2.54},
    {name = "eq", gain = -0.1, frequency = 2181, Q = 2.09},
    {name = "eq", gain = 1.2, frequency = 2930, Q = 2.00},
    {name = "eq", gain = -0.9, frequency = 3491, Q = 3.55},
}
