return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -7.8, frequency = 23, Q = 0.08},
    {name = "eq", gain = 4.0, frequency = 629, Q = 0.38},
    {name = "eq", gain = -2.9, frequency = 3038, Q = 4.31},
    {name = "eq", gain = -8.0, frequency = 5472, Q = 3.06},
    {name = "eq", gain = 6.8, frequency = 11044, Q = 0.63},
    {name = "eq", gain = -1.7, frequency = 191, Q = 3.96},
    {name = "eq", gain = 1.9, frequency = 286, Q = 5.03},
    {name = "eq", gain = -2.5, frequency = 7097, Q = 5.15},
    {name = "eq", gain = 2.2, frequency = 8656, Q = 1.47},
    {name = "eq", gain = -2.0, frequency = 10280, Q = 2.44},
}
