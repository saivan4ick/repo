return {
    {name = "preamp", gain = -6.1},
    {name = "eq", gain = -3.4, frequency = 43, Q = 0.46},
    {name = "eq", gain = 1.4, frequency = 2049, Q = 2.09},
    {name = "eq", gain = 2.5, frequency = 5124, Q = 2.02},
    {name = "eq", gain = -2.8, frequency = 5964, Q = 5.64},
    {name = "eq", gain = -2.3, frequency = 9369, Q = 2.33},
    {name = "eq", gain = 0.4, frequency = 905, Q = 4.32},
    {name = "eq", gain = -1.4, frequency = 12109, Q = 1.70},
    {name = "eq", gain = 6.0, frequency = 19548, Q = 0.45},
}
