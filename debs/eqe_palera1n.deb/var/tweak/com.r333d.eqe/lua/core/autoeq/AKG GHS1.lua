return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 3.3, frequency = 21, Q = 1.56},
    {name = "eq", gain = -4.3, frequency = 176, Q = 0.37},
    {name = "eq", gain = 9.1, frequency = 432, Q = 1.32},
    {name = "eq", gain = -2.9, frequency = 1349, Q = 2.37},
    {name = "eq", gain = -4.2, frequency = 3469, Q = 4.67},
    {name = "eq", gain = 2.0, frequency = 2337, Q = 5.97},
    {name = "eq", gain = 1.8, frequency = 4770, Q = 7.04},
    {name = "eq", gain = -4.8, frequency = 5725, Q = 4.28},
    {name = "eq", gain = 3.5, frequency = 8890, Q = 1.06},
    {name = "eq", gain = -7.0, frequency = 19584, Q = 0.53},
}
