return {
    {name = "preamp", gain = -5.3},
    {name = "eq", gain = 4.5, frequency = 19, Q = 1.44},
    {name = "eq", gain = 2.9, frequency = 87, Q = 0.37},
    {name = "eq", gain = -3.8, frequency = 1255, Q = 1.28},
    {name = "eq", gain = -3.1, frequency = 9727, Q = 2.25},
    {name = "eq", gain = -3.2, frequency = 14108, Q = 1.05},
    {name = "eq", gain = -2.4, frequency = 1815, Q = 4.89},
    {name = "eq", gain = 1.8, frequency = 3401, Q = 1.30},
    {name = "eq", gain = 3.3, frequency = 4765, Q = 3.31},
    {name = "eq", gain = -4.1, frequency = 6029, Q = 2.54},
    {name = "eq", gain = 3.1, frequency = 6877, Q = 5.93},
}
