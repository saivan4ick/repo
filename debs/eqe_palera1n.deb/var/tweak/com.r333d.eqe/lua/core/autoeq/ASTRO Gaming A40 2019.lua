return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -4.5, frequency = 156, Q = 0.49},
    {name = "eq", gain = 3.9, frequency = 2694, Q = 1.21},
    {name = "eq", gain = 5.4, frequency = 4562, Q = 2.57},
    {name = "eq", gain = -8.3, frequency = 6248, Q = 3.36},
    {name = "eq", gain = 6.3, frequency = 11862, Q = 0.87},
    {name = "eq", gain = 1.4, frequency = 947, Q = 2.18},
    {name = "eq", gain = -0.5, frequency = 1589, Q = 0.30},
    {name = "eq", gain = 1.5, frequency = 2940, Q = 9.46},
    {name = "eq", gain = -2.6, frequency = 8317, Q = 4.88},
    {name = "eq", gain = 1.6, frequency = 8428, Q = 1.97},
}
