return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -4.8, frequency = 17, Q = 0.33},
    {name = "eq", gain = -5.3, frequency = 116, Q = 0.29},
    {name = "eq", gain = 3.1, frequency = 822, Q = 1.10},
    {name = "eq", gain = 6.6, frequency = 4529, Q = 1.62},
    {name = "eq", gain = 5.8, frequency = 19789, Q = 0.36},
    {name = "eq", gain = -2.0, frequency = 2733, Q = 4.16},
    {name = "eq", gain = 1.4, frequency = 3465, Q = 4.38},
    {name = "eq", gain = -2.1, frequency = 6759, Q = 6.58},
    {name = "eq", gain = 0.9, frequency = 7818, Q = 1.33},
    {name = "eq", gain = -0.7, frequency = 10900, Q = 2.54},
}
