return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -4.4, frequency = 22, Q = 0.15},
    {name = "eq", gain = -5.3, frequency = 169, Q = 0.48},
    {name = "eq", gain = -11.9, frequency = 1559, Q = 1.67},
    {name = "eq", gain = 8.3, frequency = 1722, Q = 0.50},
    {name = "eq", gain = 4.3, frequency = 5129, Q = 1.83},
    {name = "eq", gain = -1.9, frequency = 2066, Q = 2.37},
    {name = "eq", gain = 2.4, frequency = 2444, Q = 5.81},
    {name = "eq", gain = 0.6, frequency = 4036, Q = 0.21},
    {name = "eq", gain = 1.9, frequency = 10658, Q = 1.82},
    {name = "eq", gain = -11.7, frequency = 19555, Q = 0.33},
}
