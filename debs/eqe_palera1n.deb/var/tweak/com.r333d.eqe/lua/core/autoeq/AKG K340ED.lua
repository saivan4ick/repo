return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.7, frequency = 31, Q = 0.44},
    {name = "eq", gain = -7.2, frequency = 277, Q = 0.46},
    {name = "eq", gain = 7.3, frequency = 792, Q = 0.62},
    {name = "eq", gain = -11.0, frequency = 2577, Q = 2.58},
    {name = "eq", gain = 6.3, frequency = 3916, Q = 1.24},
    {name = "eq", gain = 1.3, frequency = 843, Q = 2.43},
    {name = "eq", gain = -2.1, frequency = 1122, Q = 1.76},
    {name = "eq", gain = 3.0, frequency = 1334, Q = 5.06},
    {name = "eq", gain = 2.8, frequency = 5681, Q = 5.68},
    {name = "eq", gain = -6.4, frequency = 18745, Q = 0.48},
}
