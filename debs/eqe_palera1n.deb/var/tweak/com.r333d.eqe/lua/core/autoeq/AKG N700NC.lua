return {
    {name = "preamp", gain = -1.8},
    {name = "eq", gain = 1.7, frequency = 458, Q = 0.83},
    {name = "eq", gain = 2.8, frequency = 2187, Q = 2.48},
    {name = "eq", gain = -6.5, frequency = 2889, Q = 3.34},
    {name = "eq", gain = -6.6, frequency = 5749, Q = 2.74},
    {name = "eq", gain = 1.9, frequency = 7060, Q = 2.38},
    {name = "eq", gain = -1.3, frequency = 35, Q = 1.22},
    {name = "eq", gain = 1.9, frequency = 1019, Q = 1.82},
    {name = "eq", gain = -1.2, frequency = 1039, Q = 0.99},
    {name = "eq", gain = 0.9, frequency = 4378, Q = 2.65},
    {name = "eq", gain = -1.1, frequency = 4715, Q = 4.80},
}
