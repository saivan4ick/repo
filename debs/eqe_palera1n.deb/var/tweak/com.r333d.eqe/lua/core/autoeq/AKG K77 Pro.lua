return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.6, frequency = 37, Q = 0.28},
    {name = "eq", gain = -4.6, frequency = 197, Q = 0.63},
    {name = "eq", gain = -3.0, frequency = 645, Q = 3.23},
    {name = "eq", gain = -7.9, frequency = 1111, Q = 1.49},
    {name = "eq", gain = 7.0, frequency = 4128, Q = 0.60},
    {name = "eq", gain = -0.1, frequency = 108, Q = 3.71},
    {name = "eq", gain = -0.2, frequency = 273, Q = 4.08},
    {name = "eq", gain = 0.5, frequency = 2847, Q = 4.64},
    {name = "eq", gain = 1.8, frequency = 8153, Q = 1.86},
    {name = "eq", gain = -5.5, frequency = 19938, Q = 0.29},
}
