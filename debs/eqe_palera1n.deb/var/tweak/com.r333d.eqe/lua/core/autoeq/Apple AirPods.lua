return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 33, Q = 0.41},
    {name = "eq", gain = 3.5, frequency = 1765, Q = 0.19},
    {name = "eq", gain = -7.1, frequency = 2034, Q = 0.86},
    {name = "eq", gain = -2.6, frequency = 9552, Q = 0.29},
    {name = "eq", gain = 2.6, frequency = 19050, Q = 0.48},
    {name = "eq", gain = 0.9, frequency = 60, Q = 5.14},
    {name = "eq", gain = -1.4, frequency = 2887, Q = 4.93},
    {name = "eq", gain = 1.3, frequency = 3998, Q = 1.57},
    {name = "eq", gain = -3.4, frequency = 5490, Q = 3.51},
    {name = "eq", gain = 2.9, frequency = 6577, Q = 4.97},
}
