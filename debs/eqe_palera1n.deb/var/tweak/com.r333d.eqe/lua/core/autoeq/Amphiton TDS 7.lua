return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.8, frequency = 29, Q = 0.84},
    {name = "eq", gain = -2.0, frequency = 309, Q = 0.97},
    {name = "eq", gain = -7.7, frequency = 1608, Q = 1.05},
    {name = "eq", gain = -6.2, frequency = 3273, Q = 1.97},
    {name = "eq", gain = 7.2, frequency = 5632, Q = 0.27},
    {name = "eq", gain = -1.1, frequency = 31, Q = 2.81},
    {name = "eq", gain = 1.9, frequency = 46, Q = 2.22},
    {name = "eq", gain = -2.3, frequency = 74, Q = 3.06},
    {name = "eq", gain = -0.3, frequency = 1230, Q = 4.20},
    {name = "eq", gain = 0.9, frequency = 5059, Q = 5.42},
}
