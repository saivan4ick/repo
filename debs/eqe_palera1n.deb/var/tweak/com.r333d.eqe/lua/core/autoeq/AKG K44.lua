return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 5.5, frequency = 21, Q = 1.69},
    {name = "eq", gain = -4.5, frequency = 239, Q = 0.29},
    {name = "eq", gain = -6.0, frequency = 1155, Q = 2.21},
    {name = "eq", gain = 5.4, frequency = 2248, Q = 1.13},
    {name = "eq", gain = 4.4, frequency = 4113, Q = 1.15},
    {name = "eq", gain = -2.7, frequency = 5025, Q = 5.52},
    {name = "eq", gain = 2.3, frequency = 5638, Q = 6.25},
    {name = "eq", gain = 2.1, frequency = 6962, Q = 1.03},
    {name = "eq", gain = -2.8, frequency = 10906, Q = 0.71},
    {name = "eq", gain = 1.6, frequency = 19633, Q = 0.86},
}
