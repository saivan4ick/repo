return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = 7.0, frequency = 29, Q = 1.21},
    {name = "eq", gain = 6.3, frequency = 1226, Q = 1.60},
    {name = "eq", gain = 8.1, frequency = 3443, Q = 1.47},
    {name = "eq", gain = -8.2, frequency = 6397, Q = 1.04},
    {name = "eq", gain = 6.8, frequency = 17940, Q = 0.39},
    {name = "eq", gain = 5.5, frequency = 57, Q = 1.14},
    {name = "eq", gain = -6.7, frequency = 137, Q = 0.42},
    {name = "eq", gain = 2.6, frequency = 751, Q = 2.00},
    {name = "eq", gain = 0.9, frequency = 5582, Q = 0.91},
    {name = "eq", gain = -0.9, frequency = 5670, Q = 0.94},
}
