return {
    {name = "preamp", gain = -4.3},
    {name = "eq", gain = -1.4, frequency = 28, Q = 0.91},
    {name = "eq", gain = -5.7, frequency = 69, Q = 0.60},
    {name = "eq", gain = 4.0, frequency = 4008, Q = 2.44},
    {name = "eq", gain = 2.8, frequency = 7949, Q = 4.23},
    {name = "eq", gain = -4.6, frequency = 19867, Q = 0.31},
    {name = "eq", gain = -1.5, frequency = 431, Q = 1.78},
    {name = "eq", gain = 1.4, frequency = 990, Q = 1.45},
    {name = "eq", gain = 1.6, frequency = 4985, Q = 4.36},
    {name = "eq", gain = -4.1, frequency = 6012, Q = 4.06},
    {name = "eq", gain = 1.9, frequency = 6807, Q = 3.81},
}
