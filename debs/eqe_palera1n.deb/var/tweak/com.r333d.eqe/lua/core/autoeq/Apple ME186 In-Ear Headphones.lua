return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 0.9, frequency = 34, Q = 1.13},
    {name = "eq", gain = -4.5, frequency = 220, Q = 0.52},
    {name = "eq", gain = 2.9, frequency = 1970, Q = 2.45},
    {name = "eq", gain = 6.5, frequency = 5980, Q = 1.13},
    {name = "eq", gain = 0.6, frequency = 850, Q = 3.68},
    {name = "eq", gain = -1.9, frequency = 3017, Q = 5.71},
    {name = "eq", gain = 1.3, frequency = 3675, Q = 4.38},
    {name = "eq", gain = 1.7, frequency = 10483, Q = 1.42},
    {name = "eq", gain = -7.0, frequency = 19543, Q = 0.42},
}
