return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = -2.7, frequency = 255, Q = 1.08},
    {name = "eq", gain = -6.3, frequency = 1139, Q = 1.24},
    {name = "eq", gain = 7.2, frequency = 1869, Q = 3.09},
    {name = "eq", gain = 3.9, frequency = 3619, Q = 5.10},
    {name = "eq", gain = 2.7, frequency = 3833, Q = 4.84},
    {name = "eq", gain = 1.7, frequency = 18, Q = 1.82},
    {name = "eq", gain = 2.0, frequency = 481, Q = 5.79},
    {name = "eq", gain = 0.9, frequency = 2140, Q = 8.49},
    {name = "eq", gain = 6.8, frequency = 8753, Q = 1.34},
    {name = "eq", gain = -19.6, frequency = 19501, Q = 0.31},
}
