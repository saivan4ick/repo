return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 5.5, frequency = 30, Q = 0.46},
    {name = "eq", gain = 1.3, frequency = 347, Q = 0.07},
    {name = "eq", gain = 2.5, frequency = 709, Q = 1.61},
    {name = "eq", gain = -6.8, frequency = 1942, Q = 1.62},
    {name = "eq", gain = -6.2, frequency = 5209, Q = 3.11},
    {name = "eq", gain = 1.2, frequency = 61, Q = 5.42},
    {name = "eq", gain = -2.1, frequency = 2512, Q = 4.76},
    {name = "eq", gain = 2.6, frequency = 3376, Q = 2.35},
    {name = "eq", gain = -1.1, frequency = 4450, Q = 2.88},
    {name = "eq", gain = -6.0, frequency = 19461, Q = 0.64},
}
