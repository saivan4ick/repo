return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 2.0, frequency = 23, Q = 0.95},
    {name = "eq", gain = -4.1, frequency = 171, Q = 0.77},
    {name = "eq", gain = 5.7, frequency = 3829, Q = 1.98},
    {name = "eq", gain = -5.8, frequency = 5751, Q = 4.40},
    {name = "eq", gain = 4.8, frequency = 17009, Q = 0.23},
    {name = "eq", gain = -2.7, frequency = 344, Q = 1.17},
    {name = "eq", gain = 3.2, frequency = 766, Q = 0.41},
    {name = "eq", gain = -3.2, frequency = 1734, Q = 1.05},
    {name = "eq", gain = 0.9, frequency = 2927, Q = 3.77},
    {name = "eq", gain = -0.6, frequency = 7856, Q = 5.55},
}
