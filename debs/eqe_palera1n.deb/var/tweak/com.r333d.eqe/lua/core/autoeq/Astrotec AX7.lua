return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.5, frequency = 31, Q = 0.33},
    {name = "eq", gain = -3.5, frequency = 310, Q = 0.26},
    {name = "eq", gain = 6.6, frequency = 3487, Q = 1.82},
    {name = "eq", gain = 3.1, frequency = 9249, Q = 1.86},
    {name = "eq", gain = 4.6, frequency = 11282, Q = 2.10},
    {name = "eq", gain = 1.2, frequency = 884, Q = 1.94},
    {name = "eq", gain = -1.2, frequency = 1357, Q = 1.97},
    {name = "eq", gain = 1.4, frequency = 5476, Q = 5.35},
    {name = "eq", gain = 2.4, frequency = 14086, Q = 1.56},
    {name = "eq", gain = -8.5, frequency = 19927, Q = 0.55},
}
