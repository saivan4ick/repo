return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.9, frequency = 32, Q = 0.49},
    {name = "eq", gain = -6.1, frequency = 228, Q = 0.51},
    {name = "eq", gain = 6.2, frequency = 3769, Q = 1.36},
    {name = "eq", gain = 3.8, frequency = 10933, Q = 1.12},
    {name = "eq", gain = 6.1, frequency = 18628, Q = 0.36},
    {name = "eq", gain = 1.4, frequency = 945, Q = 2.99},
    {name = "eq", gain = -1.4, frequency = 1465, Q = 3.76},
    {name = "eq", gain = 3.1, frequency = 5347, Q = 4.65},
    {name = "eq", gain = -5.4, frequency = 6349, Q = 4.26},
    {name = "eq", gain = 2.4, frequency = 7510, Q = 3.60},
}
