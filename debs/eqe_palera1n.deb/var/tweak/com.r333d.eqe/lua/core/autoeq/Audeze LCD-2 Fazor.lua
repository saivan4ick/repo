return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 3.5, frequency = 11, Q = 0.33},
    {name = "eq", gain = -2.4, frequency = 193, Q = 1.10},
    {name = "eq", gain = -2.4, frequency = 968, Q = 0.48},
    {name = "eq", gain = 3.5, frequency = 2285, Q = 2.12},
    {name = "eq", gain = 6.7, frequency = 4281, Q = 2.54},
    {name = "eq", gain = -0.1, frequency = 117, Q = 2.97},
    {name = "eq", gain = 2.3, frequency = 7258, Q = 5.70},
    {name = "eq", gain = 1.9, frequency = 10529, Q = 1.53},
    {name = "eq", gain = -5.1, frequency = 19113, Q = 0.27},
    {name = "eq", gain = -6.6, frequency = 19894, Q = 0.43},
}
