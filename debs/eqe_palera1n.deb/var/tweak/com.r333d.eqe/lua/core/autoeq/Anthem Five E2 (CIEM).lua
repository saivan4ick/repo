return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -5.9, frequency = 16, Q = 0.35},
    {name = "eq", gain = -7.5, frequency = 134, Q = 0.31},
    {name = "eq", gain = 2.6, frequency = 623, Q = 0.76},
    {name = "eq", gain = 2.0, frequency = 968, Q = 1.93},
    {name = "eq", gain = 6.6, frequency = 15488, Q = 0.20},
    {name = "eq", gain = -0.6, frequency = 1875, Q = 2.35},
    {name = "eq", gain = 3.0, frequency = 3082, Q = 2.29},
    {name = "eq", gain = -6.2, frequency = 4049, Q = 3.38},
    {name = "eq", gain = 2.4, frequency = 6296, Q = 2.08},
    {name = "eq", gain = -0.7, frequency = 15083, Q = 1.27},
}
