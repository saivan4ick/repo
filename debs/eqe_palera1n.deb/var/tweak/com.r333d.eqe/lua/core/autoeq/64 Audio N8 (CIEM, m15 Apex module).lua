return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -2.7, frequency = 15, Q = 0.57},
    {name = "eq", gain = -4.1, frequency = 76, Q = 0.45},
    {name = "eq", gain = -3.3, frequency = 249, Q = 0.69},
    {name = "eq", gain = 4.6, frequency = 3441, Q = 2.15},
    {name = "eq", gain = 6.5, frequency = 7356, Q = 1.11},
    {name = "eq", gain = 2.1, frequency = 984, Q = 1.97},
    {name = "eq", gain = -2.0, frequency = 1497, Q = 1.08},
    {name = "eq", gain = 1.2, frequency = 2672, Q = 2.95},
    {name = "eq", gain = 1.9, frequency = 11003, Q = 1.50},
    {name = "eq", gain = -7.2, frequency = 19588, Q = 0.45},
}
