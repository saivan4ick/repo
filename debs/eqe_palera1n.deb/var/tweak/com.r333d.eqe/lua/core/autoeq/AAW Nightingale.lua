return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = 5.0, frequency = 18, Q = 0.40},
    {name = "eq", gain = -6.4, frequency = 780, Q = 0.20},
    {name = "eq", gain = 7.8, frequency = 2614, Q = 1.32},
    {name = "eq", gain = 6.8, frequency = 7140, Q = 0.41},
    {name = "eq", gain = -2.0, frequency = 1349, Q = 2.02},
    {name = "eq", gain = 0.9, frequency = 1374, Q = 0.77},
    {name = "eq", gain = 0.8, frequency = 5012, Q = 1.73},
    {name = "eq", gain = -2.5, frequency = 6995, Q = 5.21},
    {name = "eq", gain = 1.7, frequency = 12097, Q = 3.32},
}
