return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = 5.2, frequency = 18, Q = 0.56},
    {name = "eq", gain = -2.9, frequency = 287, Q = 0.48},
    {name = "eq", gain = -1.1, frequency = 1815, Q = 2.46},
    {name = "eq", gain = 7.2, frequency = 3794, Q = 1.73},
    {name = "eq", gain = -0.4, frequency = 523, Q = 3.15},
    {name = "eq", gain = 2.0, frequency = 5223, Q = 3.06},
    {name = "eq", gain = 1.8, frequency = 6392, Q = 0.93},
    {name = "eq", gain = -7.5, frequency = 19092, Q = 0.17},
    {name = "eq", gain = -6.8, frequency = 19891, Q = 0.28},
}
