return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -4.2, frequency = 253, Q = 0.79},
    {name = "eq", gain = 3.7, frequency = 588, Q = 2.32},
    {name = "eq", gain = 6.0, frequency = 4400, Q = 2.75},
    {name = "eq", gain = 3.5, frequency = 11638, Q = 1.58},
    {name = "eq", gain = 4.8, frequency = 17922, Q = 0.48},
    {name = "eq", gain = 1.4, frequency = 27, Q = 1.04},
    {name = "eq", gain = 1.8, frequency = 1370, Q = 2.98},
    {name = "eq", gain = -2.6, frequency = 2487, Q = 3.92},
    {name = "eq", gain = 3.0, frequency = 5582, Q = 4.89},
    {name = "eq", gain = -3.2, frequency = 6603, Q = 4.31},
}
