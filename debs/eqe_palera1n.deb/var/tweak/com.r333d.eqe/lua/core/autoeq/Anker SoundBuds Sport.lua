return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 13.1, frequency = 31, Q = 0.74},
    {name = "eq", gain = -11.2, frequency = 109, Q = 0.27},
    {name = "eq", gain = 3.0, frequency = 777, Q = 1.36},
    {name = "eq", gain = 5.5, frequency = 2555, Q = 0.63},
    {name = "eq", gain = 4.1, frequency = 6137, Q = 1.14},
    {name = "eq", gain = -2.9, frequency = 28, Q = 2.58},
    {name = "eq", gain = 2.1, frequency = 33, Q = 0.50},
    {name = "eq", gain = -2.3, frequency = 65, Q = 1.60},
    {name = "eq", gain = 1.2, frequency = 8322, Q = 4.84},
    {name = "eq", gain = -0.7, frequency = 16138, Q = 0.38},
}
