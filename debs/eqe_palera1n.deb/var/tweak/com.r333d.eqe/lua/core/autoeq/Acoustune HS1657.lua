return {
    {name = "preamp", gain = -5.1},
    {name = "eq", gain = -3.7, frequency = 66, Q = 0.39},
    {name = "eq", gain = -8.7, frequency = 2359, Q = 1.63},
    {name = "eq", gain = 8.6, frequency = 3257, Q = 0.80},
    {name = "eq", gain = -8.7, frequency = 5310, Q = 4.81},
    {name = "eq", gain = 2.7, frequency = 9488, Q = 3.57},
    {name = "eq", gain = -0.9, frequency = 18, Q = 1.68},
    {name = "eq", gain = 1.6, frequency = 424, Q = 1.97},
    {name = "eq", gain = -1.0, frequency = 1548, Q = 4.49},
    {name = "eq", gain = 3.3, frequency = 11912, Q = 0.98},
    {name = "eq", gain = -13.4, frequency = 19680, Q = 0.39},
}
