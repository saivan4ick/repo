return {
    {name = "preamp", gain = -5.6},
    {name = "eq", gain = -7.3, frequency = 21, Q = 0.24},
    {name = "eq", gain = -3.7, frequency = 146, Q = 1.33},
    {name = "eq", gain = 1.4, frequency = 492, Q = 0.54},
    {name = "eq", gain = 2.0, frequency = 2347, Q = 3.73},
    {name = "eq", gain = 5.3, frequency = 5416, Q = 2.42},
    {name = "eq", gain = 1.0, frequency = 922, Q = 3.81},
    {name = "eq", gain = -1.1, frequency = 1415, Q = 4.08},
    {name = "eq", gain = -1.3, frequency = 3444, Q = 6.14},
    {name = "eq", gain = -1.8, frequency = 11178, Q = 1.97},
    {name = "eq", gain = 4.8, frequency = 19724, Q = 0.56},
}
