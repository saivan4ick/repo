return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 5.9, frequency = 25, Q = 0.61},
    {name = "eq", gain = 2.8, frequency = 63, Q = 1.41},
    {name = "eq", gain = -3.4, frequency = 2325, Q = 2.19},
    {name = "eq", gain = -2.5, frequency = 6103, Q = 5.98},
    {name = "eq", gain = 2.4, frequency = 10074, Q = 3.00},
    {name = "eq", gain = 1.8, frequency = 656, Q = 2.13},
    {name = "eq", gain = 1.0, frequency = 1253, Q = 2.99},
    {name = "eq", gain = -1.3, frequency = 1722, Q = 4.08},
    {name = "eq", gain = 1.9, frequency = 4408, Q = 5.68},
    {name = "eq", gain = -7.7, frequency = 19327, Q = 0.78},
}
