return {
    {name = "preamp", gain = -5.2},
    {name = "eq", gain = -3.5, frequency = 180, Q = 0.52},
    {name = "eq", gain = 3.5, frequency = 2777, Q = 3.22},
    {name = "eq", gain = 2.8, frequency = 3688, Q = 1.64},
    {name = "eq", gain = 2.9, frequency = 5845, Q = 3.07},
    {name = "eq", gain = 4.0, frequency = 9138, Q = 3.02},
    {name = "eq", gain = 1.0, frequency = 20, Q = 1.29},
    {name = "eq", gain = 1.1, frequency = 933, Q = 2.92},
    {name = "eq", gain = -0.7, frequency = 1339, Q = 3.98},
    {name = "eq", gain = 3.1, frequency = 11607, Q = 1.16},
    {name = "eq", gain = -12.0, frequency = 19603, Q = 0.39},
}
