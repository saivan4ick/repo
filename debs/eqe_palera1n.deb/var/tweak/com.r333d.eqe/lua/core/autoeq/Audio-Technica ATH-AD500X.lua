return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.5, frequency = 24, Q = 1.72},
    {name = "eq", gain = 6.2, frequency = 2917, Q = 2.58},
    {name = "eq", gain = 4.3, frequency = 5976, Q = 1.64},
    {name = "eq", gain = 5.1, frequency = 9522, Q = 1.37},
    {name = "eq", gain = 4.5, frequency = 22050, Q = 2.28},
    {name = "eq", gain = -3.2, frequency = 143, Q = 1.06},
    {name = "eq", gain = -3.4, frequency = 292, Q = 0.66},
    {name = "eq", gain = -4.5, frequency = 1229, Q = 0.89},
    {name = "eq", gain = 5.0, frequency = 2296, Q = 1.87},
    {name = "eq", gain = -2.8, frequency = 2731, Q = 5.02},
}
