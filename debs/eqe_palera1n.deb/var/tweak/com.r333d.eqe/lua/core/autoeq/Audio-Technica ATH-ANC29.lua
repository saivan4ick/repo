return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -3.5, frequency = 508, Q = 0.36},
    {name = "eq", gain = -7.3, frequency = 1247, Q = 3.67},
    {name = "eq", gain = 2.5, frequency = 1890, Q = 2.45},
    {name = "eq", gain = 8.7, frequency = 5405, Q = 0.52},
    {name = "eq", gain = -12.1, frequency = 6337, Q = 2.25},
    {name = "eq", gain = -2.1, frequency = 761, Q = 2.94},
    {name = "eq", gain = 4.1, frequency = 914, Q = 3.96},
    {name = "eq", gain = -1.6, frequency = 1055, Q = 3.71},
    {name = "eq", gain = 1.5, frequency = 4214, Q = 3.73},
    {name = "eq", gain = -1.6, frequency = 4940, Q = 4.79},
}
