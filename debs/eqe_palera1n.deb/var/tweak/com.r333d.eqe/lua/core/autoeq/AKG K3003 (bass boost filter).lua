return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -7.1, frequency = 202, Q = 0.51},
    {name = "eq", gain = 3.9, frequency = 1344, Q = 0.57},
    {name = "eq", gain = 4.9, frequency = 3530, Q = 2.31},
    {name = "eq", gain = 5.4, frequency = 11357, Q = 0.95},
    {name = "eq", gain = 4.1, frequency = 22050, Q = 1.87},
    {name = "eq", gain = 3.1, frequency = 20, Q = 1.53},
    {name = "eq", gain = -1.7, frequency = 3658, Q = 5.50},
    {name = "eq", gain = 2.4, frequency = 4277, Q = 2.40},
    {name = "eq", gain = -4.5, frequency = 5358, Q = 4.08},
    {name = "eq", gain = 1.7, frequency = 6437, Q = 3.83},
}
