return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.0, frequency = 52, Q = 0.06},
    {name = "eq", gain = -7.6, frequency = 882, Q = 1.45},
    {name = "eq", gain = -11.4, frequency = 2672, Q = 1.04},
    {name = "eq", gain = -12.3, frequency = 4307, Q = 1.86},
    {name = "eq", gain = 7.9, frequency = 11072, Q = 0.19},
    {name = "eq", gain = -1.9, frequency = 2125, Q = 8.41},
    {name = "eq", gain = 2.0, frequency = 4474, Q = 5.91},
    {name = "eq", gain = -6.7, frequency = 5370, Q = 4.18},
    {name = "eq", gain = 5.8, frequency = 6355, Q = 2.79},
    {name = "eq", gain = -1.5, frequency = 13203, Q = 1.18},
}
