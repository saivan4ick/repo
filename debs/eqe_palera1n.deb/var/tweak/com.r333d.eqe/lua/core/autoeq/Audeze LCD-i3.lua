return {
    {name = "preamp", gain = -7.6},
    {name = "eq", gain = 4.1, frequency = 29, Q = 0.19},
    {name = "eq", gain = -5.3, frequency = 1248, Q = 0.97},
    {name = "eq", gain = -5.5, frequency = 1584, Q = 0.11},
    {name = "eq", gain = 12.2, frequency = 2839, Q = 0.84},
    {name = "eq", gain = 7.0, frequency = 6266, Q = 1.09},
    {name = "eq", gain = -1.7, frequency = 110, Q = 0.64},
    {name = "eq", gain = -3.7, frequency = 838, Q = 2.53},
    {name = "eq", gain = 2.9, frequency = 1139, Q = 0.97},
    {name = "eq", gain = -3.7, frequency = 1485, Q = 3.13},
    {name = "eq", gain = -4.3, frequency = 18824, Q = 0.39},
}
