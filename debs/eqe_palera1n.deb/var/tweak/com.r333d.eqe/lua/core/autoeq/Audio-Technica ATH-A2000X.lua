return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 6.2, frequency = 23, Q = 1.46},
    {name = "eq", gain = 3.3, frequency = 45, Q = 3.63},
    {name = "eq", gain = -5.8, frequency = 1486, Q = 1.35},
    {name = "eq", gain = -3.2, frequency = 4551, Q = 8.28},
    {name = "eq", gain = 7.1, frequency = 7535, Q = 2.19},
    {name = "eq", gain = -1.8, frequency = 104, Q = 1.32},
    {name = "eq", gain = 2.0, frequency = 257, Q = 1.85},
    {name = "eq", gain = 3.2, frequency = 3425, Q = 5.91},
    {name = "eq", gain = 4.8, frequency = 10464, Q = 1.19},
    {name = "eq", gain = -16.3, frequency = 19507, Q = 0.34},
}
