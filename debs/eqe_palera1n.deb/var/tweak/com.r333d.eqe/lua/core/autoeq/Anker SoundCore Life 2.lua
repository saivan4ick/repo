return {
    {name = "preamp", gain = -3.9},
    {name = "eq", gain = -6.8, frequency = 20, Q = 0.82},
    {name = "eq", gain = -7.6, frequency = 69, Q = 0.75},
    {name = "eq", gain = 4.5, frequency = 300, Q = 1.91},
    {name = "eq", gain = -4.8, frequency = 10023, Q = 1.38},
    {name = "eq", gain = 2.3, frequency = 18851, Q = 0.00},
    {name = "eq", gain = -0.9, frequency = 122, Q = 2.30},
    {name = "eq", gain = -0.9, frequency = 275, Q = 1.95},
    {name = "eq", gain = -2.4, frequency = 691, Q = 0.76},
    {name = "eq", gain = -1.4, frequency = 1642, Q = 2.19},
    {name = "eq", gain = -1.3, frequency = 7318, Q = 3.30},
}
