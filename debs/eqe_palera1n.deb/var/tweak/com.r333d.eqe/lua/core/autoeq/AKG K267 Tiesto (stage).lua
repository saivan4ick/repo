return {
    {name = "preamp", gain = -5.4},
    {name = "eq", gain = -3.2, frequency = 33, Q = 0.44},
    {name = "eq", gain = -4.1, frequency = 174, Q = 1.16},
    {name = "eq", gain = -4.6, frequency = 1433, Q = 1.90},
    {name = "eq", gain = 4.3, frequency = 4065, Q = 4.76},
    {name = "eq", gain = 1.4, frequency = 8089, Q = 0.00},
    {name = "eq", gain = -0.9, frequency = 34, Q = 0.06},
    {name = "eq", gain = 4.8, frequency = 367, Q = 2.69},
    {name = "eq", gain = -1.7, frequency = 383, Q = 0.74},
    {name = "eq", gain = -2.7, frequency = 6001, Q = 2.22},
    {name = "eq", gain = 4.7, frequency = 6490, Q = 4.46},
}
