return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.3, frequency = 26, Q = 0.76},
    {name = "eq", gain = -8.0, frequency = 2310, Q = 2.03},
    {name = "eq", gain = 5.2, frequency = 2597, Q = 0.63},
    {name = "eq", gain = -6.5, frequency = 5699, Q = 2.67},
    {name = "eq", gain = 4.7, frequency = 10473, Q = 2.43},
    {name = "eq", gain = 1.7, frequency = 104, Q = 3.81},
    {name = "eq", gain = -2.4, frequency = 215, Q = 1.10},
    {name = "eq", gain = -0.6, frequency = 401, Q = 1.76},
    {name = "eq", gain = 1.1, frequency = 714, Q = 1.92},
    {name = "eq", gain = -0.2, frequency = 7374, Q = 2.43},
}
