return {
    {name = "preamp", gain = -5.4},
    {name = "eq", gain = -3.9, frequency = 66, Q = 0.48},
    {name = "eq", gain = -4.1, frequency = 197, Q = 0.58},
    {name = "eq", gain = 5.0, frequency = 1081, Q = 0.77},
    {name = "eq", gain = 3.4, frequency = 2339, Q = 1.84},
    {name = "eq", gain = 4.8, frequency = 11371, Q = 2.26},
    {name = "eq", gain = 0.7, frequency = 4269, Q = 1.53},
    {name = "eq", gain = 2.0, frequency = 4633, Q = 2.69},
    {name = "eq", gain = -5.7, frequency = 5807, Q = 2.37},
    {name = "eq", gain = 0.6, frequency = 8902, Q = 3.05},
    {name = "eq", gain = 1.4, frequency = 9518, Q = 4.23},
}
