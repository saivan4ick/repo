return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -5.5, frequency = 182, Q = 0.52},
    {name = "eq", gain = -4.9, frequency = 1646, Q = 2.68},
    {name = "eq", gain = 3.8, frequency = 2479, Q = 1.78},
    {name = "eq", gain = 5.0, frequency = 4025, Q = 0.83},
    {name = "eq", gain = 5.8, frequency = 11126, Q = 1.64},
    {name = "eq", gain = 1.2, frequency = 23, Q = 1.38},
    {name = "eq", gain = -2.2, frequency = 5602, Q = 5.64},
    {name = "eq", gain = 3.3, frequency = 6418, Q = 3.64},
    {name = "eq", gain = -2.4, frequency = 7409, Q = 3.36},
    {name = "eq", gain = 1.1, frequency = 9384, Q = 5.76},
}
