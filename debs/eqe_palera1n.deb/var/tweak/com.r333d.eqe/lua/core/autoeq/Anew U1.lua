return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -5.7, frequency = 61, Q = 0.19},
    {name = "eq", gain = -15.3, frequency = 1811, Q = 1.28},
    {name = "eq", gain = 13.1, frequency = 2449, Q = 0.42},
    {name = "eq", gain = -9.6, frequency = 5544, Q = 2.09},
    {name = "eq", gain = 2.0, frequency = 10559, Q = 3.53},
    {name = "eq", gain = -2.5, frequency = 1293, Q = 2.59},
    {name = "eq", gain = 1.6, frequency = 1372, Q = 0.76},
    {name = "eq", gain = -2.7, frequency = 2230, Q = 4.77},
    {name = "eq", gain = 0.7, frequency = 2660, Q = 3.03},
    {name = "eq", gain = -7.6, frequency = 19542, Q = 0.85},
}
