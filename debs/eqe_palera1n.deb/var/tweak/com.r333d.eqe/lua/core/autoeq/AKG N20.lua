return {
    {name = "preamp", gain = -5.5},
    {name = "eq", gain = -2.4, frequency = 72, Q = 0.86},
    {name = "eq", gain = -4.1, frequency = 179, Q = 0.58},
    {name = "eq", gain = 3.8, frequency = 905, Q = 0.64},
    {name = "eq", gain = 5.4, frequency = 4202, Q = 2.64},
    {name = "eq", gain = -5.8, frequency = 5895, Q = 4.35},
    {name = "eq", gain = 1.4, frequency = 2008, Q = 2.87},
    {name = "eq", gain = -2.7, frequency = 2707, Q = 3.37},
    {name = "eq", gain = 1.7, frequency = 3387, Q = 6.16},
    {name = "eq", gain = 1.2, frequency = 5136, Q = 6.00},
    {name = "eq", gain = -6.7, frequency = 19554, Q = 0.53},
}
