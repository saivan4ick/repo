return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = 6.1, frequency = 33, Q = 0.20},
    {name = "eq", gain = -6.9, frequency = 1629, Q = 1.99},
    {name = "eq", gain = -7.9, frequency = 2960, Q = 2.25},
    {name = "eq", gain = 8.2, frequency = 4544, Q = 2.03},
    {name = "eq", gain = 6.8, frequency = 17791, Q = 0.47},
    {name = "eq", gain = -2.2, frequency = 434, Q = 0.42},
    {name = "eq", gain = 3.5, frequency = 490, Q = 0.75},
    {name = "eq", gain = 2.6, frequency = 5788, Q = 5.74},
    {name = "eq", gain = -2.2, frequency = 7644, Q = 2.26},
    {name = "eq", gain = 1.2, frequency = 13561, Q = 2.06},
}
