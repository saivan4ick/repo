return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 6.2, frequency = 19, Q = 0.53},
    {name = "eq", gain = -2.7, frequency = 227, Q = 0.89},
    {name = "eq", gain = 2.7, frequency = 1076, Q = 2.42},
    {name = "eq", gain = 5.1, frequency = 3477, Q = 4.04},
    {name = "eq", gain = 3.4, frequency = 11080, Q = 2.80},
    {name = "eq", gain = -3.7, frequency = 2280, Q = 3.59},
    {name = "eq", gain = 1.7, frequency = 2612, Q = 1.25},
    {name = "eq", gain = 2.7, frequency = 4523, Q = 3.46},
    {name = "eq", gain = -3.4, frequency = 5571, Q = 1.56},
    {name = "eq", gain = 1.4, frequency = 9423, Q = 3.91},
}
