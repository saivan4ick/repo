return {
    {name = "preamp", gain = -4.4},
    {name = "eq", gain = -6.6, frequency = 21, Q = 0.62},
    {name = "eq", gain = -4.8, frequency = 62, Q = 0.92},
    {name = "eq", gain = -5.3, frequency = 149, Q = 1.93},
    {name = "eq", gain = 2.2, frequency = 985, Q = 0.88},
    {name = "eq", gain = 3.5, frequency = 2079, Q = 2.16},
    {name = "eq", gain = 1.7, frequency = 111, Q = 10.86},
    {name = "eq", gain = -0.7, frequency = 220, Q = 5.16},
    {name = "eq", gain = 0.4, frequency = 1583, Q = 3.97},
    {name = "eq", gain = 2.1, frequency = 6788, Q = 2.40},
    {name = "eq", gain = -7.3, frequency = 19410, Q = 0.22},
}
