return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -3.0, frequency = 110, Q = 0.19},
    {name = "eq", gain = 6.4, frequency = 3365, Q = 2.54},
    {name = "eq", gain = 2.9, frequency = 5954, Q = 2.72},
    {name = "eq", gain = 4.9, frequency = 10140, Q = 1.10},
    {name = "eq", gain = -12.3, frequency = 19678, Q = 0.41},
    {name = "eq", gain = 0.7, frequency = 19, Q = 1.82},
    {name = "eq", gain = 0.5, frequency = 1088, Q = 0.20},
    {name = "eq", gain = -2.2, frequency = 1846, Q = 1.02},
    {name = "eq", gain = -0.1, frequency = 2194, Q = 1.56},
    {name = "eq", gain = 2.2, frequency = 2737, Q = 4.71},
}
