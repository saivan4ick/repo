return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -3.9, frequency = 18, Q = 0.61},
    {name = "eq", gain = -3.2, frequency = 295, Q = 0.66},
    {name = "eq", gain = -3.2, frequency = 1694, Q = 1.77},
    {name = "eq", gain = 4.4, frequency = 3378, Q = 1.78},
    {name = "eq", gain = 6.4, frequency = 7009, Q = 1.59},
    {name = "eq", gain = 0.6, frequency = 934, Q = 4.83},
    {name = "eq", gain = 1.4, frequency = 9616, Q = 2.62},
    {name = "eq", gain = 1.8, frequency = 11313, Q = 1.17},
    {name = "eq", gain = -4.8, frequency = 19483, Q = 0.27},
    {name = "eq", gain = -6.0, frequency = 19792, Q = 0.43},
}
