return {
    {name = "preamp", gain = -5.9},
    {name = "eq", gain = 8.7, frequency = 2022, Q = 2.30},
    {name = "eq", gain = -7.1, frequency = 2974, Q = 0.32},
    {name = "eq", gain = 8.5, frequency = 3748, Q = 2.45},
    {name = "eq", gain = 11.6, frequency = 9668, Q = 0.86},
    {name = "eq", gain = -19.1, frequency = 19626, Q = 0.42},
    {name = "eq", gain = 2.1, frequency = 20, Q = 0.33},
    {name = "eq", gain = -1.6, frequency = 183, Q = 1.24},
    {name = "eq", gain = 3.1, frequency = 5426, Q = 5.80},
    {name = "eq", gain = -4.4, frequency = 6159, Q = 3.70},
    {name = "eq", gain = 3.0, frequency = 7149, Q = 5.23},
}
