return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -2.8, frequency = 14, Q = 0.26},
    {name = "eq", gain = -3.0, frequency = 343, Q = 0.29},
    {name = "eq", gain = -3.4, frequency = 712, Q = 1.79},
    {name = "eq", gain = 5.9, frequency = 1149, Q = 1.47},
    {name = "eq", gain = 6.5, frequency = 3822, Q = 1.73},
    {name = "eq", gain = 2.0, frequency = 8552, Q = 0.80},
    {name = "eq", gain = 1.3, frequency = 11098, Q = 1.77},
    {name = "eq", gain = -6.9, frequency = 19150, Q = 0.24},
    {name = "eq", gain = -7.2, frequency = 19725, Q = 0.53},
}
