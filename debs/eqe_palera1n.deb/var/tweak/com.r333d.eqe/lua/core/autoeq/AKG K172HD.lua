return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.5, frequency = 39, Q = 0.35},
    {name = "eq", gain = -4.1, frequency = 1961, Q = 1.33},
    {name = "eq", gain = -2.2, frequency = 3358, Q = 3.59},
    {name = "eq", gain = 3.8, frequency = 4607, Q = 3.83},
    {name = "eq", gain = 2.2, frequency = 7177, Q = 3.43},
    {name = "eq", gain = -0.6, frequency = 43, Q = 2.18},
    {name = "eq", gain = 1.8, frequency = 92, Q = 2.51},
    {name = "eq", gain = -3.1, frequency = 174, Q = 1.96},
    {name = "eq", gain = 2.8, frequency = 237, Q = 1.35},
    {name = "eq", gain = -2.6, frequency = 321, Q = 2.61},
}
