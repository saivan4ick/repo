return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 31, Q = 0.47},
    {name = "eq", gain = 6.5, frequency = 522, Q = 1.07},
    {name = "eq", gain = -4.0, frequency = 1127, Q = 1.36},
    {name = "eq", gain = -6.1, frequency = 6751, Q = 1.70},
    {name = "eq", gain = -9.6, frequency = 19516, Q = 0.19},
    {name = "eq", gain = -2.3, frequency = 801, Q = 4.00},
    {name = "eq", gain = 1.3, frequency = 952, Q = 1.13},
    {name = "eq", gain = -2.5, frequency = 1671, Q = 2.14},
    {name = "eq", gain = 3.7, frequency = 3358, Q = 1.30},
    {name = "eq", gain = -4.2, frequency = 4887, Q = 3.72},
}
