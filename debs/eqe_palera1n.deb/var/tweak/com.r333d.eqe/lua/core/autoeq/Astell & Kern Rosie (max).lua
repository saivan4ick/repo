return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -6.0, frequency = 20, Q = 0.25},
    {name = "eq", gain = -5.8, frequency = 114, Q = 0.59},
    {name = "eq", gain = -4.7, frequency = 269, Q = 0.94},
    {name = "eq", gain = 5.8, frequency = 3647, Q = 0.48},
    {name = "eq", gain = 3.8, frequency = 14697, Q = 0.52},
    {name = "eq", gain = 2.2, frequency = 994, Q = 2.45},
    {name = "eq", gain = -1.6, frequency = 1442, Q = 2.21},
    {name = "eq", gain = 1.9, frequency = 6372, Q = 3.17},
    {name = "eq", gain = -2.6, frequency = 8142, Q = 1.97},
    {name = "eq", gain = 2.0, frequency = 10360, Q = 2.90},
}
