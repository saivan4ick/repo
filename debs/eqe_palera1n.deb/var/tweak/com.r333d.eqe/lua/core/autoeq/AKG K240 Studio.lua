return {
    {name = "preamp", gain = -7.5},
    {name = "eq", gain = 6.9, frequency = 34, Q = 0.65},
    {name = "eq", gain = 5.4, frequency = 1600, Q = 4.06},
    {name = "eq", gain = 4.4, frequency = 3847, Q = 4.62},
    {name = "eq", gain = 3.6, frequency = 4936, Q = 4.17},
    {name = "eq", gain = 7.1, frequency = 18618, Q = 0.93},
    {name = "eq", gain = 2.4, frequency = 74, Q = 1.74},
    {name = "eq", gain = -3.2, frequency = 244, Q = 0.63},
    {name = "eq", gain = -2.3, frequency = 800, Q = 3.15},
    {name = "eq", gain = -2.6, frequency = 9165, Q = 1.71},
    {name = "eq", gain = 1.6, frequency = 15924, Q = 2.25},
}
