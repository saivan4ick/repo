return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = 2.3, frequency = 16, Q = 0.85},
    {name = "eq", gain = -1.5, frequency = 81, Q = 0.91},
    {name = "eq", gain = -4.2, frequency = 237, Q = 0.54},
    {name = "eq", gain = 4.6, frequency = 3426, Q = 2.59},
    {name = "eq", gain = 6.7, frequency = 7623, Q = 1.08},
    {name = "eq", gain = 1.6, frequency = 954, Q = 1.95},
    {name = "eq", gain = -2.2, frequency = 1599, Q = 1.41},
    {name = "eq", gain = 1.4, frequency = 2708, Q = 3.70},
    {name = "eq", gain = 2.0, frequency = 11511, Q = 1.47},
    {name = "eq", gain = -7.7, frequency = 19810, Q = 0.45},
}
