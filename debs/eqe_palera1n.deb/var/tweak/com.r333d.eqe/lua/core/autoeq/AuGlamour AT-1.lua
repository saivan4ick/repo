return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 7.2, frequency = 18, Q = 0.54},
    {name = "eq", gain = -7.8, frequency = 209, Q = 0.28},
    {name = "eq", gain = 4.6, frequency = 944, Q = 1.10},
    {name = "eq", gain = 2.9, frequency = 3626, Q = 1.57},
    {name = "eq", gain = 6.2, frequency = 15626, Q = 0.12},
    {name = "eq", gain = -0.9, frequency = 2537, Q = 3.32},
    {name = "eq", gain = 0.6, frequency = 2950, Q = 3.40},
    {name = "eq", gain = -0.7, frequency = 6153, Q = 1.84},
    {name = "eq", gain = 1.0, frequency = 6858, Q = 2.80},
}
