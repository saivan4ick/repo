return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 7.6, frequency = 32, Q = 0.56},
    {name = "eq", gain = -3.5, frequency = 466, Q = 0.09},
    {name = "eq", gain = 7.9, frequency = 2716, Q = 1.28},
    {name = "eq", gain = 5.3, frequency = 7627, Q = 2.71},
    {name = "eq", gain = 3.9, frequency = 10255, Q = 2.01},
    {name = "eq", gain = 1.5, frequency = 588, Q = 1.52},
    {name = "eq", gain = -2.3, frequency = 1477, Q = 1.39},
    {name = "eq", gain = 3.7, frequency = 2029, Q = 4.61},
    {name = "eq", gain = 1.5, frequency = 12851, Q = 2.01},
    {name = "eq", gain = -6.3, frequency = 19517, Q = 0.67},
}
