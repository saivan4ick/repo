return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -5.3, frequency = 36, Q = 0.31},
    {name = "eq", gain = -5.9, frequency = 166, Q = 0.40},
    {name = "eq", gain = 6.8, frequency = 3448, Q = 0.72},
    {name = "eq", gain = 6.6, frequency = 18309, Q = 0.48},
    {name = "eq", gain = -2.7, frequency = 1420, Q = 2.80},
    {name = "eq", gain = 2.7, frequency = 2041, Q = 2.76},
    {name = "eq", gain = -1.3, frequency = 3543, Q = 1.99},
    {name = "eq", gain = 2.3, frequency = 5944, Q = 2.37},
    {name = "eq", gain = -2.5, frequency = 8053, Q = 2.86},
}
