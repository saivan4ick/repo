return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -3.1, frequency = 72, Q = 0.31},
    {name = "eq", gain = -0.9, frequency = 864, Q = 0.08},
    {name = "eq", gain = 6.3, frequency = 3431, Q = 2.14},
    {name = "eq", gain = 2.3, frequency = 5802, Q = 2.18},
    {name = "eq", gain = 4.7, frequency = 8850, Q = 2.55},
    {name = "eq", gain = 1.2, frequency = 969, Q = 5.27},
    {name = "eq", gain = 0.8, frequency = 3758, Q = 2.02},
    {name = "eq", gain = 3.1, frequency = 10441, Q = 1.07},
    {name = "eq", gain = 3.3, frequency = 12196, Q = 1.03},
    {name = "eq", gain = -17.9, frequency = 19746, Q = 0.33},
}
