return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -3.6, frequency = 116, Q = 0.64},
    {name = "eq", gain = -3.6, frequency = 258, Q = 0.94},
    {name = "eq", gain = -5.2, frequency = 1927, Q = 1.29},
    {name = "eq", gain = 3.2, frequency = 4537, Q = 1.87},
    {name = "eq", gain = 6.2, frequency = 15906, Q = 0.12},
    {name = "eq", gain = 0.6, frequency = 14, Q = 1.25},
    {name = "eq", gain = 1.2, frequency = 919, Q = 3.06},
    {name = "eq", gain = -0.8, frequency = 1464, Q = 2.76},
    {name = "eq", gain = -4.1, frequency = 3141, Q = 5.14},
    {name = "eq", gain = 1.8, frequency = 3178, Q = 1.82},
}
