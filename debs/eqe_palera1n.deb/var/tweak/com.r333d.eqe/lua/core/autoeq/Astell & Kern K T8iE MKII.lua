return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -4.6, frequency = 55, Q = 0.16},
    {name = "eq", gain = 1.5, frequency = 855, Q = 1.86},
    {name = "eq", gain = 3.2, frequency = 2722, Q = 3.11},
    {name = "eq", gain = 5.7, frequency = 3817, Q = 1.53},
    {name = "eq", gain = -1.8, frequency = 8102, Q = 4.04},
    {name = "eq", gain = -0.9, frequency = 1675, Q = 4.93},
    {name = "eq", gain = -1.2, frequency = 5222, Q = 6.93},
    {name = "eq", gain = -1.2, frequency = 9226, Q = 2.81},
    {name = "eq", gain = -1.3, frequency = 13952, Q = 1.04},
    {name = "eq", gain = 3.9, frequency = 18886, Q = 0.28},
}
