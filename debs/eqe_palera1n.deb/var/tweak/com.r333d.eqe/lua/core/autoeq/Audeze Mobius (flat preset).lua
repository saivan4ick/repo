return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -3.9, frequency = 243, Q = 0.27},
    {name = "eq", gain = 6.4, frequency = 435, Q = 1.38},
    {name = "eq", gain = -3.7, frequency = 3353, Q = 1.38},
    {name = "eq", gain = 4.3, frequency = 4258, Q = 2.90},
    {name = "eq", gain = 6.7, frequency = 6801, Q = 1.90},
    {name = "eq", gain = -1.4, frequency = 18, Q = 1.87},
    {name = "eq", gain = -0.9, frequency = 229, Q = 4.36},
    {name = "eq", gain = 1.1, frequency = 708, Q = 5.09},
    {name = "eq", gain = -0.5, frequency = 1205, Q = 2.63},
    {name = "eq", gain = 1.3, frequency = 9422, Q = 4.80},
}
