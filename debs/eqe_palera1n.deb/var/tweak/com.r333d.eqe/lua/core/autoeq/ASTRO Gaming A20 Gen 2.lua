return {
    {name = "preamp", gain = -4.8},
    {name = "eq", gain = 6.8, frequency = 20, Q = 1.52},
    {name = "eq", gain = -3.7, frequency = 36, Q = 0.58},
    {name = "eq", gain = 4.6, frequency = 456, Q = 1.94},
    {name = "eq", gain = -1.9, frequency = 3801, Q = 3.55},
    {name = "eq", gain = -5.6, frequency = 6030, Q = 2.19},
    {name = "eq", gain = -1.6, frequency = 1068, Q = 3.46},
    {name = "eq", gain = 3.0, frequency = 2194, Q = 1.05},
    {name = "eq", gain = -2.4, frequency = 3097, Q = 3.46},
    {name = "eq", gain = 1.3, frequency = 6822, Q = 5.19},
    {name = "eq", gain = -0.9, frequency = 15787, Q = 0.11},
}
