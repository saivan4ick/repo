return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -3.9, frequency = 83, Q = 0.32},
    {name = "eq", gain = 4.1, frequency = 1801, Q = 0.30},
    {name = "eq", gain = -7.9, frequency = 1816, Q = 0.81},
    {name = "eq", gain = 5.7, frequency = 3237, Q = 2.12},
    {name = "eq", gain = 5.7, frequency = 9106, Q = 1.79},
    {name = "eq", gain = -0.3, frequency = 4490, Q = 2.69},
    {name = "eq", gain = 0.6, frequency = 11746, Q = 0.30},
    {name = "eq", gain = 2.4, frequency = 12303, Q = 1.94},
    {name = "eq", gain = -6.7, frequency = 19255, Q = 0.48},
    {name = "eq", gain = -5.5, frequency = 19729, Q = 0.56},
}
