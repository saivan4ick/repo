return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -4.3, frequency = 177, Q = 0.96},
    {name = "eq", gain = -4.8, frequency = 1285, Q = 2.52},
    {name = "eq", gain = 4.7, frequency = 2453, Q = 3.06},
    {name = "eq", gain = 4.8, frequency = 8206, Q = 2.90},
    {name = "eq", gain = 6.4, frequency = 12687, Q = 1.12},
    {name = "eq", gain = 6.5, frequency = 653, Q = 1.79},
    {name = "eq", gain = -4.3, frequency = 840, Q = 0.76},
    {name = "eq", gain = 1.8, frequency = 1344, Q = 0.99},
    {name = "eq", gain = -4.2, frequency = 5957, Q = 6.35},
    {name = "eq", gain = 2.4, frequency = 7093, Q = 6.21},
}
