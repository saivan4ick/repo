return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 7.9, frequency = 23, Q = 0.73},
    {name = "eq", gain = -6.0, frequency = 113, Q = 0.32},
    {name = "eq", gain = 4.7, frequency = 2910, Q = 1.26},
    {name = "eq", gain = 3.8, frequency = 7435, Q = 1.88},
    {name = "eq", gain = 3.7, frequency = 9864, Q = 2.32},
    {name = "eq", gain = 1.9, frequency = 315, Q = 3.32},
    {name = "eq", gain = -1.4, frequency = 1120, Q = 0.74},
    {name = "eq", gain = 2.6, frequency = 1709, Q = 3.08},
    {name = "eq", gain = -3.0, frequency = 4155, Q = 7.08},
    {name = "eq", gain = 3.2, frequency = 5029, Q = 6.09},
}
