return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.0, frequency = 16, Q = 0.21},
    {name = "eq", gain = -2.5, frequency = 596, Q = 0.13},
    {name = "eq", gain = 7.7, frequency = 3488, Q = 1.49},
    {name = "eq", gain = 4.7, frequency = 13130, Q = 0.53},
    {name = "eq", gain = 5.4, frequency = 20267, Q = 0.33},
    {name = "eq", gain = 1.5, frequency = 849, Q = 1.65},
    {name = "eq", gain = -2.1, frequency = 1469, Q = 2.34},
    {name = "eq", gain = -2.0, frequency = 4920, Q = 4.84},
    {name = "eq", gain = 3.8, frequency = 6167, Q = 2.46},
    {name = "eq", gain = -3.3, frequency = 7262, Q = 3.29},
}
