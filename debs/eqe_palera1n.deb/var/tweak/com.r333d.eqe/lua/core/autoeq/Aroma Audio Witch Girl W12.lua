return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 2.6, frequency = 19, Q = 1.05},
    {name = "eq", gain = -5.5, frequency = 177, Q = 0.51},
    {name = "eq", gain = 4.8, frequency = 2466, Q = 1.04},
    {name = "eq", gain = 4.9, frequency = 4585, Q = 2.51},
    {name = "eq", gain = 2.8, frequency = 10435, Q = 2.14},
    {name = "eq", gain = 1.1, frequency = 778, Q = 2.11},
    {name = "eq", gain = -1.0, frequency = 1303, Q = 3.98},
    {name = "eq", gain = 0.5, frequency = 5257, Q = 4.19},
    {name = "eq", gain = -1.4, frequency = 6682, Q = 3.30},
    {name = "eq", gain = 0.7, frequency = 7475, Q = 2.80},
}
