return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 7.4, frequency = 69, Q = 0.22},
    {name = "eq", gain = -14.3, frequency = 322, Q = 0.95},
    {name = "eq", gain = 4.1, frequency = 1418, Q = 0.63},
    {name = "eq", gain = -4.9, frequency = 11185, Q = 1.00},
    {name = "eq", gain = 6.8, frequency = 18245, Q = 0.39},
    {name = "eq", gain = 2.3, frequency = 122, Q = 4.88},
    {name = "eq", gain = 3.6, frequency = 938, Q = 1.74},
    {name = "eq", gain = -3.0, frequency = 1160, Q = 0.75},
    {name = "eq", gain = 2.9, frequency = 2115, Q = 2.37},
    {name = "eq", gain = -1.5, frequency = 3055, Q = 5.21},
}
