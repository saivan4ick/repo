return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 3.4, frequency = 21, Q = 1.90},
    {name = "eq", gain = -2.4, frequency = 90, Q = 1.01},
    {name = "eq", gain = 9.7, frequency = 3238, Q = 1.72},
    {name = "eq", gain = -3.0, frequency = 9725, Q = 0.09},
    {name = "eq", gain = -3.3, frequency = 20184, Q = 0.42},
    {name = "eq", gain = 3.1, frequency = 285, Q = 3.78},
    {name = "eq", gain = -2.2, frequency = 1923, Q = 2.50},
    {name = "eq", gain = 3.2, frequency = 2626, Q = 3.50},
    {name = "eq", gain = -1.5, frequency = 3059, Q = 2.56},
    {name = "eq", gain = 1.5, frequency = 4792, Q = 5.78},
}
