return {
    {name = "preamp", gain = -5.1},
    {name = "eq", gain = -1.3, frequency = 93, Q = 0.83},
    {name = "eq", gain = -1.2, frequency = 152, Q = 1.17},
    {name = "eq", gain = 2.6, frequency = 4811, Q = 4.84},
    {name = "eq", gain = 5.5, frequency = 7151, Q = 2.05},
    {name = "eq", gain = -10.4, frequency = 19381, Q = 0.48},
    {name = "eq", gain = -1.3, frequency = 1926, Q = 1.36},
    {name = "eq", gain = -3.0, frequency = 3478, Q = 2.11},
    {name = "eq", gain = 2.3, frequency = 4253, Q = 2.60},
    {name = "eq", gain = -1.3, frequency = 7900, Q = 5.43},
    {name = "eq", gain = 1.3, frequency = 9755, Q = 2.00},
}
