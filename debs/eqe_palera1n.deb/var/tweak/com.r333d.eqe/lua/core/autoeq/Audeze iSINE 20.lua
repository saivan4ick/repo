return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 4.5, frequency = 31, Q = 0.54},
    {name = "eq", gain = -20.2, frequency = 1460, Q = 0.43},
    {name = "eq", gain = 6.5, frequency = 2305, Q = 2.24},
    {name = "eq", gain = 17.7, frequency = 3717, Q = 0.25},
    {name = "eq", gain = -11.1, frequency = 11614, Q = 0.60},
    {name = "eq", gain = -0.6, frequency = 209, Q = 2.41},
    {name = "eq", gain = 1.4, frequency = 6329, Q = 4.74},
    {name = "eq", gain = -0.9, frequency = 9977, Q = 1.15},
    {name = "eq", gain = 1.1, frequency = 12301, Q = 2.06},
    {name = "eq", gain = -0.5, frequency = 16594, Q = 1.95},
}
