return {
    {name = "preamp", gain = -4.4},
    {name = "eq", gain = -5.7, frequency = 23, Q = 0.51},
    {name = "eq", gain = -4.2, frequency = 65, Q = 1.06},
    {name = "eq", gain = -5.5, frequency = 135, Q = 1.49},
    {name = "eq", gain = 3.0, frequency = 568, Q = 0.62},
    {name = "eq", gain = 4.6, frequency = 3599, Q = 5.97},
    {name = "eq", gain = 1.4, frequency = 1146, Q = 3.82},
    {name = "eq", gain = 1.2, frequency = 1402, Q = 3.91},
    {name = "eq", gain = -3.5, frequency = 2329, Q = 3.61},
    {name = "eq", gain = 3.8, frequency = 6174, Q = 2.99},
    {name = "eq", gain = -7.2, frequency = 18310, Q = 0.26},
}
