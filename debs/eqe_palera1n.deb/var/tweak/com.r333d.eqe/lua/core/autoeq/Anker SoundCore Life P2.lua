return {
    {name = "preamp", gain = -4.7},
    {name = "eq", gain = -6.3, frequency = 25, Q = 0.42},
    {name = "eq", gain = -6.6, frequency = 89, Q = 0.70},
    {name = "eq", gain = 1.7, frequency = 915, Q = 0.79},
    {name = "eq", gain = 4.0, frequency = 2510, Q = 2.29},
    {name = "eq", gain = 3.6, frequency = 5864, Q = 3.89},
    {name = "eq", gain = 0.2, frequency = 944, Q = 3.67},
    {name = "eq", gain = 0.6, frequency = 2949, Q = 4.20},
    {name = "eq", gain = 2.3, frequency = 7871, Q = 1.81},
    {name = "eq", gain = 1.0, frequency = 12897, Q = 0.67},
    {name = "eq", gain = -7.4, frequency = 19392, Q = 0.19},
}
