return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.8, frequency = 26, Q = 1.51},
    {name = "eq", gain = 5.1, frequency = 872, Q = 3.20},
    {name = "eq", gain = 8.1, frequency = 3867, Q = 1.34},
    {name = "eq", gain = -11.6, frequency = 5910, Q = 2.46},
    {name = "eq", gain = 4.2, frequency = 15029, Q = 0.44},
    {name = "eq", gain = -3.6, frequency = 129, Q = 1.36},
    {name = "eq", gain = -2.5, frequency = 327, Q = 0.76},
    {name = "eq", gain = 2.3, frequency = 692, Q = 2.78},
    {name = "eq", gain = -1.3, frequency = 1714, Q = 4.73},
    {name = "eq", gain = 0.5, frequency = 11292, Q = 3.31},
}
