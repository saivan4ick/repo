return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -4.6, frequency = 14, Q = 0.35},
    {name = "eq", gain = -3.1, frequency = 276, Q = 0.63},
    {name = "eq", gain = -3.0, frequency = 1702, Q = 1.90},
    {name = "eq", gain = 4.4, frequency = 3411, Q = 1.79},
    {name = "eq", gain = 6.2, frequency = 6786, Q = 1.74},
    {name = "eq", gain = 0.8, frequency = 928, Q = 4.65},
    {name = "eq", gain = 0.9, frequency = 9470, Q = 2.29},
    {name = "eq", gain = 1.8, frequency = 10645, Q = 1.25},
    {name = "eq", gain = -4.3, frequency = 19350, Q = 0.28},
    {name = "eq", gain = -5.5, frequency = 19900, Q = 0.42},
}
