return {
    {name = "preamp", gain = -3.2},
    {name = "eq", gain = -5.6, frequency = 206, Q = 0.16},
    {name = "eq", gain = 8.2, frequency = 334, Q = 0.94},
    {name = "eq", gain = 4.3, frequency = 2114, Q = 1.19},
    {name = "eq", gain = -4.4, frequency = 5961, Q = 2.83},
    {name = "eq", gain = 2.9, frequency = 9460, Q = 1.00},
    {name = "eq", gain = 1.8, frequency = 3452, Q = 5.02},
    {name = "eq", gain = -2.8, frequency = 3897, Q = 4.51},
    {name = "eq", gain = 0.8, frequency = 4688, Q = 3.46},
}
