return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -5.6, frequency = 26, Q = 0.06},
    {name = "eq", gain = 6.3, frequency = 3305, Q = 2.63},
    {name = "eq", gain = 4.1, frequency = 6464, Q = 1.87},
    {name = "eq", gain = 7.2, frequency = 9890, Q = 1.09},
    {name = "eq", gain = -15.6, frequency = 19667, Q = 0.42},
    {name = "eq", gain = -2.9, frequency = 2542, Q = 1.41},
    {name = "eq", gain = 4.1, frequency = 2711, Q = 4.66},
    {name = "eq", gain = 2.2, frequency = 4294, Q = 2.51},
    {name = "eq", gain = -2.7, frequency = 4755, Q = 6.94},
    {name = "eq", gain = -0.7, frequency = 16978, Q = 1.64},
}
