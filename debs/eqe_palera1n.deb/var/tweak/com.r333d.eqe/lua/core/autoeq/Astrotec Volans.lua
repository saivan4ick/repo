return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -2.6, frequency = 19, Q = 0.10},
    {name = "eq", gain = -3.8, frequency = 206, Q = 0.68},
    {name = "eq", gain = 7.5, frequency = 6931, Q = 1.10},
    {name = "eq", gain = 11.7, frequency = 13133, Q = 0.67},
    {name = "eq", gain = -7.2, frequency = 19235, Q = 0.07},
    {name = "eq", gain = 1.6, frequency = 890, Q = 2.21},
    {name = "eq", gain = -3.1, frequency = 1982, Q = 1.54},
    {name = "eq", gain = 5.6, frequency = 3006, Q = 2.41},
    {name = "eq", gain = -8.0, frequency = 4407, Q = 4.30},
    {name = "eq", gain = 4.8, frequency = 5137, Q = 5.02},
}
