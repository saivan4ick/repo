return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.6, frequency = 28, Q = 0.90},
    {name = "eq", gain = -7.9, frequency = 2207, Q = 2.27},
    {name = "eq", gain = 6.3, frequency = 3663, Q = 2.32},
    {name = "eq", gain = 4.1, frequency = 7518, Q = 1.88},
    {name = "eq", gain = 4.6, frequency = 10715, Q = 1.73},
    {name = "eq", gain = -2.7, frequency = 231, Q = 1.01},
    {name = "eq", gain = 2.5, frequency = 816, Q = 2.05},
    {name = "eq", gain = 1.9, frequency = 14048, Q = 1.46},
    {name = "eq", gain = -5.8, frequency = 19933, Q = 0.46},
}
