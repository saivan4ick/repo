return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.6, frequency = 32, Q = 0.60},
    {name = "eq", gain = 2.2, frequency = 582, Q = 0.72},
    {name = "eq", gain = -8.3, frequency = 1839, Q = 2.17},
    {name = "eq", gain = 7.2, frequency = 8860, Q = 0.34},
    {name = "eq", gain = -11.8, frequency = 20237, Q = 0.06},
    {name = "eq", gain = 2.6, frequency = 60, Q = 3.62},
    {name = "eq", gain = -1.6, frequency = 83, Q = 1.84},
    {name = "eq", gain = -2.2, frequency = 2352, Q = 4.96},
    {name = "eq", gain = 4.3, frequency = 3285, Q = 4.08},
    {name = "eq", gain = -4.0, frequency = 5409, Q = 3.31},
}
