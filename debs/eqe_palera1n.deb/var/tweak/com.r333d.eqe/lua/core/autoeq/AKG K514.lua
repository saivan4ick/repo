return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 6.6, frequency = 34, Q = 0.42},
    {name = "eq", gain = -6.1, frequency = 633, Q = 0.38},
    {name = "eq", gain = -2.1, frequency = 1425, Q = 3.57},
    {name = "eq", gain = 6.0, frequency = 3636, Q = 0.65},
    {name = "eq", gain = 4.5, frequency = 7723, Q = 1.79},
    {name = "eq", gain = -1.0, frequency = 188, Q = 2.34},
    {name = "eq", gain = 1.3, frequency = 382, Q = 2.35},
    {name = "eq", gain = -1.1, frequency = 625, Q = 3.31},
    {name = "eq", gain = 1.9, frequency = 10244, Q = 1.25},
    {name = "eq", gain = -8.1, frequency = 19575, Q = 0.40},
}
