return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 4.9, frequency = 13, Q = 0.43},
    {name = "eq", gain = -2.6, frequency = 966, Q = 0.12},
    {name = "eq", gain = 3.5, frequency = 2526, Q = 2.84},
    {name = "eq", gain = 7.4, frequency = 4587, Q = 1.36},
    {name = "eq", gain = 3.8, frequency = 10451, Q = 0.86},
    {name = "eq", gain = -0.6, frequency = 220, Q = 3.08},
    {name = "eq", gain = 1.6, frequency = 682, Q = 1.16},
    {name = "eq", gain = -1.4, frequency = 1339, Q = 0.68},
    {name = "eq", gain = 1.6, frequency = 2094, Q = 5.52},
    {name = "eq", gain = 0.6, frequency = 3236, Q = 2.85},
}
