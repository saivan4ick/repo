return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 33, Q = 0.44},
    {name = "eq", gain = -1.3, frequency = 1291, Q = 3.81},
    {name = "eq", gain = 5.9, frequency = 5025, Q = 1.48},
    {name = "eq", gain = -1.7, frequency = 7777, Q = 2.18},
    {name = "eq", gain = -2.4, frequency = 15247, Q = 0.10},
    {name = "eq", gain = -1.8, frequency = 269, Q = 1.89},
    {name = "eq", gain = 0.6, frequency = 823, Q = 4.14},
    {name = "eq", gain = 0.8, frequency = 2174, Q = 4.25},
    {name = "eq", gain = -0.9, frequency = 2915, Q = 5.53},
}
