return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.8, frequency = 46, Q = 0.23},
    {name = "eq", gain = -4.7, frequency = 200, Q = 0.61},
    {name = "eq", gain = 2.1, frequency = 2705, Q = 2.35},
    {name = "eq", gain = 5.9, frequency = 6186, Q = 1.94},
    {name = "eq", gain = -2.9, frequency = 13419, Q = 0.17},
    {name = "eq", gain = -0.3, frequency = 678, Q = 1.21},
    {name = "eq", gain = 0.7, frequency = 1351, Q = 2.62},
    {name = "eq", gain = 2.5, frequency = 3136, Q = 6.99},
    {name = "eq", gain = -3.1, frequency = 3658, Q = 3.28},
    {name = "eq", gain = 1.5, frequency = 4279, Q = 3.20},
}
