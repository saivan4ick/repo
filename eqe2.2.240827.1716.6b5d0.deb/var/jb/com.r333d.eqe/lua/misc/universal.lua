#!/usr/bin/env luajit

ffi = require 'ffi'
C = ffi.C
local statPtr, ffiStat

Command = {}
Command['find'] = function()
    local function find(findType)
        local s = 'find '..arg[2]:bashEsc()
        if arg[3] then
            s = s..' -maxdepth '..tonumber(arg[3])
        end
        s = s..' -type '..findType
        local f = io.popen(s, 'r')
        for l in f:lines() do
            if not Stat(l, findType) then
                WriteJson{
                    warning = StrErr(),
                }
            end
        end
        f:close()
    end
    -- using -type f and -type d in separate commands is a relatively portable way of marking files vs directories
    find('f')
    find('d')
end
Command['compressImage'] = function()
    -- sanity check
    local f = io.popen('ffmpeg 2>&1')
    local s = f:read('*a')
    f:close()
    local prefix = 'ffmpeg version'
    if s:sub(1, #prefix) ~= prefix then
        WriteJson{
            warning = 'ffmpeg not installed',
        }
        return
    end

    local outPath = arg[3]
    local f = io.open(outPath, 'r')
    if f then
        f:close()
    else
        -- if ffmpeg fails in the middle of a conversion,
        -- a partial file is written. we dont want this, so
        -- write to a temporary file and move it to the correct path
        local x, y = outPath:match('^(.+)%.(.-)$')
        local tmpPath = x..'.part.'..y
        os.execute('rm -f '..tmpPath:bashEsc())
        os.execute('ffmpeg -i '..arg[2]:bashEsc()..' -vf scale='..arg[4]:bashEsc()..':-1 '..tmpPath:bashEsc()..' >/dev/null 2>/dev/null')
        os.execute('mv '..tmpPath:bashEsc()..' '..outPath:bashEsc())
    end
    local f = io.open(outPath, 'r')
    if not f then
        WriteJson{
            warning = 'compressImage '..arg[2]..' to '..outPath..' failed',
        }
    else
        f:close()
        if not Stat(outPath, 'f') then
            WriteJson{
                error = 'stat failed: '..StrErr(),
            }
        end
    end
end

-- "Standard" library

function WriteJson(x, recursive)
    local type = type(x)
    if type == 'string' then
        x = x:gsub('\\', '\\\\')
        x = x:gsub('\n', '\\n')
        x = x:gsub('"', '\\"')
        io.write'"'
        io.write(x)
        io.write'"'
    elseif type == 'number' then
        io.write(tostring(x))
    elseif type == 'table' then
        io.write'{'
        local needComma = false
        for k,v in pairs(x) do
            assert(_G.type(k) == 'string')
            if needComma then io.write', ' end
            needComma = true
            WriteJson(k, true)
            io.write':'
            WriteJson(v, true)
        end
        io.write'}'
    end
    if not recursive then
        assert(type == 'table')
        io.write'\n'
        io.flush()
    end
end

function Stat(s, findType)
    local lastModified, size = ffiStat(s)
    if lastModified then
        WriteJson{
            path = s,
            lastModified = lastModified,
            size = size,
            findType = findType,
        }
        return true
    end
end

function StrErr()
    return ffi.string(C.strerror(ffi.errno()))
end

function string:bashEsc()
    return "'"..self:gsub("'", "'\\''").."'"
end

-- Platform-specific stuff

ffi.cdef[[
char * strerror(int);
]]

if ffi.os == 'OSX' and ffi.arch == 'x64' then
    -- This is incorrect but I want to get this out the door
    ffi.cdef[[
    typedef signed char __int8_t;
    typedef unsigned char __uint8_t;
    typedef short __int16_t;
    typedef unsigned short __uint16_t;
    typedef int __int32_t;
    typedef unsigned int __uint32_t;
    typedef long long __int64_t;
    typedef unsigned long long __uint64_t;
    typedef long __darwin_intptr_t;
    typedef unsigned int __darwin_natural_t;
    typedef int __darwin_ct_rune_t;

    typedef union {
     char __mbstate8[128];
     long long _mbstateL;
    } __mbstate_t;

    typedef __mbstate_t __darwin_mbstate_t;
    typedef long int __darwin_ptrdiff_t;
    typedef long unsigned int __darwin_size_t;
    typedef __builtin_va_list __darwin_va_list;
    typedef int __darwin_wchar_t;
    typedef __darwin_wchar_t __darwin_rune_t;
    typedef int __darwin_wint_t;
    typedef unsigned long __darwin_clock_t;
    typedef __uint32_t __darwin_socklen_t;
    typedef long __darwin_ssize_t;
    typedef long __darwin_time_t;
    typedef __int64_t __darwin_blkcnt_t;
    typedef __int32_t __darwin_blksize_t;
    typedef __int32_t __darwin_dev_t;
    typedef unsigned int __darwin_fsblkcnt_t;
    typedef unsigned int __darwin_fsfilcnt_t;
    typedef __uint32_t __darwin_gid_t;
    typedef __uint32_t __darwin_id_t;
    typedef __uint64_t __darwin_ino64_t;
    typedef __darwin_ino64_t __darwin_ino_t;
    typedef __darwin_natural_t __darwin_mach_port_name_t;
    typedef __darwin_mach_port_name_t __darwin_mach_port_t;
    typedef __uint16_t __darwin_mode_t;
    typedef __int64_t __darwin_off_t;
    typedef __int32_t __darwin_pid_t;
    typedef __uint32_t __darwin_sigset_t;
    typedef __int32_t __darwin_suseconds_t;
    typedef __uint32_t __darwin_uid_t;
    typedef __uint32_t __darwin_useconds_t;
    typedef unsigned char __darwin_uuid_t[16];
    typedef char __darwin_uuid_string_t[37];

    struct __darwin_pthread_handler_rec {
     void (*__routine)(void *);
     void *__arg;
     struct __darwin_pthread_handler_rec *__next;
    };

    struct _opaque_pthread_attr_t {
     long __sig;
     char __opaque[56];
    };

    struct _opaque_pthread_cond_t {
     long __sig;
     char __opaque[40];
    };

    struct _opaque_pthread_condattr_t {
     long __sig;
     char __opaque[8];
    };

    struct _opaque_pthread_mutex_t {
     long __sig;
     char __opaque[56];
    };

    struct _opaque_pthread_mutexattr_t {
     long __sig;
     char __opaque[8];
    };

    struct _opaque_pthread_once_t {
     long __sig;
     char __opaque[8];
    };

    struct _opaque_pthread_rwlock_t {
     long __sig;
     char __opaque[192];
    };

    struct _opaque_pthread_rwlockattr_t {
     long __sig;
     char __opaque[16];
    };

    struct _opaque_pthread_t {
     long __sig;
     struct __darwin_pthread_handler_rec *__cleanup_stack;
     char __opaque[8176];
    };

    typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
    typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
    typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
    typedef unsigned long __darwin_pthread_key_t;
    typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
    typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
    typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
    typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
    typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
    typedef struct _opaque_pthread_t *__darwin_pthread_t;
    typedef signed char int8_t;
    typedef short int16_t;
    typedef int int32_t;
    typedef long long int64_t;
    typedef unsigned char u_int8_t;
    typedef unsigned short u_int16_t;
    typedef unsigned int u_int32_t;
    typedef unsigned long long u_int64_t;
    typedef int64_t register_t;
    typedef __darwin_intptr_t intptr_t;
    typedef unsigned long uintptr_t;
    typedef u_int64_t user_addr_t;
    typedef u_int64_t user_size_t;
    typedef int64_t user_ssize_t;
    typedef int64_t user_long_t;
    typedef u_int64_t user_ulong_t;
    typedef int64_t user_time_t;
    typedef int64_t user_off_t;
    typedef u_int64_t syscall_arg_t;

    struct timespec
    {
     __darwin_time_t tv_sec;
     long tv_nsec;
    };
    typedef __darwin_blkcnt_t blkcnt_t;
    typedef __darwin_blksize_t blksize_t;
    typedef __darwin_dev_t dev_t;
    typedef __darwin_ino_t ino_t;
    typedef __darwin_ino64_t ino64_t;
    typedef __darwin_mode_t mode_t;
    typedef __uint16_t nlink_t;
    typedef __darwin_uid_t uid_t;
    typedef __darwin_gid_t gid_t;
    typedef __darwin_off_t off_t;
    typedef __darwin_time_t time_t;
    struct ostat {
     __uint16_t st_dev;
     ino_t st_ino;
     mode_t st_mode;
     nlink_t st_nlink;
     __uint16_t st_uid;
     __uint16_t st_gid;
     __uint16_t st_rdev;
     __int32_t st_size;
     struct timespec st_atimespec;
     struct timespec st_mtimespec;
     struct timespec st_ctimespec;
     __int32_t st_blksize;
     __int32_t st_blocks;
     __uint32_t st_flags;
     __uint32_t st_gen;
    };
    struct stat { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };
    int stat(const char *, struct stat *);
    ]]
    ffiStat = function(path)
        if C.stat(path, statPtr) == 0 then
            return tonumber(statPtr.st_mtimespec.tv_sec),
                tonumber(statPtr.st_size)
        end
    end
elseif ffi.os == 'OSX' and ffi.arch == 'arm64' then
    ffi.cdef[[
    typedef signed char __int8_t;
    typedef unsigned char __uint8_t;
    typedef short __int16_t;
    typedef unsigned short __uint16_t;
    typedef int __int32_t;
    typedef unsigned int __uint32_t;
    typedef long long __int64_t;
    typedef unsigned long long __uint64_t;
    typedef long __darwin_intptr_t;
    typedef unsigned int __darwin_natural_t;
    typedef int __darwin_ct_rune_t;
    typedef union {
        char __mbstate8[128];
        long long _mbstateL;
    } __mbstate_t;
    typedef __mbstate_t __darwin_mbstate_t;
    typedef long int __darwin_ptrdiff_t;
    typedef long unsigned int __darwin_size_t;
    typedef __builtin_va_list __darwin_va_list;
    typedef int __darwin_wchar_t;
    typedef __darwin_wchar_t __darwin_rune_t;
    typedef int __darwin_wint_t;
    typedef unsigned long __darwin_clock_t;
    typedef __uint32_t __darwin_socklen_t;
    typedef long __darwin_ssize_t;
    typedef long __darwin_time_t;
    typedef __int64_t __darwin_blkcnt_t;
    typedef __int32_t __darwin_blksize_t;
    typedef __int32_t __darwin_dev_t;
    typedef unsigned int __darwin_fsblkcnt_t;
    typedef unsigned int __darwin_fsfilcnt_t;
    typedef __uint32_t __darwin_gid_t;
    typedef __uint32_t __darwin_id_t;
    typedef __uint64_t __darwin_ino64_t;
    typedef __darwin_ino64_t __darwin_ino_t;
    typedef __darwin_natural_t __darwin_mach_port_name_t;
    typedef __darwin_mach_port_name_t __darwin_mach_port_t;
    typedef __uint16_t __darwin_mode_t;
    typedef __int64_t __darwin_off_t;
    typedef __int32_t __darwin_pid_t;
    typedef __uint32_t __darwin_sigset_t;
    typedef __int32_t __darwin_suseconds_t;
    typedef __uint32_t __darwin_uid_t;
    typedef __uint32_t __darwin_useconds_t;
    typedef unsigned char __darwin_uuid_t[16];
    typedef char __darwin_uuid_string_t[37];

    typedef signed char int8_t;
    typedef short int16_t;
    typedef int int32_t;
    typedef long long int64_t;

    typedef unsigned char u_int8_t;
    typedef unsigned short u_int16_t;
    typedef unsigned int u_int32_t;
    typedef unsigned long long u_int64_t;
    typedef int64_t register_t;

    typedef __darwin_intptr_t intptr_t;
    typedef unsigned long uintptr_t;
    typedef u_int64_t user_addr_t;
    typedef u_int64_t user_size_t;
    typedef int64_t user_ssize_t;
    typedef int64_t user_long_t;
    typedef u_int64_t user_ulong_t;
    typedef int64_t user_time_t;
    typedef int64_t user_off_t;
    typedef u_int64_t syscall_arg_t;

    struct timespec
    {
        __darwin_time_t tv_sec;
        long tv_nsec;
    };
    typedef __darwin_blkcnt_t blkcnt_t;
    typedef __darwin_blksize_t blksize_t;
    typedef __darwin_dev_t dev_t;
    typedef __darwin_ino_t ino_t;
    typedef __darwin_ino64_t ino64_t;
    typedef __darwin_mode_t mode_t;
    typedef __uint16_t nlink_t;
    typedef __darwin_uid_t uid_t;
    typedef __darwin_gid_t gid_t;
    typedef __darwin_off_t off_t;
    typedef __darwin_time_t time_t;
    struct stat { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };

    int stat(const char *, struct stat *);
    ]]
    ffiStat = function(path)
        if C.stat(path, statPtr) == 0 then
            return tonumber(statPtr.st_mtimespec.tv_sec),
                tonumber(statPtr.st_size)
        end
    end
elseif ffi.os == 'Linux' and ffi.arch == 'x64' then
    ffi.cdef[[
    typedef unsigned char __u_char;
    typedef unsigned short int __u_short;
    typedef unsigned int __u_int;
    typedef unsigned long int __u_long;
    typedef signed char __int8_t;
    typedef unsigned char __uint8_t;
    typedef signed short int __int16_t;
    typedef unsigned short int __uint16_t;
    typedef signed int __int32_t;
    typedef unsigned int __uint32_t;
    typedef signed long int __int64_t;
    typedef unsigned long int __uint64_t;
    typedef __int8_t __int_least8_t;
    typedef __uint8_t __uint_least8_t;
    typedef __int16_t __int_least16_t;
    typedef __uint16_t __uint_least16_t;
    typedef __int32_t __int_least32_t;
    typedef __uint32_t __uint_least32_t;
    typedef __int64_t __int_least64_t;
    typedef __uint64_t __uint_least64_t;
    typedef long int __quad_t;
    typedef unsigned long int __u_quad_t;
    typedef long int __intmax_t;
    typedef unsigned long int __uintmax_t;
    typedef unsigned long int __dev_t;
    typedef unsigned int __uid_t;
    typedef unsigned int __gid_t;
    typedef unsigned long int __ino_t;
    typedef unsigned long int __ino64_t;
    typedef unsigned int __mode_t;
    typedef unsigned long int __nlink_t;
    typedef long int __off_t;
    typedef long int __off64_t;
    typedef int __pid_t;
    typedef struct { int __val[2]; } __fsid_t;
    typedef long int __clock_t;
    typedef unsigned long int __rlim_t;
    typedef unsigned long int __rlim64_t;
    typedef unsigned int __id_t;
    typedef long int __time_t;
    typedef unsigned int __useconds_t;
    typedef long int __suseconds_t;
    typedef int __daddr_t;
    typedef int __key_t;
    typedef int __clockid_t;
    typedef void * __timer_t;
    typedef long int __blksize_t;
    typedef long int __blkcnt_t;
    typedef long int __blkcnt64_t;
    typedef unsigned long int __fsblkcnt_t;
    typedef unsigned long int __fsblkcnt64_t;
    typedef unsigned long int __fsfilcnt_t;
    typedef unsigned long int __fsfilcnt64_t;
    typedef long int __fsword_t;
    typedef long int __ssize_t;
    typedef long int __syscall_slong_t;
    typedef unsigned long int __syscall_ulong_t;
    typedef __off64_t __loff_t;
    typedef char *__caddr_t;
    typedef long int __intptr_t;
    typedef unsigned int __socklen_t;
    typedef int __sig_atomic_t;
    struct timespec
    {
        __time_t tv_sec;
        __syscall_slong_t tv_nsec;
    };
    typedef __time_t time_t;
    typedef __dev_t dev_t;
    typedef __gid_t gid_t;
    typedef __ino_t ino_t;
    typedef __mode_t mode_t;
    typedef __nlink_t nlink_t;
    typedef __off_t off_t;
    typedef __uid_t uid_t;

    struct stat {
        __dev_t st_dev;
        __ino_t st_ino;
        __nlink_t st_nlink;
        __mode_t st_mode;
        __uid_t st_uid;
        __gid_t st_gid;
        int __pad0;
        __dev_t st_rdev;
        __off_t st_size;
        __blksize_t st_blksize;
        __blkcnt_t st_blocks;
        struct timespec st_atim;
        struct timespec st_mtim;
        struct timespec st_ctim;
        __syscall_slong_t __glibc_reserved[3];
    };
    extern int stat (const char *__restrict __file, struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
    extern int __xstat (int __ver, const char *__filename, struct stat *__stat_buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
     ]]
     ffiStat = function(path)
         -- what the fuck
         -- official docs: https://refspecs.linuxfoundation.org/LSB_1.1.0/gLSB/baselib-xstat-1.html
         -- random stackoverflow post: https://stackoverflow.com/questions/54520101/xstat-dynamic-symbol-resolving-error-on-64bit
         -- first arg should be 3 on 32bit
         if C.__xstat(1, path, statPtr) == 0 then
             return tonumber(statPtr.st_mtim.tv_sec),
                tonumber(statPtr.st_size)
         end
     end
else
    WriteJson{
        error = 'unsupported platform '..ffi.os..' '..ffi.arch,
    }
    return
end
statPtr = ffi.new('struct stat')

local f = Command[arg[1]]
if f then
    f()
else
    WriteJson{
        error = 'unknown arg '..tostring(arg[1]),
    }
end
