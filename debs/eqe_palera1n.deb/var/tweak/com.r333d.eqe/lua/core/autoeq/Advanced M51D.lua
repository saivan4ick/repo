return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 6.3, frequency = 27, Q = 0.50},
    {name = "eq", gain = -4.4, frequency = 336, Q = 0.56},
    {name = "eq", gain = 4.3, frequency = 3116, Q = 3.63},
    {name = "eq", gain = 5.2, frequency = 5805, Q = 2.01},
    {name = "eq", gain = 5.7, frequency = 9897, Q = 1.36},
    {name = "eq", gain = 2.8, frequency = 968, Q = 1.86},
    {name = "eq", gain = -2.3, frequency = 1784, Q = 0.55},
    {name = "eq", gain = 2.1, frequency = 2571, Q = 4.03},
    {name = "eq", gain = 2.8, frequency = 4191, Q = 1.94},
    {name = "eq", gain = -3.7, frequency = 4221, Q = 6.37},
}
