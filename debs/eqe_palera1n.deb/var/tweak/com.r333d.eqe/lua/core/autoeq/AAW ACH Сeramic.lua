return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.3, frequency = 23, Q = 0.66},
    {name = "eq", gain = -5.4, frequency = 287, Q = 0.40},
    {name = "eq", gain = 5.3, frequency = 1388, Q = 0.74},
    {name = "eq", gain = 2.8, frequency = 3883, Q = 2.65},
    {name = "eq", gain = 5.0, frequency = 6329, Q = 4.53},
    {name = "eq", gain = 0.3, frequency = 868, Q = 4.87},
    {name = "eq", gain = 0.3, frequency = 3086, Q = 1.97},
    {name = "eq", gain = 1.4, frequency = 7556, Q = 1.72},
    {name = "eq", gain = -6.6, frequency = 19227, Q = 0.27},
}
