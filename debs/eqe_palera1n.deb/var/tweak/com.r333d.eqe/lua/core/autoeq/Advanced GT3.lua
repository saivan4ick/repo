return {
    {name = "preamp", gain = -5.9},
    {name = "eq", gain = -3.4, frequency = 273, Q = 0.29},
    {name = "eq", gain = 5.0, frequency = 891, Q = 0.72},
    {name = "eq", gain = 4.8, frequency = 2162, Q = 1.85},
    {name = "eq", gain = -5.2, frequency = 5750, Q = 4.78},
    {name = "eq", gain = -17.2, frequency = 19373, Q = 0.51},
    {name = "eq", gain = -0.6, frequency = 20, Q = 1.30},
    {name = "eq", gain = -2.5, frequency = 3631, Q = 4.82},
    {name = "eq", gain = 1.5, frequency = 4016, Q = 3.07},
    {name = "eq", gain = 1.8, frequency = 10706, Q = 3.35},
    {name = "eq", gain = -1.5, frequency = 16232, Q = 1.67},
}
