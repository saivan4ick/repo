return {
    {name = "preamp", gain = -5.5},
    {name = "eq", gain = -5.7, frequency = 12, Q = 0.10},
    {name = "eq", gain = -3.8, frequency = 1441, Q = 1.53},
    {name = "eq", gain = 2.6, frequency = 3049, Q = 2.45},
    {name = "eq", gain = 3.2, frequency = 3261, Q = 0.75},
    {name = "eq", gain = 2.6, frequency = 9784, Q = 3.39},
    {name = "eq", gain = -0.7, frequency = 23, Q = 1.01},
    {name = "eq", gain = 0.6, frequency = 42, Q = 1.02},
    {name = "eq", gain = 2.2, frequency = 6328, Q = 6.26},
    {name = "eq", gain = 3.1, frequency = 11910, Q = 1.34},
    {name = "eq", gain = -12.1, frequency = 19717, Q = 0.36},
}
