return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -11.1, frequency = 18, Q = 0.23},
    {name = "eq", gain = -4.7, frequency = 131, Q = 1.67},
    {name = "eq", gain = 1.1, frequency = 907, Q = 2.36},
    {name = "eq", gain = 3.1, frequency = 2018, Q = 0.94},
    {name = "eq", gain = 6.7, frequency = 17173, Q = 0.33},
    {name = "eq", gain = -1.6, frequency = 234, Q = 1.11},
    {name = "eq", gain = 4.1, frequency = 251, Q = 2.99},
    {name = "eq", gain = 3.4, frequency = 4200, Q = 3.57},
    {name = "eq", gain = -3.8, frequency = 5842, Q = 1.98},
    {name = "eq", gain = 1.7, frequency = 9009, Q = 1.53},
}
