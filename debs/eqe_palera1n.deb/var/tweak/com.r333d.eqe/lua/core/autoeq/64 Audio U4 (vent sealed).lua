return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -5.3, frequency = 44, Q = 0.12},
    {name = "eq", gain = 4.2, frequency = 2120, Q = 2.66},
    {name = "eq", gain = 4.0, frequency = 3875, Q = 1.86},
    {name = "eq", gain = 4.7, frequency = 9523, Q = 0.89},
    {name = "eq", gain = 3.7, frequency = 13816, Q = 1.22},
    {name = "eq", gain = 0.8, frequency = 715, Q = 2.17},
    {name = "eq", gain = -0.8, frequency = 1296, Q = 4.61},
    {name = "eq", gain = -2.0, frequency = 5326, Q = 5.14},
    {name = "eq", gain = 2.7, frequency = 6314, Q = 2.81},
    {name = "eq", gain = -2.8, frequency = 7205, Q = 5.73},
}
