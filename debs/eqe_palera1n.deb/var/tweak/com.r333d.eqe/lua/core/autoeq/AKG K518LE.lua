return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.1, frequency = 20, Q = 0.63},
    {name = "eq", gain = -4.1, frequency = 170, Q = 0.88},
    {name = "eq", gain = 4.2, frequency = 3616, Q = 2.35},
    {name = "eq", gain = 4.3, frequency = 8578, Q = 1.90},
    {name = "eq", gain = 3.4, frequency = 11095, Q = 2.42},
    {name = "eq", gain = 1.3, frequency = 490, Q = 2.02},
    {name = "eq", gain = -2.3, frequency = 1307, Q = 0.90},
    {name = "eq", gain = 1.6, frequency = 2177, Q = 1.27},
    {name = "eq", gain = -3.5, frequency = 5414, Q = 6.40},
    {name = "eq", gain = 2.4, frequency = 6168, Q = 5.31},
}
