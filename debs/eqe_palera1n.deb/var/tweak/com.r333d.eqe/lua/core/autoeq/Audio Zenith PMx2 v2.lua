return {
    {name = "preamp", gain = -4.0},
    {name = "eq", gain = 3.5, frequency = 13, Q = 0.35},
    {name = "eq", gain = 5.8, frequency = 2039, Q = 1.44},
    {name = "eq", gain = -2.6, frequency = 2325, Q = 0.02},
    {name = "eq", gain = 3.6, frequency = 4136, Q = 2.32},
    {name = "eq", gain = 4.9, frequency = 9959, Q = 0.78},
    {name = "eq", gain = 0.9, frequency = 12, Q = 0.98},
    {name = "eq", gain = 1.8, frequency = 59, Q = 0.71},
    {name = "eq", gain = 1.5, frequency = 347, Q = 3.22},
    {name = "eq", gain = -1.4, frequency = 6042, Q = 7.56},
    {name = "eq", gain = 1.1, frequency = 15148, Q = 1.14},
}
