return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -4.5, frequency = 285, Q = 0.67},
    {name = "eq", gain = 2.3, frequency = 2067, Q = 2.94},
    {name = "eq", gain = 6.0, frequency = 4984, Q = 1.17},
    {name = "eq", gain = 2.9, frequency = 9287, Q = 2.00},
    {name = "eq", gain = -3.9, frequency = 21325, Q = 1.22},
    {name = "eq", gain = 2.2, frequency = 30, Q = 0.92},
    {name = "eq", gain = 0.7, frequency = 1270, Q = 1.60},
    {name = "eq", gain = -1.3, frequency = 1299, Q = 3.18},
    {name = "eq", gain = 2.1, frequency = 12001, Q = 1.06},
    {name = "eq", gain = -9.4, frequency = 19651, Q = 0.38},
}
