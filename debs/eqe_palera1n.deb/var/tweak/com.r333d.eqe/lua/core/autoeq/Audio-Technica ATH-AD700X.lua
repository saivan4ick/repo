return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 8.0, frequency = 33, Q = 0.59},
    {name = "eq", gain = -3.9, frequency = 379, Q = 0.11},
    {name = "eq", gain = 4.6, frequency = 2120, Q = 3.10},
    {name = "eq", gain = 7.5, frequency = 2795, Q = 1.95},
    {name = "eq", gain = 5.6, frequency = 7944, Q = 2.80},
    {name = "eq", gain = 1.0, frequency = 586, Q = 1.68},
    {name = "eq", gain = -1.1, frequency = 1198, Q = 2.59},
    {name = "eq", gain = -2.6, frequency = 3984, Q = 8.30},
    {name = "eq", gain = 1.6, frequency = 11029, Q = 0.33},
    {name = "eq", gain = -7.7, frequency = 19528, Q = 0.33},
}
