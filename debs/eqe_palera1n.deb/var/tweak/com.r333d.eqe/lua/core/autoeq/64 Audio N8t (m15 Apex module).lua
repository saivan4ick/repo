return {
    {name = "preamp", gain = -5.4},
    {name = "eq", gain = -2.8, frequency = 28, Q = 0.40},
    {name = "eq", gain = -3.8, frequency = 125, Q = 0.45},
    {name = "eq", gain = 4.6, frequency = 3188, Q = 1.67},
    {name = "eq", gain = 2.6, frequency = 8378, Q = 0.76},
    {name = "eq", gain = 1.7, frequency = 22049, Q = 2.20},
    {name = "eq", gain = 1.0, frequency = 934, Q = 1.99},
    {name = "eq", gain = -0.9, frequency = 1395, Q = 2.73},
    {name = "eq", gain = -3.2, frequency = 5215, Q = 6.04},
    {name = "eq", gain = 3.5, frequency = 6064, Q = 2.80},
    {name = "eq", gain = -2.8, frequency = 7132, Q = 4.35},
}
