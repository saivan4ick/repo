return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 7.8, frequency = 67, Q = 0.25},
    {name = "eq", gain = -11.1, frequency = 250, Q = 0.82},
    {name = "eq", gain = 7.1, frequency = 1624, Q = 2.28},
    {name = "eq", gain = -9.6, frequency = 4691, Q = 4.75},
    {name = "eq", gain = -2.7, frequency = 10888, Q = 3.45},
    {name = "eq", gain = 3.9, frequency = 118, Q = 3.69},
    {name = "eq", gain = -3.7, frequency = 149, Q = 3.92},
    {name = "eq", gain = 1.2, frequency = 878, Q = 1.39},
    {name = "eq", gain = -3.0, frequency = 943, Q = 4.92},
    {name = "eq", gain = 5.0, frequency = 19454, Q = 0.90},
}
