return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 10.6, frequency = 24, Q = 1.43},
    {name = "eq", gain = -7.9, frequency = 103, Q = 0.21},
    {name = "eq", gain = 7.4, frequency = 1336, Q = 0.29},
    {name = "eq", gain = -10.5, frequency = 1369, Q = 1.06},
    {name = "eq", gain = 5.4, frequency = 8261, Q = 1.05},
    {name = "eq", gain = 1.6, frequency = 643, Q = 3.68},
    {name = "eq", gain = -1.7, frequency = 912, Q = 4.78},
    {name = "eq", gain = 1.5, frequency = 3151, Q = 1.72},
    {name = "eq", gain = -2.7, frequency = 4282, Q = 1.34},
    {name = "eq", gain = 3.2, frequency = 5174, Q = 3.24},
}
