return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 4.0, frequency = 20, Q = 0.71},
    {name = "eq", gain = -4.0, frequency = 201, Q = 0.73},
    {name = "eq", gain = 4.9, frequency = 2914, Q = 1.88},
    {name = "eq", gain = 4.3, frequency = 12144, Q = 1.40},
    {name = "eq", gain = 6.3, frequency = 18583, Q = 0.49},
    {name = "eq", gain = -0.9, frequency = 380, Q = 2.07},
    {name = "eq", gain = 2.0, frequency = 913, Q = 1.61},
    {name = "eq", gain = 3.0, frequency = 4195, Q = 3.77},
    {name = "eq", gain = -4.7, frequency = 5530, Q = 2.16},
    {name = "eq", gain = 2.4, frequency = 8178, Q = 2.97},
}
