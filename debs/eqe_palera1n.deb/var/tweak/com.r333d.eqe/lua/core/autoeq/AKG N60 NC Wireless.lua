return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 6.8, frequency = 27, Q = 0.81},
    {name = "eq", gain = -4.0, frequency = 121, Q = 0.79},
    {name = "eq", gain = -6.3, frequency = 3617, Q = 3.70},
    {name = "eq", gain = -7.5, frequency = 5597, Q = 2.91},
    {name = "eq", gain = 7.3, frequency = 9779, Q = 2.63},
    {name = "eq", gain = -1.3, frequency = 230, Q = 2.75},
    {name = "eq", gain = 2.0, frequency = 563, Q = 1.44},
    {name = "eq", gain = 2.3, frequency = 1888, Q = 2.95},
    {name = "eq", gain = 2.8, frequency = 11745, Q = 1.78},
    {name = "eq", gain = -14.9, frequency = 19778, Q = 0.56},
}
