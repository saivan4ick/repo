return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 2.9, frequency = 30, Q = 0.59},
    {name = "eq", gain = 6.5, frequency = 2056, Q = 2.67},
    {name = "eq", gain = -2.7, frequency = 3980, Q = 0.00},
    {name = "eq", gain = 8.4, frequency = 4048, Q = 2.22},
    {name = "eq", gain = 7.1, frequency = 10356, Q = 1.29},
    {name = "eq", gain = 2.8, frequency = 20, Q = 1.36},
    {name = "eq", gain = 1.8, frequency = 69, Q = 0.94},
    {name = "eq", gain = 1.3, frequency = 431, Q = 0.97},
    {name = "eq", gain = -2.0, frequency = 1046, Q = 4.08},
    {name = "eq", gain = -2.5, frequency = 6043, Q = 6.95},
}
