return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 5.3, frequency = 17, Q = 0.76},
    {name = "eq", gain = -7.6, frequency = 181, Q = 0.38},
    {name = "eq", gain = 5.8, frequency = 1723, Q = 0.92},
    {name = "eq", gain = 2.9, frequency = 2872, Q = 2.22},
    {name = "eq", gain = 6.3, frequency = 13803, Q = 0.49},
    {name = "eq", gain = 0.9, frequency = 685, Q = 4.09},
    {name = "eq", gain = 1.4, frequency = 4315, Q = 3.86},
    {name = "eq", gain = -2.2, frequency = 6216, Q = 1.67},
    {name = "eq", gain = 2.1, frequency = 8974, Q = 2.14},
    {name = "eq", gain = -0.8, frequency = 14516, Q = 2.19},
}
