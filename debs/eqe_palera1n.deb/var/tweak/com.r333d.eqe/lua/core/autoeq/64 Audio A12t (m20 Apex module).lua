return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -4.0, frequency = 68, Q = 0.23},
    {name = "eq", gain = 7.0, frequency = 3182, Q = 2.76},
    {name = "eq", gain = 3.5, frequency = 6131, Q = 4.80},
    {name = "eq", gain = 2.9, frequency = 8194, Q = 4.01},
    {name = "eq", gain = -0.7, frequency = 1152, Q = 1.01},
    {name = "eq", gain = -1.1, frequency = 2105, Q = 2.10},
    {name = "eq", gain = 2.2, frequency = 2619, Q = 5.25},
    {name = "eq", gain = 2.7, frequency = 10210, Q = 1.20},
    {name = "eq", gain = -11.3, frequency = 19517, Q = 0.33},
}
