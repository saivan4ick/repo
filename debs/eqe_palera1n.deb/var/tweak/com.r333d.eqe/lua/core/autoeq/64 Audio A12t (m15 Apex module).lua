return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = -3.7, frequency = 85, Q = 0.27},
    {name = "eq", gain = 7.0, frequency = 3185, Q = 2.79},
    {name = "eq", gain = 3.4, frequency = 6134, Q = 4.49},
    {name = "eq", gain = 2.8, frequency = 8210, Q = 3.88},
    {name = "eq", gain = -1.0, frequency = 1422, Q = 1.15},
    {name = "eq", gain = 1.5, frequency = 3847, Q = 4.36},
    {name = "eq", gain = -2.3, frequency = 4764, Q = 6.35},
    {name = "eq", gain = 2.8, frequency = 10246, Q = 0.88},
    {name = "eq", gain = -11.3, frequency = 19648, Q = 0.29},
}
