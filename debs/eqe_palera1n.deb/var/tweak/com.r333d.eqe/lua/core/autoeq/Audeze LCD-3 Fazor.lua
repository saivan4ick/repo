return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = 6.1, frequency = 21, Q = 0.45},
    {name = "eq", gain = -2.0, frequency = 269, Q = 0.19},
    {name = "eq", gain = 5.3, frequency = 3598, Q = 3.05},
    {name = "eq", gain = 13.7, frequency = 9507, Q = 0.60},
    {name = "eq", gain = -11.3, frequency = 19106, Q = 0.07},
    {name = "eq", gain = 1.3, frequency = 2382, Q = 5.13},
    {name = "eq", gain = 1.7, frequency = 4111, Q = 6.49},
    {name = "eq", gain = -3.8, frequency = 5233, Q = 3.86},
    {name = "eq", gain = 2.5, frequency = 6943, Q = 3.31},
    {name = "eq", gain = -1.0, frequency = 9795, Q = 3.75},
}
