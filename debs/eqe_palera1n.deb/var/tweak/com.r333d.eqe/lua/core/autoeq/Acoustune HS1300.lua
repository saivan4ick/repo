return {
    {name = "preamp", gain = -5.3},
    {name = "eq", gain = -3.7, frequency = 105, Q = 0.50},
    {name = "eq", gain = 6.1, frequency = 3594, Q = 3.04},
    {name = "eq", gain = 7.6, frequency = 8326, Q = 1.33},
    {name = "eq", gain = 7.8, frequency = 12745, Q = 0.75},
    {name = "eq", gain = -8.6, frequency = 18973, Q = 0.10},
    {name = "eq", gain = 2.3, frequency = 811, Q = 1.79},
    {name = "eq", gain = 2.3, frequency = 4364, Q = 5.28},
    {name = "eq", gain = -5.2, frequency = 5206, Q = 3.60},
    {name = "eq", gain = 3.9, frequency = 6240, Q = 3.89},
    {name = "eq", gain = -1.4, frequency = 7553, Q = 3.99},
}
