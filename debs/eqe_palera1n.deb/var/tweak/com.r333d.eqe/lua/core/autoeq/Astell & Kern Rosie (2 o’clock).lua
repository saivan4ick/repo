return {
    {name = "preamp", gain = -6.1},
    {name = "eq", gain = -4.7, frequency = 113, Q = 0.60},
    {name = "eq", gain = -3.8, frequency = 268, Q = 1.05},
    {name = "eq", gain = 4.3, frequency = 2926, Q = 0.79},
    {name = "eq", gain = 3.2, frequency = 4473, Q = 1.34},
    {name = "eq", gain = 2.4, frequency = 11940, Q = 2.05},
    {name = "eq", gain = 2.1, frequency = 915, Q = 2.98},
    {name = "eq", gain = 3.7, frequency = 6244, Q = 5.39},
    {name = "eq", gain = -2.2, frequency = 7572, Q = 1.99},
    {name = "eq", gain = 1.9, frequency = 10136, Q = 4.29},
    {name = "eq", gain = -0.2, frequency = 12147, Q = 0.01},
}
