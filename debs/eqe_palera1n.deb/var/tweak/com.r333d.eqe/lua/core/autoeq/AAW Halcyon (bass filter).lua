return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -1.3, frequency = 41, Q = 0.19},
    {name = "eq", gain = -3.9, frequency = 163, Q = 0.37},
    {name = "eq", gain = 5.8, frequency = 2704, Q = 2.40},
    {name = "eq", gain = 5.6, frequency = 4063, Q = 2.68},
    {name = "eq", gain = 3.4, frequency = 8779, Q = 3.06},
    {name = "eq", gain = -2.2, frequency = 1440, Q = 2.02},
    {name = "eq", gain = 1.1, frequency = 1543, Q = 0.77},
    {name = "eq", gain = 2.3, frequency = 10803, Q = 1.14},
    {name = "eq", gain = 2.2, frequency = 11837, Q = 1.07},
    {name = "eq", gain = -15.5, frequency = 19754, Q = 0.34},
}
