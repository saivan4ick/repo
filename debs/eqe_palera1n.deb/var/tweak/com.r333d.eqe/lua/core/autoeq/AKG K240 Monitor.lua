return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.8, frequency = 28, Q = 0.62},
    {name = "eq", gain = -3.3, frequency = 198, Q = 0.30},
    {name = "eq", gain = -5.9, frequency = 3718, Q = 4.51},
    {name = "eq", gain = 2.6, frequency = 5342, Q = 1.59},
    {name = "eq", gain = 1.8, frequency = 5816, Q = 0.11},
    {name = "eq", gain = 0.3, frequency = 35, Q = 2.49},
    {name = "eq", gain = 0.5, frequency = 468, Q = 0.96},
    {name = "eq", gain = 1.1, frequency = 2815, Q = 4.10},
    {name = "eq", gain = 2.0, frequency = 6432, Q = 4.97},
    {name = "eq", gain = -1.1, frequency = 9298, Q = 1.30},
}
