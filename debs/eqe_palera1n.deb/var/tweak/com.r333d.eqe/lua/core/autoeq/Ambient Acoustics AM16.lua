return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -3.6, frequency = 179, Q = 0.53},
    {name = "eq", gain = -2.5, frequency = 1481, Q = 2.20},
    {name = "eq", gain = 7.1, frequency = 3155, Q = 2.13},
    {name = "eq", gain = -4.8, frequency = 7126, Q = 3.80},
    {name = "eq", gain = 2.8, frequency = 9812, Q = 1.98},
    {name = "eq", gain = 1.7, frequency = 21, Q = 1.60},
    {name = "eq", gain = 1.9, frequency = 3934, Q = 4.93},
    {name = "eq", gain = -3.9, frequency = 5173, Q = 3.32},
    {name = "eq", gain = 1.0, frequency = 5705, Q = 4.18},
    {name = "eq", gain = 2.4, frequency = 5774, Q = 5.13},
}
