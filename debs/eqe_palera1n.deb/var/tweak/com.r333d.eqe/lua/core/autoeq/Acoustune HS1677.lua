return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -2.8, frequency = 75, Q = 0.70},
    {name = "eq", gain = -2.2, frequency = 167, Q = 1.76},
    {name = "eq", gain = 6.2, frequency = 3830, Q = 2.88},
    {name = "eq", gain = -7.0, frequency = 5515, Q = 6.54},
    {name = "eq", gain = 3.3, frequency = 9350, Q = 2.72},
    {name = "eq", gain = 2.3, frequency = 486, Q = 2.41},
    {name = "eq", gain = 1.2, frequency = 885, Q = 1.96},
    {name = "eq", gain = -3.0, frequency = 2396, Q = 1.63},
    {name = "eq", gain = 3.1, frequency = 3085, Q = 3.87},
    {name = "eq", gain = 0.8, frequency = 6581, Q = 4.67},
}
