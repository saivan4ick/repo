return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -2.7, frequency = 232, Q = 1.34},
    {name = "eq", gain = -4.8, frequency = 1000, Q = 0.62},
    {name = "eq", gain = 4.8, frequency = 1990, Q = 1.50},
    {name = "eq", gain = 6.2, frequency = 3915, Q = 3.01},
    {name = "eq", gain = 6.5, frequency = 9199, Q = 1.99},
    {name = "eq", gain = 2.1, frequency = 28, Q = 0.69},
    {name = "eq", gain = 3.0, frequency = 7113, Q = 5.10},
    {name = "eq", gain = 3.8, frequency = 11291, Q = 2.51},
    {name = "eq", gain = 4.0, frequency = 13757, Q = 1.32},
    {name = "eq", gain = -16.6, frequency = 19875, Q = 0.33},
}
