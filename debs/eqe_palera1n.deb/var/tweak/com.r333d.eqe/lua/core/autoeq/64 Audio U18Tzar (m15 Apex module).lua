return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = -4.0, frequency = 72, Q = 0.77},
    {name = "eq", gain = -4.4, frequency = 208, Q = 0.62},
    {name = "eq", gain = 1.6, frequency = 882, Q = 1.80},
    {name = "eq", gain = 4.4, frequency = 3014, Q = 1.51},
    {name = "eq", gain = 3.6, frequency = 4687, Q = 1.22},
    {name = "eq", gain = 1.5, frequency = 18, Q = 2.01},
    {name = "eq", gain = 2.1, frequency = 9561, Q = 1.87},
    {name = "eq", gain = 1.8, frequency = 11892, Q = 1.21},
    {name = "eq", gain = -5.6, frequency = 19624, Q = 0.25},
    {name = "eq", gain = -5.3, frequency = 19994, Q = 0.55},
}
