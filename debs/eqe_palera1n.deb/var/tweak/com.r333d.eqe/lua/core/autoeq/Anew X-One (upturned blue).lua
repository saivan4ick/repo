return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.8, frequency = 32, Q = 0.44},
    {name = "eq", gain = -2.0, frequency = 844, Q = 0.07},
    {name = "eq", gain = 6.5, frequency = 3905, Q = 3.05},
    {name = "eq", gain = 5.9, frequency = 5628, Q = 2.45},
    {name = "eq", gain = 2.7, frequency = 10402, Q = 0.80},
    {name = "eq", gain = -1.0, frequency = 269, Q = 1.48},
    {name = "eq", gain = 2.0, frequency = 1057, Q = 0.65},
    {name = "eq", gain = -2.3, frequency = 1496, Q = 1.09},
    {name = "eq", gain = 0.2, frequency = 16719, Q = 2.20},
}
