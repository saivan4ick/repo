return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.2, frequency = 20, Q = 0.79},
    {name = "eq", gain = -2.9, frequency = 197, Q = 0.71},
    {name = "eq", gain = -5.6, frequency = 1897, Q = 0.29},
    {name = "eq", gain = 10.8, frequency = 1983, Q = 1.31},
    {name = "eq", gain = 8.4, frequency = 8834, Q = 0.83},
    {name = "eq", gain = -2.2, frequency = 3558, Q = 6.64},
    {name = "eq", gain = 3.3, frequency = 4547, Q = 4.63},
    {name = "eq", gain = 3.3, frequency = 6879, Q = 7.34},
    {name = "eq", gain = 7.7, frequency = 13462, Q = 0.79},
    {name = "eq", gain = -7.2, frequency = 18527, Q = 0.15},
}
