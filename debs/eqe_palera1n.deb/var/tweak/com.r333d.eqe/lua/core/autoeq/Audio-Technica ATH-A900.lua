return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 6.3, frequency = 26, Q = 0.68},
    {name = "eq", gain = -4.7, frequency = 432, Q = 2.61},
    {name = "eq", gain = -3.6, frequency = 1239, Q = 0.95},
    {name = "eq", gain = -1.7, frequency = 2705, Q = 1.81},
    {name = "eq", gain = 7.1, frequency = 7041, Q = 1.17},
    {name = "eq", gain = -1.4, frequency = 56, Q = 4.13},
    {name = "eq", gain = 2.9, frequency = 227, Q = 1.70},
    {name = "eq", gain = -2.3, frequency = 346, Q = 4.13},
    {name = "eq", gain = 2.6, frequency = 10470, Q = 1.64},
    {name = "eq", gain = -10.3, frequency = 19630, Q = 0.47},
}
