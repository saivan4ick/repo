return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -3.4, frequency = 116, Q = 0.77},
    {name = "eq", gain = -9.8, frequency = 373, Q = 0.39},
    {name = "eq", gain = 8.7, frequency = 1617, Q = 0.36},
    {name = "eq", gain = -8.6, frequency = 5712, Q = 3.56},
    {name = "eq", gain = 5.7, frequency = 13544, Q = 0.39},
    {name = "eq", gain = 1.9, frequency = 19, Q = 1.49},
    {name = "eq", gain = 2.3, frequency = 1316, Q = 2.73},
    {name = "eq", gain = -1.1, frequency = 1555, Q = 0.72},
    {name = "eq", gain = 1.8, frequency = 4238, Q = 4.33},
    {name = "eq", gain = -1.0, frequency = 7447, Q = 4.72},
}
