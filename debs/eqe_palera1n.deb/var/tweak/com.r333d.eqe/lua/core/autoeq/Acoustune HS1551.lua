return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -5.1, frequency = 150, Q = 0.59},
    {name = "eq", gain = 6.8, frequency = 3403, Q = 2.27},
    {name = "eq", gain = -5.9, frequency = 5610, Q = 5.30},
    {name = "eq", gain = 3.2, frequency = 8519, Q = 1.19},
    {name = "eq", gain = 3.8, frequency = 11338, Q = 1.93},
    {name = "eq", gain = 1.2, frequency = 20, Q = 1.69},
    {name = "eq", gain = 3.8, frequency = 916, Q = 1.33},
    {name = "eq", gain = -3.9, frequency = 1699, Q = 0.76},
    {name = "eq", gain = 4.1, frequency = 2678, Q = 3.68},
    {name = "eq", gain = 1.9, frequency = 4065, Q = 6.47},
}
