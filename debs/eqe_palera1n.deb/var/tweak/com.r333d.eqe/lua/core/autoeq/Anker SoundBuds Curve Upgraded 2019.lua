return {
    {name = "preamp", gain = -6.1},
    {name = "eq", gain = -8.9, frequency = 29, Q = 0.24},
    {name = "eq", gain = -5.8, frequency = 137, Q = 0.73},
    {name = "eq", gain = 4.3, frequency = 295, Q = 0.30},
    {name = "eq", gain = -4.1, frequency = 5282, Q = 4.22},
    {name = "eq", gain = 5.9, frequency = 19187, Q = 0.17},
    {name = "eq", gain = 1.1, frequency = 821, Q = 2.47},
    {name = "eq", gain = -1.6, frequency = 1333, Q = 2.42},
    {name = "eq", gain = 2.3, frequency = 3602, Q = 2.85},
    {name = "eq", gain = -2.8, frequency = 6951, Q = 4.88},
    {name = "eq", gain = 1.2, frequency = 8386, Q = 3.95},
}
