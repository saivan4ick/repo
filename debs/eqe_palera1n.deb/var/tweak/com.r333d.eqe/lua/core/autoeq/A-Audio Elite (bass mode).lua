return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -1.6, frequency = 88, Q = 0.03},
    {name = "eq", gain = -7.0, frequency = 1041, Q = 1.33},
    {name = "eq", gain = 7.0, frequency = 2417, Q = 1.03},
    {name = "eq", gain = 3.6, frequency = 8141, Q = 1.12},
    {name = "eq", gain = 6.2, frequency = 17931, Q = 0.24},
    {name = "eq", gain = -2.6, frequency = 16, Q = 1.34},
    {name = "eq", gain = 1.8, frequency = 52, Q = 0.78},
    {name = "eq", gain = -2.3, frequency = 244, Q = 0.68},
    {name = "eq", gain = 2.8, frequency = 342, Q = 1.79},
    {name = "eq", gain = -1.9, frequency = 4679, Q = 4.56},
}
