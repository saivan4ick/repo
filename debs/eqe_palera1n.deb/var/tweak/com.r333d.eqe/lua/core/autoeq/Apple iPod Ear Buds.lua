return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 7.0, frequency = 65, Q = 0.19},
    {name = "eq", gain = -6.7, frequency = 322, Q = 0.81},
    {name = "eq", gain = -8.9, frequency = 3146, Q = 3.95},
    {name = "eq", gain = 4.7, frequency = 5447, Q = 0.39},
    {name = "eq", gain = -10.5, frequency = 6388, Q = 1.95},
    {name = "eq", gain = 0.7, frequency = 17, Q = 2.33},
    {name = "eq", gain = 2.1, frequency = 141, Q = 3.61},
    {name = "eq", gain = -1.2, frequency = 222, Q = 3.26},
    {name = "eq", gain = 2.2, frequency = 2145, Q = 6.59},
    {name = "eq", gain = -0.8, frequency = 8794, Q = 4.39},
}
