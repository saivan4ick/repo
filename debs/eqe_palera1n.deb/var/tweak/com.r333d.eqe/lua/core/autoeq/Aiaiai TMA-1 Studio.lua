return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 7.0, frequency = 23, Q = 1.00},
    {name = "eq", gain = -2.3, frequency = 63, Q = 0.67},
    {name = "eq", gain = -4.1, frequency = 198, Q = 0.42},
    {name = "eq", gain = 5.7, frequency = 2402, Q = 1.70},
    {name = "eq", gain = 5.1, frequency = 4566, Q = 2.32},
    {name = "eq", gain = 1.6, frequency = 729, Q = 3.92},
    {name = "eq", gain = -2.3, frequency = 1082, Q = 2.90},
    {name = "eq", gain = 1.0, frequency = 1808, Q = 4.43},
    {name = "eq", gain = 1.2, frequency = 9754, Q = 1.66},
    {name = "eq", gain = -3.5, frequency = 19816, Q = 0.37},
}
