return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -1.5, frequency = 77, Q = 0.25},
    {name = "eq", gain = -7.0, frequency = 1857, Q = 2.06},
    {name = "eq", gain = 5.6, frequency = 2642, Q = 2.19},
    {name = "eq", gain = 6.3, frequency = 5500, Q = 2.45},
    {name = "eq", gain = 6.6, frequency = 18528, Q = 0.52},
    {name = "eq", gain = 1.0, frequency = 670, Q = 2.37},
    {name = "eq", gain = -2.5, frequency = 3995, Q = 6.00},
    {name = "eq", gain = 2.6, frequency = 4554, Q = 2.07},
    {name = "eq", gain = -2.5, frequency = 5918, Q = 1.62},
    {name = "eq", gain = 2.8, frequency = 6315, Q = 5.97},
}
