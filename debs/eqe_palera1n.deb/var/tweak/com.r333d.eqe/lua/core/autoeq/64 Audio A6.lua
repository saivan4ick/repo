return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -4.3, frequency = 25, Q = 0.05},
    {name = "eq", gain = 4.2, frequency = 3095, Q = 1.36},
    {name = "eq", gain = 5.3, frequency = 6130, Q = 2.91},
    {name = "eq", gain = 4.0, frequency = 8995, Q = 3.06},
    {name = "eq", gain = 0.9, frequency = 464, Q = 0.47},
    {name = "eq", gain = -1.6, frequency = 554, Q = 0.95},
    {name = "eq", gain = 0.9, frequency = 969, Q = 2.74},
    {name = "eq", gain = 3.7, frequency = 11415, Q = 1.08},
    {name = "eq", gain = -13.1, frequency = 19544, Q = 0.36},
}
