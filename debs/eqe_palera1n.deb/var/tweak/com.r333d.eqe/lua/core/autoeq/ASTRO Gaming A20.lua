return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 4.8, frequency = 20, Q = 1.30},
    {name = "eq", gain = -3.7, frequency = 69, Q = 0.96},
    {name = "eq", gain = -3.3, frequency = 139, Q = 1.67},
    {name = "eq", gain = 6.1, frequency = 1842, Q = 0.85},
    {name = "eq", gain = -9.8, frequency = 5765, Q = 1.94},
    {name = "eq", gain = 3.4, frequency = 409, Q = 3.08},
    {name = "eq", gain = -0.9, frequency = 1092, Q = 3.25},
    {name = "eq", gain = 2.6, frequency = 2384, Q = 2.72},
    {name = "eq", gain = -2.5, frequency = 3283, Q = 1.30},
    {name = "eq", gain = 3.5, frequency = 4589, Q = 5.95},
}
