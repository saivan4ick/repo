return {
    {name = "preamp", gain = -7.6},
    {name = "eq", gain = 3.6, frequency = 19, Q = 1.84},
    {name = "eq", gain = -5.2, frequency = 234, Q = 0.44},
    {name = "eq", gain = 6.9, frequency = 2212, Q = 2.69},
    {name = "eq", gain = 5.3, frequency = 7703, Q = 2.32},
    {name = "eq", gain = 6.1, frequency = 11566, Q = 1.61},
    {name = "eq", gain = 3.9, frequency = 782, Q = 3.58},
    {name = "eq", gain = -3.0, frequency = 1104, Q = 1.88},
    {name = "eq", gain = 1.5, frequency = 3068, Q = 0.67},
    {name = "eq", gain = -4.2, frequency = 3833, Q = 3.59},
    {name = "eq", gain = -7.7, frequency = 19532, Q = 1.10},
}
