return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -4.4, frequency = 19, Q = 2.31},
    {name = "eq", gain = -10.6, frequency = 55, Q = 1.08},
    {name = "eq", gain = 6.2, frequency = 4699, Q = 0.51},
    {name = "eq", gain = -13.7, frequency = 7081, Q = 1.67},
    {name = "eq", gain = 6.3, frequency = 17526, Q = 0.26},
    {name = "eq", gain = -7.1, frequency = 274, Q = 1.27},
    {name = "eq", gain = 3.5, frequency = 319, Q = 0.54},
    {name = "eq", gain = -1.0, frequency = 2899, Q = 2.15},
    {name = "eq", gain = 1.8, frequency = 5416, Q = 2.50},
    {name = "eq", gain = -2.0, frequency = 6317, Q = 4.68},
}
