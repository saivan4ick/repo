return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 2.9, frequency = 22, Q = 1.06},
    {name = "eq", gain = -2.9, frequency = 218, Q = 0.76},
    {name = "eq", gain = -4.6, frequency = 856, Q = 1.09},
    {name = "eq", gain = 6.7, frequency = 3252, Q = 0.93},
    {name = "eq", gain = -5.8, frequency = 5330, Q = 3.69},
    {name = "eq", gain = -1.2, frequency = 1134, Q = 5.36},
    {name = "eq", gain = 1.6, frequency = 2179, Q = 1.35},
    {name = "eq", gain = -2.3, frequency = 2464, Q = 3.17},
    {name = "eq", gain = 4.7, frequency = 10267, Q = 1.05},
    {name = "eq", gain = -17.0, frequency = 19623, Q = 0.34},
}
