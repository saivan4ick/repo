return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -3.7, frequency = 62, Q = 1.51},
    {name = "eq", gain = -4.6, frequency = 132, Q = 0.74},
    {name = "eq", gain = 7.5, frequency = 613, Q = 2.57},
    {name = "eq", gain = -8.3, frequency = 1120, Q = 2.48},
    {name = "eq", gain = 6.1, frequency = 3732, Q = 2.09},
    {name = "eq", gain = 3.8, frequency = 21, Q = 2.63},
    {name = "eq", gain = -1.7, frequency = 1474, Q = 4.27},
    {name = "eq", gain = 4.1, frequency = 2086, Q = 2.80},
    {name = "eq", gain = 3.6, frequency = 4427, Q = 5.79},
    {name = "eq", gain = -2.2, frequency = 19707, Q = 0.04},
}
