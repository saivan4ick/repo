return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -3.3, frequency = 179, Q = 0.37},
    {name = "eq", gain = -2.2, frequency = 1726, Q = 2.21},
    {name = "eq", gain = 3.5, frequency = 3304, Q = 2.27},
    {name = "eq", gain = 4.8, frequency = 7077, Q = 1.35},
    {name = "eq", gain = 4.5, frequency = 11115, Q = 1.24},
    {name = "eq", gain = -0.7, frequency = 68, Q = 4.12},
    {name = "eq", gain = 1.2, frequency = 914, Q = 4.04},
    {name = "eq", gain = 1.5, frequency = 5914, Q = 12.59},
    {name = "eq", gain = 1.1, frequency = 14834, Q = 1.88},
    {name = "eq", gain = -3.5, frequency = 20143, Q = 0.58},
}
