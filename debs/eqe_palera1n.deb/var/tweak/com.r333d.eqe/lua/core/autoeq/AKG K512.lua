return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 7.0, frequency = 25, Q = 1.24},
    {name = "eq", gain = -6.0, frequency = 215, Q = 0.42},
    {name = "eq", gain = -1.5, frequency = 589, Q = 0.52},
    {name = "eq", gain = -4.5, frequency = 1176, Q = 1.53},
    {name = "eq", gain = 7.1, frequency = 4048, Q = 0.43},
    {name = "eq", gain = -1.3, frequency = 63, Q = 3.16},
    {name = "eq", gain = 1.0, frequency = 97, Q = 3.09},
    {name = "eq", gain = 0.1, frequency = 404, Q = 3.59},
    {name = "eq", gain = 3.2, frequency = 9071, Q = 2.14},
    {name = "eq", gain = -6.6, frequency = 19696, Q = 0.33},
}
