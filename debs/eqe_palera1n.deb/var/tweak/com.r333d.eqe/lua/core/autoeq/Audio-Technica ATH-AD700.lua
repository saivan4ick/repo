return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 6.6, frequency = 33, Q = 0.55},
    {name = "eq", gain = -3.8, frequency = 1418, Q = 0.79},
    {name = "eq", gain = 2.1, frequency = 1807, Q = 2.22},
    {name = "eq", gain = -3.1, frequency = 5282, Q = 3.49},
    {name = "eq", gain = 6.3, frequency = 6784, Q = 1.62},
    {name = "eq", gain = 1.2, frequency = 66, Q = 3.05},
    {name = "eq", gain = -1.4, frequency = 197, Q = 1.61},
    {name = "eq", gain = -2.1, frequency = 3224, Q = 4.30},
    {name = "eq", gain = 3.6, frequency = 3847, Q = 3.77},
    {name = "eq", gain = -2.2, frequency = 4421, Q = 5.21},
}
