return {
    {name = "preamp", gain = -8.5},
    {name = "eq", gain = 5.3, frequency = 25, Q = 0.99},
    {name = "eq", gain = -3.3, frequency = 258, Q = 0.78},
    {name = "eq", gain = -3.6, frequency = 788, Q = 1.59},
    {name = "eq", gain = 4.6, frequency = 3251, Q = 1.26},
    {name = "eq", gain = 5.4, frequency = 9448, Q = 2.20},
    {name = "eq", gain = 1.1, frequency = 2033, Q = 2.37},
    {name = "eq", gain = 1.6, frequency = 4007, Q = 2.49},
    {name = "eq", gain = 2.3, frequency = 10161, Q = 1.86},
    {name = "eq", gain = 2.0, frequency = 11757, Q = 1.82},
    {name = "eq", gain = -3.8, frequency = 21890, Q = 0.03},
}
