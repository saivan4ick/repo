return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.4, frequency = 23, Q = 1.24},
    {name = "eq", gain = -5.1, frequency = 145, Q = 1.05},
    {name = "eq", gain = 5.1, frequency = 304, Q = 1.31},
    {name = "eq", gain = 6.3, frequency = 1954, Q = 1.91},
    {name = "eq", gain = -4.0, frequency = 2733, Q = 0.92},
    {name = "eq", gain = 2.2, frequency = 413, Q = 4.65},
    {name = "eq", gain = -1.2, frequency = 478, Q = 1.74},
    {name = "eq", gain = 1.5, frequency = 4657, Q = 4.48},
    {name = "eq", gain = -2.7, frequency = 5734, Q = 4.48},
    {name = "eq", gain = 1.9, frequency = 8961, Q = 2.45},
}
