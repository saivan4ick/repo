return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -8.0, frequency = 18, Q = 0.16},
    {name = "eq", gain = -7.2, frequency = 170, Q = 0.44},
    {name = "eq", gain = -6.7, frequency = 1960, Q = 1.30},
    {name = "eq", gain = 8.1, frequency = 3134, Q = 0.54},
    {name = "eq", gain = 4.3, frequency = 9150, Q = 1.51},
    {name = "eq", gain = -1.0, frequency = 1337, Q = 4.52},
    {name = "eq", gain = 0.3, frequency = 3221, Q = 0.23},
    {name = "eq", gain = -0.8, frequency = 3998, Q = 3.69},
    {name = "eq", gain = 1.5, frequency = 12132, Q = 1.95},
    {name = "eq", gain = -6.4, frequency = 19779, Q = 0.47},
}
