return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.1, frequency = 23, Q = 0.62},
    {name = "eq", gain = -2.8, frequency = 156, Q = 1.05},
    {name = "eq", gain = 3.9, frequency = 2461, Q = 2.34},
    {name = "eq", gain = -5.3, frequency = 3679, Q = 4.24},
    {name = "eq", gain = 3.3, frequency = 6935, Q = 3.97},
    {name = "eq", gain = 1.6, frequency = 495, Q = 2.06},
    {name = "eq", gain = -1.7, frequency = 1243, Q = 2.20},
    {name = "eq", gain = 0.7, frequency = 2062, Q = 2.75},
    {name = "eq", gain = 2.0, frequency = 9580, Q = 0.99},
    {name = "eq", gain = -9.8, frequency = 19693, Q = 0.30},
}
