return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -2.6, frequency = 16, Q = 0.80},
    {name = "eq", gain = -3.9, frequency = 104, Q = 0.44},
    {name = "eq", gain = -2.9, frequency = 280, Q = 0.79},
    {name = "eq", gain = 2.1, frequency = 1457, Q = 0.30},
    {name = "eq", gain = 4.4, frequency = 2335, Q = 2.05},
    {name = "eq", gain = 0.7, frequency = 926, Q = 2.74},
    {name = "eq", gain = -0.8, frequency = 1151, Q = 2.66},
    {name = "eq", gain = -2.7, frequency = 3475, Q = 3.97},
    {name = "eq", gain = 2.2, frequency = 4126, Q = 1.53},
    {name = "eq", gain = -2.3, frequency = 6718, Q = 3.64},
}
