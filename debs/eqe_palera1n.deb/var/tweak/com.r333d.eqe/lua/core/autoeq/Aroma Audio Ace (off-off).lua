return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 5.0, frequency = 16, Q = 0.45},
    {name = "eq", gain = -3.0, frequency = 201, Q = 0.61},
    {name = "eq", gain = -5.1, frequency = 1420, Q = 2.29},
    {name = "eq", gain = 2.8, frequency = 2209, Q = 2.32},
    {name = "eq", gain = 4.8, frequency = 2691, Q = 0.99},
    {name = "eq", gain = -2.6, frequency = 3986, Q = 5.95},
    {name = "eq", gain = 2.6, frequency = 4538, Q = 3.41},
    {name = "eq", gain = 1.6, frequency = 10737, Q = 1.11},
    {name = "eq", gain = -2.7, frequency = 18444, Q = 0.21},
    {name = "eq", gain = -3.0, frequency = 19995, Q = 0.55},
}
