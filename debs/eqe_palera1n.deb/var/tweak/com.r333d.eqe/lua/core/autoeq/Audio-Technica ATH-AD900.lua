return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.5, frequency = 35, Q = 0.41},
    {name = "eq", gain = -4.1, frequency = 1419, Q = 1.57},
    {name = "eq", gain = -7.3, frequency = 4225, Q = 2.30},
    {name = "eq", gain = 5.0, frequency = 4753, Q = 0.41},
    {name = "eq", gain = -6.3, frequency = 5664, Q = 2.35},
    {name = "eq", gain = -1.2, frequency = 170, Q = 3.79},
    {name = "eq", gain = 1.4, frequency = 2271, Q = 3.79},
    {name = "eq", gain = -2.0, frequency = 2998, Q = 2.79},
    {name = "eq", gain = 2.6, frequency = 3344, Q = 6.08},
    {name = "eq", gain = -0.3, frequency = 3587, Q = 3.08},
}
