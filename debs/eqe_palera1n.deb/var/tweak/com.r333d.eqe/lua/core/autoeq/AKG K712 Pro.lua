return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.1, frequency = 21, Q = 0.58},
    {name = "eq", gain = -3.6, frequency = 240, Q = 0.80},
    {name = "eq", gain = 5.2, frequency = 1163, Q = 2.14},
    {name = "eq", gain = 3.5, frequency = 3177, Q = 4.54},
    {name = "eq", gain = 4.4, frequency = 10591, Q = 3.07},
    {name = "eq", gain = -4.5, frequency = 2169, Q = 3.68},
    {name = "eq", gain = 1.7, frequency = 2583, Q = 0.83},
    {name = "eq", gain = -3.6, frequency = 5842, Q = 2.26},
    {name = "eq", gain = -0.1, frequency = 8948, Q = 3.51},
    {name = "eq", gain = 1.8, frequency = 9017, Q = 5.04},
}
