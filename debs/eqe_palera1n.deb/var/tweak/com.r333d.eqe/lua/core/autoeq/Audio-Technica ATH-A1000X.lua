return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 6.7, frequency = 22, Q = 1.44},
    {name = "eq", gain = -2.7, frequency = 248, Q = 0.03},
    {name = "eq", gain = 6.7, frequency = 3397, Q = 3.23},
    {name = "eq", gain = 8.3, frequency = 6983, Q = 0.93},
    {name = "eq", gain = -11.0, frequency = 19170, Q = 0.49},
    {name = "eq", gain = -1.8, frequency = 136, Q = 2.05},
    {name = "eq", gain = 2.1, frequency = 348, Q = 1.47},
    {name = "eq", gain = 2.6, frequency = 1728, Q = 5.84},
    {name = "eq", gain = -4.1, frequency = 2012, Q = 3.62},
    {name = "eq", gain = 2.2, frequency = 2964, Q = 8.97},
}
