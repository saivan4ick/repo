return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 33, Q = 0.44},
    {name = "eq", gain = 3.8, frequency = 1758, Q = 0.23},
    {name = "eq", gain = -11.8, frequency = 2264, Q = 1.71},
    {name = "eq", gain = -3.7, frequency = 7815, Q = 2.03},
    {name = "eq", gain = -1.5, frequency = 17343, Q = 0.19},
    {name = "eq", gain = -0.2, frequency = 31, Q = 2.69},
    {name = "eq", gain = -0.4, frequency = 995, Q = 3.82},
    {name = "eq", gain = -1.6, frequency = 3976, Q = 5.17},
    {name = "eq", gain = 1.0, frequency = 5487, Q = 1.06},
    {name = "eq", gain = -1.7, frequency = 6622, Q = 3.79},
}
