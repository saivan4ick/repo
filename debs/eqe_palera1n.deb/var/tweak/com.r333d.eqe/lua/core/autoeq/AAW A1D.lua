return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 3.3, frequency = 16, Q = 0.95},
    {name = "eq", gain = -2.6, frequency = 83, Q = 0.68},
    {name = "eq", gain = -6.0, frequency = 238, Q = 0.44},
    {name = "eq", gain = 7.2, frequency = 2600, Q = 0.70},
    {name = "eq", gain = -9.3, frequency = 19462, Q = 0.31},
    {name = "eq", gain = 2.2, frequency = 1798, Q = 4.14},
    {name = "eq", gain = -1.1, frequency = 2247, Q = 1.00},
    {name = "eq", gain = 2.7, frequency = 4247, Q = 2.75},
    {name = "eq", gain = -2.0, frequency = 5916, Q = 1.81},
    {name = "eq", gain = 0.9, frequency = 11173, Q = 1.45},
}
