return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.7, frequency = 28, Q = 0.89},
    {name = "eq", gain = 1.8, frequency = 2668, Q = 4.22},
    {name = "eq", gain = -7.9, frequency = 5329, Q = 6.51},
    {name = "eq", gain = 3.7, frequency = 6111, Q = 1.27},
    {name = "eq", gain = 2.5, frequency = 11254, Q = 0.64},
    {name = "eq", gain = -2.8, frequency = 685, Q = 0.25},
    {name = "eq", gain = 4.8, frequency = 1333, Q = 2.53},
    {name = "eq", gain = -0.6, frequency = 3069, Q = 0.50},
    {name = "eq", gain = 3.0, frequency = 3381, Q = 1.27},
    {name = "eq", gain = -2.3, frequency = 3447, Q = 5.71},
}
