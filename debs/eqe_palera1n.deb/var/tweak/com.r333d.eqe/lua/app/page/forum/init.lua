local json = require 'dkjson'
local page = {}
page.title = 'Forum (beta)'
page.hide_nav_button = true
page.icon = IMG('person-stalker.png', PAGE_ICON_COLOR):retain()

local load_failed = require 'vc.load_failed'

local view_forum = require 'page.forum.threads'

local icon_cache = {}
local function loadicon(url, cb)
    local cache = icon_cache[url]
    if cache then
        if type(cache) == 'table' then
            table.insert(cache, cb)
        elseif type(cache) == 'cdata' then
            cb(cache)
        end
        return
    end
    icon_cache[url] = {}
    HTTP(url, {convert = 'image'}, function(img, status, headers)
        if not(img and status == 200) then return end
        img:retain()
        cb(img)
        for i,v in ipairs(icon_cache[url]) do
            v(img)
        end
        icon_cache[url] = img
    end)
end

function page:init()
    local function push(f, title)
        self.nav:pushViewController_animated(VIEWCONTROLLER(f, title), true)
    end
    local f = function(m)
        local target = ns.target:new()
        target.onaction = function()
            TOGGLE_NAV()
        end

        local nav_button = new_nav_button(0, 0)
        nav_button.ontoggle = TOGGLE_NAV

        local item = objc.UIBarButtonItem:alloc():initWithCustomView(nav_button.m)
        m:navigationItem():setLeftBarButtonItem(item)

        view_forum(push, loadicon)(m)
    end
    self.nav = objc.UINavigationController:alloc():initWithRootViewController(VIEWCONTROLLER(f))

    self.nav:navigationBar():setBarTintColor(objc.EQEMainView:themeColor())
    self.nav:navigationBar():setTintColor(objc.UIColor:whiteColor())
    self.nav:navigationBar():setTitleTextAttributes{[C.NSForegroundColorAttributeName] = objc.UIColor:whiteColor()}
    self.view = self.nav:view()
end

function page:navpressed(is_showing_list)
end

return page
