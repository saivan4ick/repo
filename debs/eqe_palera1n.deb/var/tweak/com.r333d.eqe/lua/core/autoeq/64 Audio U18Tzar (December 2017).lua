return {
    {name = "preamp", gain = -5.2},
    {name = "eq", gain = -4.6, frequency = 145, Q = 0.36},
    {name = "eq", gain = 1.8, frequency = 819, Q = 1.82},
    {name = "eq", gain = 3.5, frequency = 2825, Q = 2.60},
    {name = "eq", gain = 4.6, frequency = 5458, Q = 0.89},
    {name = "eq", gain = 2.1, frequency = 22049, Q = 2.50},
    {name = "eq", gain = -0.3, frequency = 1398, Q = 4.32},
    {name = "eq", gain = 0.8, frequency = 4361, Q = 5.77},
    {name = "eq", gain = 3.2, frequency = 9595, Q = 2.86},
    {name = "eq", gain = 2.7, frequency = 12372, Q = 1.49},
    {name = "eq", gain = -11.9, frequency = 19897, Q = 0.32},
}
