return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -2.7, frequency = 22, Q = 0.67},
    {name = "eq", gain = -4.9, frequency = 77, Q = 0.48},
    {name = "eq", gain = -6.5, frequency = 245, Q = 0.46},
    {name = "eq", gain = 5.7, frequency = 1385, Q = 0.43},
    {name = "eq", gain = 4.2, frequency = 4147, Q = 1.36},
    {name = "eq", gain = -2.0, frequency = 1583, Q = 2.76},
    {name = "eq", gain = 1.2, frequency = 1934, Q = 1.00},
    {name = "eq", gain = 2.2, frequency = 10505, Q = 2.92},
    {name = "eq", gain = 2.3, frequency = 13929, Q = 1.06},
    {name = "eq", gain = -5.7, frequency = 19567, Q = 0.18},
}
