return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -6.2, frequency = 90, Q = 1.20},
    {name = "eq", gain = -8.1, frequency = 159, Q = 0.68},
    {name = "eq", gain = 4.2, frequency = 806, Q = 0.73},
    {name = "eq", gain = 4.4, frequency = 2204, Q = 1.27},
    {name = "eq", gain = 5.0, frequency = 4393, Q = 2.94},
    {name = "eq", gain = 1.1, frequency = 18, Q = 0.53},
    {name = "eq", gain = -0.9, frequency = 58, Q = 2.19},
    {name = "eq", gain = -5.4, frequency = 6609, Q = 4.98},
    {name = "eq", gain = 1.4, frequency = 9725, Q = 0.85},
    {name = "eq", gain = 2.0, frequency = 16458, Q = 0.36},
}
