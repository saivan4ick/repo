return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 7.6, frequency = 2088, Q = 3.05},
    {name = "eq", gain = -1.8, frequency = 2814, Q = 2.64},
    {name = "eq", gain = -3.9, frequency = 3657, Q = 0.00},
    {name = "eq", gain = 8.4, frequency = 4293, Q = 1.96},
    {name = "eq", gain = 9.2, frequency = 9586, Q = 0.87},
    {name = "eq", gain = 5.1, frequency = 21, Q = 0.19},
    {name = "eq", gain = 1.9, frequency = 406, Q = 2.37},
    {name = "eq", gain = -4.4, frequency = 5972, Q = 5.29},
    {name = "eq", gain = 4.2, frequency = 6771, Q = 4.06},
    {name = "eq", gain = 2.8, frequency = 12335, Q = 3.15},
}
