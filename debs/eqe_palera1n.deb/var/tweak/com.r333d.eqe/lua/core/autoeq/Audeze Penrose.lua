return {
    {name = "preamp", gain = -5.9},
    {name = "eq", gain = -1.7, frequency = 271, Q = 0.21},
    {name = "eq", gain = 0.9, frequency = 739, Q = 3.50},
    {name = "eq", gain = 5.3, frequency = 4449, Q = 3.55},
    {name = "eq", gain = 4.2, frequency = 6813, Q = 2.04},
    {name = "eq", gain = -9.0, frequency = 19483, Q = 0.38},
    {name = "eq", gain = 1.9, frequency = 23, Q = 2.23},
    {name = "eq", gain = -1.0, frequency = 477, Q = 4.92},
    {name = "eq", gain = -2.8, frequency = 1648, Q = 2.35},
    {name = "eq", gain = 4.1, frequency = 2121, Q = 2.78},
    {name = "eq", gain = -1.0, frequency = 3434, Q = 4.42},
}
