return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -4.8, frequency = 181, Q = 0.58},
    {name = "eq", gain = 3.0, frequency = 710, Q = 2.30},
    {name = "eq", gain = 5.1, frequency = 4040, Q = 2.46},
    {name = "eq", gain = 5.2, frequency = 5996, Q = 2.36},
    {name = "eq", gain = 1.9, frequency = 9931, Q = 2.43},
    {name = "eq", gain = 1.7, frequency = 20, Q = 1.44},
    {name = "eq", gain = 0.7, frequency = 495, Q = 3.82},
    {name = "eq", gain = 1.7, frequency = 922, Q = 3.98},
    {name = "eq", gain = -2.1, frequency = 1703, Q = 0.96},
    {name = "eq", gain = 2.0, frequency = 2886, Q = 3.26},
}
