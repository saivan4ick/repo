return {
    {name = "preamp", gain = -4.4},
    {name = "eq", gain = -4.1, frequency = 198, Q = 0.65},
    {name = "eq", gain = 3.5, frequency = 901, Q = 1.13},
    {name = "eq", gain = 3.4, frequency = 2006, Q = 2.39},
    {name = "eq", gain = 4.3, frequency = 4774, Q = 2.39},
    {name = "eq", gain = -6.8, frequency = 6494, Q = 5.11},
    {name = "eq", gain = 1.3, frequency = 25, Q = 1.03},
    {name = "eq", gain = -0.1, frequency = 326, Q = 3.10},
    {name = "eq", gain = 0.4, frequency = 2386, Q = 6.22},
    {name = "eq", gain = 3.1, frequency = 10908, Q = 1.68},
    {name = "eq", gain = -11.1, frequency = 19529, Q = 0.45},
}
