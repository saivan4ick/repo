return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -4.0, frequency = 79, Q = 0.53},
    {name = "eq", gain = -5.1, frequency = 231, Q = 0.55},
    {name = "eq", gain = 6.7, frequency = 1735, Q = 0.44},
    {name = "eq", gain = -10.2, frequency = 5854, Q = 3.06},
    {name = "eq", gain = 3.5, frequency = 10906, Q = 2.27},
    {name = "eq", gain = 2.9, frequency = 3151, Q = 3.99},
    {name = "eq", gain = -3.5, frequency = 3644, Q = 3.82},
    {name = "eq", gain = 1.4, frequency = 4634, Q = 4.64},
    {name = "eq", gain = 1.9, frequency = 13743, Q = 1.61},
    {name = "eq", gain = -7.1, frequency = 19913, Q = 0.52},
}
