return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -4.0, frequency = 220, Q = 0.76},
    {name = "eq", gain = 1.9, frequency = 851, Q = 2.29},
    {name = "eq", gain = 4.4, frequency = 3342, Q = 2.01},
    {name = "eq", gain = 6.0, frequency = 16254, Q = 0.42},
    {name = "eq", gain = 3.2, frequency = 19829, Q = 1.61},
    {name = "eq", gain = 3.2, frequency = 21, Q = 0.95},
    {name = "eq", gain = 2.4, frequency = 4253, Q = 5.78},
    {name = "eq", gain = -3.4, frequency = 4886, Q = 3.76},
    {name = "eq", gain = 3.4, frequency = 5930, Q = 4.74},
    {name = "eq", gain = -1.8, frequency = 10089, Q = 5.45},
}
