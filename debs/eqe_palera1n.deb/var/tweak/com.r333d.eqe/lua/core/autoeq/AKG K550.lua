return {
    {name = "preamp", gain = -5.1},
    {name = "eq", gain = -2.3, frequency = 133, Q = 2.22},
    {name = "eq", gain = 5.7, frequency = 4075, Q = 1.91},
    {name = "eq", gain = -5.7, frequency = 5669, Q = 4.06},
    {name = "eq", gain = -2.4, frequency = 8302, Q = 4.09},
    {name = "eq", gain = -5.4, frequency = 19737, Q = 0.27},
    {name = "eq", gain = -0.8, frequency = 54, Q = 0.14},
    {name = "eq", gain = 2.3, frequency = 78, Q = 2.31},
    {name = "eq", gain = 2.5, frequency = 742, Q = 1.17},
    {name = "eq", gain = -2.4, frequency = 1201, Q = 1.24},
    {name = "eq", gain = 2.0, frequency = 1967, Q = 3.98},
}
