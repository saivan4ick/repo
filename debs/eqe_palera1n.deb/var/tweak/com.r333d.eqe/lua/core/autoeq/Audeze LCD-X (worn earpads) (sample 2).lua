return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 9.4, frequency = 34, Q = 0.57},
    {name = "eq", gain = -6.3, frequency = 87, Q = 0.45},
    {name = "eq", gain = -2.3, frequency = 770, Q = 0.57},
    {name = "eq", gain = 6.5, frequency = 4021, Q = 1.42},
    {name = "eq", gain = 5.7, frequency = 9226, Q = 2.06},
    {name = "eq", gain = -0.3, frequency = 358, Q = 3.91},
    {name = "eq", gain = 1.9, frequency = 7515, Q = 5.60},
    {name = "eq", gain = 2.8, frequency = 11275, Q = 2.95},
    {name = "eq", gain = 2.7, frequency = 13354, Q = 1.71},
    {name = "eq", gain = -14.2, frequency = 19827, Q = 0.42},
}
