return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -5.0, frequency = 201, Q = 0.45},
    {name = "eq", gain = -4.3, frequency = 1870, Q = 1.58},
    {name = "eq", gain = 3.5, frequency = 3281, Q = 1.09},
    {name = "eq", gain = 4.2, frequency = 7567, Q = 0.53},
    {name = "eq", gain = 5.6, frequency = 18449, Q = 0.29},
    {name = "eq", gain = 1.3, frequency = 20, Q = 1.46},
    {name = "eq", gain = 0.9, frequency = 988, Q = 2.83},
    {name = "eq", gain = -0.7, frequency = 1258, Q = 2.63},
    {name = "eq", gain = 0.8, frequency = 21593, Q = 1.49},
    {name = "eq", gain = -1.1, frequency = 21841, Q = 1.13},
}
