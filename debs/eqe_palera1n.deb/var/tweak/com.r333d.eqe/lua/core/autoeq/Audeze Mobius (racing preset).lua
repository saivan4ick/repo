return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -1.6, frequency = 19, Q = 1.78},
    {name = "eq", gain = -2.8, frequency = 83, Q = 0.62},
    {name = "eq", gain = -4.1, frequency = 212, Q = 1.66},
    {name = "eq", gain = 3.3, frequency = 4546, Q = 3.76},
    {name = "eq", gain = 6.4, frequency = 6780, Q = 1.93},
    {name = "eq", gain = -1.2, frequency = 282, Q = 4.16},
    {name = "eq", gain = 1.1, frequency = 493, Q = 1.44},
    {name = "eq", gain = 0.3, frequency = 2626, Q = 2.11},
    {name = "eq", gain = -3.1, frequency = 2978, Q = 4.01},
    {name = "eq", gain = 0.8, frequency = 4073, Q = 3.35},
}
