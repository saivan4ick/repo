return {
    {name = "preamp", gain = -3.3},
    {name = "eq", gain = 2.8, frequency = 27, Q = 0.83},
    {name = "eq", gain = 2.1, frequency = 61, Q = 1.57},
    {name = "eq", gain = 4.7, frequency = 1899, Q = 1.44},
    {name = "eq", gain = -7.9, frequency = 2798, Q = 2.26},
    {name = "eq", gain = -3.9, frequency = 20172, Q = 0.23},
    {name = "eq", gain = -1.8, frequency = 232, Q = 1.71},
    {name = "eq", gain = 1.3, frequency = 669, Q = 2.49},
    {name = "eq", gain = 4.3, frequency = 4231, Q = 4.82},
    {name = "eq", gain = -3.5, frequency = 5140, Q = 1.86},
    {name = "eq", gain = 1.9, frequency = 7273, Q = 4.16},
}
