return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -2.8, frequency = 703, Q = 0.22},
    {name = "eq", gain = 4.3, frequency = 2667, Q = 1.24},
    {name = "eq", gain = 4.7, frequency = 4366, Q = 2.95},
    {name = "eq", gain = 6.0, frequency = 9325, Q = 0.82},
    {name = "eq", gain = -16.8, frequency = 19561, Q = 0.33},
    {name = "eq", gain = 2.3, frequency = 16, Q = 0.89},
    {name = "eq", gain = 0.8, frequency = 43, Q = 0.82},
    {name = "eq", gain = -1.1, frequency = 182, Q = 1.84},
    {name = "eq", gain = -2.8, frequency = 5738, Q = 6.26},
    {name = "eq", gain = 1.5, frequency = 6091, Q = 2.61},
}
