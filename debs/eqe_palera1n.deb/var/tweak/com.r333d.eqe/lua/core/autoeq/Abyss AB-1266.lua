return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -5.8, frequency = 228, Q = 0.25},
    {name = "eq", gain = 5.2, frequency = 350, Q = 0.08},
    {name = "eq", gain = -7.8, frequency = 1015, Q = 1.51},
    {name = "eq", gain = 7.1, frequency = 4632, Q = 2.13},
    {name = "eq", gain = -13.9, frequency = 19844, Q = 0.14},
    {name = "eq", gain = -2.7, frequency = 452, Q = 3.04},
    {name = "eq", gain = 3.5, frequency = 521, Q = 4.37},
    {name = "eq", gain = 3.6, frequency = 5611, Q = 7.17},
    {name = "eq", gain = -5.4, frequency = 6497, Q = 4.20},
    {name = "eq", gain = 2.1, frequency = 7290, Q = 2.03},
}
