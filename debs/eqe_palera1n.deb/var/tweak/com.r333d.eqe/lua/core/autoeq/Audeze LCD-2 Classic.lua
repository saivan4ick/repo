return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 3.8, frequency = 15, Q = 0.30},
    {name = "eq", gain = -2.6, frequency = 239, Q = 0.89},
    {name = "eq", gain = -3.9, frequency = 927, Q = 1.24},
    {name = "eq", gain = -2.9, frequency = 2761, Q = 4.10},
    {name = "eq", gain = 7.0, frequency = 3708, Q = 1.65},
    {name = "eq", gain = 1.6, frequency = 4689, Q = 4.23},
    {name = "eq", gain = 0.3, frequency = 5500, Q = 2.61},
    {name = "eq", gain = -4.4, frequency = 6128, Q = 3.24},
    {name = "eq", gain = 2.8, frequency = 7031, Q = 3.97},
    {name = "eq", gain = 1.5, frequency = 10752, Q = 2.86},
}
