return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 4.3, frequency = 20, Q = 0.51},
    {name = "eq", gain = -3.8, frequency = 230, Q = 0.71},
    {name = "eq", gain = -4.6, frequency = 2457, Q = 4.30},
    {name = "eq", gain = 6.8, frequency = 3845, Q = 2.68},
    {name = "eq", gain = 5.9, frequency = 9790, Q = 2.22},
    {name = "eq", gain = 1.4, frequency = 930, Q = 3.09},
    {name = "eq", gain = 3.3, frequency = 5290, Q = 5.50},
    {name = "eq", gain = -5.5, frequency = 5833, Q = 4.91},
    {name = "eq", gain = 0.6, frequency = 6323, Q = 3.45},
    {name = "eq", gain = 1.4, frequency = 8180, Q = 5.91},
}
