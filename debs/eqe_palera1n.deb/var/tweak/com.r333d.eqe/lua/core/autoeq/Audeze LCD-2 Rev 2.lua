return {
    {name = "preamp", gain = -5.6},
    {name = "eq", gain = -2.7, frequency = 223, Q = 1.24},
    {name = "eq", gain = -2.7, frequency = 706, Q = 1.98},
    {name = "eq", gain = 7.8, frequency = 4326, Q = 1.72},
    {name = "eq", gain = -7.2, frequency = 5444, Q = 2.77},
    {name = "eq", gain = 4.7, frequency = 9715, Q = 2.44},
    {name = "eq", gain = 2.5, frequency = 31, Q = 0.83},
    {name = "eq", gain = -1.1, frequency = 867, Q = 4.55},
    {name = "eq", gain = -3.8, frequency = 4573, Q = 0.55},
    {name = "eq", gain = 4.1, frequency = 7054, Q = 0.22},
    {name = "eq", gain = -14.4, frequency = 19504, Q = 0.50},
}
