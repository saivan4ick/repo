return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.5, frequency = 35, Q = 0.41},
    {name = "eq", gain = 0.8, frequency = 735, Q = 2.48},
    {name = "eq", gain = -0.6, frequency = 1371, Q = 1.97},
    {name = "eq", gain = -9.6, frequency = 3731, Q = 2.31},
    {name = "eq", gain = 6.9, frequency = 8234, Q = 1.84},
    {name = "eq", gain = -1.3, frequency = 257, Q = 2.41},
    {name = "eq", gain = 0.8, frequency = 2845, Q = 2.91},
    {name = "eq", gain = -0.6, frequency = 3151, Q = 2.88},
    {name = "eq", gain = 2.9, frequency = 11866, Q = 1.46},
    {name = "eq", gain = -10.5, frequency = 19686, Q = 0.46},
}
