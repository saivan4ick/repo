return {
    {name = "preamp", gain = -4.0},
    {name = "eq", gain = -3.4, frequency = 14, Q = 0.41},
    {name = "eq", gain = -4.6, frequency = 113, Q = 0.38},
    {name = "eq", gain = 3.9, frequency = 816, Q = 0.87},
    {name = "eq", gain = 2.9, frequency = 2086, Q = 1.28},
    {name = "eq", gain = -5.9, frequency = 5672, Q = 5.39},
    {name = "eq", gain = -1.2, frequency = 3073, Q = 4.71},
    {name = "eq", gain = 1.7, frequency = 4070, Q = 4.36},
    {name = "eq", gain = -1.8, frequency = 8263, Q = 2.73},
    {name = "eq", gain = 2.1, frequency = 10840, Q = 1.24},
    {name = "eq", gain = -5.0, frequency = 19728, Q = 0.52},
}
