return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.5, frequency = 26, Q = 0.94},
    {name = "eq", gain = 3.6, frequency = 2209, Q = 5.73},
    {name = "eq", gain = 1.3, frequency = 2759, Q = 6.27},
    {name = "eq", gain = 4.0, frequency = 7411, Q = 4.33},
    {name = "eq", gain = -10.2, frequency = 19047, Q = 0.54},
    {name = "eq", gain = -2.2, frequency = 181, Q = 1.28},
    {name = "eq", gain = 2.5, frequency = 3091, Q = 4.27},
    {name = "eq", gain = -5.6, frequency = 3558, Q = 4.70},
    {name = "eq", gain = 1.4, frequency = 9776, Q = 3.40},
    {name = "eq", gain = -0.8, frequency = 14742, Q = 2.42},
}
