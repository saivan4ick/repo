return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = 6.9, frequency = 32, Q = 0.73},
    {name = "eq", gain = -2.8, frequency = 1679, Q = 2.24},
    {name = "eq", gain = -3.7, frequency = 3394, Q = 1.77},
    {name = "eq", gain = 4.5, frequency = 4457, Q = 4.99},
    {name = "eq", gain = 7.1, frequency = 8671, Q = 1.93},
    {name = "eq", gain = 2.2, frequency = 58, Q = 3.26},
    {name = "eq", gain = -2.7, frequency = 198, Q = 1.05},
    {name = "eq", gain = 1.6, frequency = 7323, Q = 6.53},
    {name = "eq", gain = 3.8, frequency = 12048, Q = 1.67},
    {name = "eq", gain = -13.0, frequency = 19864, Q = 0.43},
}
