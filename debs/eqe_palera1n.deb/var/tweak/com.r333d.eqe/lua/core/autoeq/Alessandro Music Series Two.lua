return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.3, frequency = 30, Q = 0.43},
    {name = "eq", gain = 2.2, frequency = 395, Q = 0.70},
    {name = "eq", gain = -11.5, frequency = 2380, Q = 1.34},
    {name = "eq", gain = 5.0, frequency = 2868, Q = 0.29},
    {name = "eq", gain = -8.3, frequency = 9609, Q = 0.76},
    {name = "eq", gain = 0.7, frequency = 153, Q = 4.30},
    {name = "eq", gain = -2.0, frequency = 3534, Q = 5.44},
    {name = "eq", gain = 2.8, frequency = 4290, Q = 5.98},
    {name = "eq", gain = -0.9, frequency = 10080, Q = 1.01},
    {name = "eq", gain = 1.4, frequency = 10235, Q = 2.72},
}
