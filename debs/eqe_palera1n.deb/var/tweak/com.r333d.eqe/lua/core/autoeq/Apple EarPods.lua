return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.2, frequency = 33, Q = 0.32},
    {name = "eq", gain = 3.5, frequency = 571, Q = 0.33},
    {name = "eq", gain = -7.6, frequency = 2068, Q = 1.09},
    {name = "eq", gain = -5.8, frequency = 5843, Q = 3.03},
    {name = "eq", gain = -1.1, frequency = 22050, Q = 2.25},
    {name = "eq", gain = 0.7, frequency = 71, Q = 5.10},
    {name = "eq", gain = -1.4, frequency = 3024, Q = 3.89},
    {name = "eq", gain = 1.1, frequency = 3806, Q = 1.91},
    {name = "eq", gain = -2.1, frequency = 8953, Q = 2.71},
    {name = "eq", gain = 3.1, frequency = 19531, Q = 0.40},
}
