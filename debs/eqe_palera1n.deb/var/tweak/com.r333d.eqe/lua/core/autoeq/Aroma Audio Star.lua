return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -2.6, frequency = 109, Q = 0.83},
    {name = "eq", gain = -3.8, frequency = 262, Q = 0.86},
    {name = "eq", gain = 2.9, frequency = 2130, Q = 1.29},
    {name = "eq", gain = 5.5, frequency = 4247, Q = 2.90},
    {name = "eq", gain = 6.8, frequency = 16853, Q = 0.35},
    {name = "eq", gain = 1.2, frequency = 916, Q = 4.00},
    {name = "eq", gain = 3.4, frequency = 5268, Q = 4.66},
    {name = "eq", gain = -4.7, frequency = 6387, Q = 2.92},
    {name = "eq", gain = 2.3, frequency = 10450, Q = 2.13},
    {name = "eq", gain = -1.0, frequency = 16524, Q = 1.89},
}
