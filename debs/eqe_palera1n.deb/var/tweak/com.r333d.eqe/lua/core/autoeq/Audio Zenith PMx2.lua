return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 4.9, frequency = 23, Q = 0.39},
    {name = "eq", gain = -2.8, frequency = 323, Q = 0.15},
    {name = "eq", gain = 4.3, frequency = 2151, Q = 1.48},
    {name = "eq", gain = 4.4, frequency = 4305, Q = 1.45},
    {name = "eq", gain = 6.7, frequency = 18364, Q = 0.52},
    {name = "eq", gain = 0.9, frequency = 54, Q = 3.43},
    {name = "eq", gain = -2.0, frequency = 341, Q = 0.73},
    {name = "eq", gain = 3.8, frequency = 402, Q = 1.80},
    {name = "eq", gain = 1.3, frequency = 6646, Q = 6.13},
    {name = "eq", gain = -1.6, frequency = 8771, Q = 3.87},
}
