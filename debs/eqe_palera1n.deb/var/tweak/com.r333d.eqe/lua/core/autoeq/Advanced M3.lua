return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -5.3, frequency = 13, Q = 0.36},
    {name = "eq", gain = -7.9, frequency = 142, Q = 0.28},
    {name = "eq", gain = 4.8, frequency = 895, Q = 0.56},
    {name = "eq", gain = 4.1, frequency = 7062, Q = 0.46},
    {name = "eq", gain = 3.0, frequency = 12318, Q = 0.86},
    {name = "eq", gain = 1.5, frequency = 3623, Q = 4.69},
    {name = "eq", gain = -3.4, frequency = 4685, Q = 3.30},
    {name = "eq", gain = 2.0, frequency = 5396, Q = 4.30},
    {name = "eq", gain = 1.6, frequency = 6773, Q = 1.74},
    {name = "eq", gain = -2.6, frequency = 7653, Q = 4.71},
}
