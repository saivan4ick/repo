return {
    {name = "preamp", gain = -5.2},
    {name = "eq", gain = 5.2, frequency = 21, Q = 1.11},
    {name = "eq", gain = -2.9, frequency = 96, Q = 0.66},
    {name = "eq", gain = -4.4, frequency = 1610, Q = 2.18},
    {name = "eq", gain = 5.1, frequency = 3902, Q = 3.17},
    {name = "eq", gain = 4.6, frequency = 9063, Q = 3.21},
    {name = "eq", gain = -2.0, frequency = 206, Q = 2.47},
    {name = "eq", gain = 2.9, frequency = 463, Q = 1.43},
    {name = "eq", gain = 1.2, frequency = 2921, Q = 6.80},
    {name = "eq", gain = 6.6, frequency = 11594, Q = 1.01},
    {name = "eq", gain = -19.3, frequency = 19695, Q = 0.32},
}
