return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -6.6, frequency = 236, Q = 0.51},
    {name = "eq", gain = -10.4, frequency = 1280, Q = 1.36},
    {name = "eq", gain = 3.3, frequency = 2565, Q = 3.34},
    {name = "eq", gain = 9.2, frequency = 3983, Q = 0.08},
    {name = "eq", gain = -10.6, frequency = 4488, Q = 0.77},
    {name = "eq", gain = 1.7, frequency = 698, Q = 6.50},
    {name = "eq", gain = 4.4, frequency = 4875, Q = 5.17},
    {name = "eq", gain = -6.5, frequency = 6067, Q = 3.39},
    {name = "eq", gain = 5.4, frequency = 7326, Q = 2.23},
    {name = "eq", gain = -1.1, frequency = 8020, Q = 0.47},
}
