return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -5.2, frequency = 16, Q = 0.36},
    {name = "eq", gain = -5.1, frequency = 123, Q = 0.35},
    {name = "eq", gain = 2.0, frequency = 773, Q = 1.68},
    {name = "eq", gain = 4.8, frequency = 6047, Q = 0.82},
    {name = "eq", gain = 1.5, frequency = 11696, Q = 0.30},
    {name = "eq", gain = -0.4, frequency = 2174, Q = 2.28},
    {name = "eq", gain = -1.7, frequency = 2505, Q = 2.52},
    {name = "eq", gain = 3.5, frequency = 3478, Q = 3.18},
    {name = "eq", gain = -3.4, frequency = 4644, Q = 4.08},
    {name = "eq", gain = 1.6, frequency = 5247, Q = 3.99},
}
