return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -4.5, frequency = 53, Q = 0.32},
    {name = "eq", gain = -5.4, frequency = 254, Q = 0.51},
    {name = "eq", gain = 4.4, frequency = 1494, Q = 0.42},
    {name = "eq", gain = 3.4, frequency = 9065, Q = 1.30},
    {name = "eq", gain = 6.2, frequency = 18053, Q = 0.29},
    {name = "eq", gain = 1.3, frequency = 945, Q = 3.36},
    {name = "eq", gain = -2.0, frequency = 1461, Q = 1.50},
    {name = "eq", gain = 1.5, frequency = 2083, Q = 1.13},
    {name = "eq", gain = -5.0, frequency = 5419, Q = 5.36},
    {name = "eq", gain = 2.9, frequency = 6391, Q = 4.16},
}
