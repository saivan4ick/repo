return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -7.4, frequency = 13, Q = 0.26},
    {name = "eq", gain = -4.9, frequency = 71, Q = 0.66},
    {name = "eq", gain = 22.1, frequency = 4871, Q = 0.65},
    {name = "eq", gain = -26.0, frequency = 6135, Q = 0.89},
    {name = "eq", gain = 7.3, frequency = 17908, Q = 0.53},
    {name = "eq", gain = -2.9, frequency = 548, Q = 1.95},
    {name = "eq", gain = 2.8, frequency = 879, Q = 1.56},
    {name = "eq", gain = -1.4, frequency = 1193, Q = 3.45},
    {name = "eq", gain = -1.3, frequency = 10232, Q = 3.57},
    {name = "eq", gain = 1.2, frequency = 15163, Q = 3.48},
}
