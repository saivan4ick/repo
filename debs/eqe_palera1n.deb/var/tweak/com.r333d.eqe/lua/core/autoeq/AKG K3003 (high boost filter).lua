return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 6.2, frequency = 23, Q = 0.63},
    {name = "eq", gain = -3.5, frequency = 204, Q = 0.69},
    {name = "eq", gain = 3.3, frequency = 1630, Q = 0.79},
    {name = "eq", gain = 4.3, frequency = 3757, Q = 6.35},
    {name = "eq", gain = -5.9, frequency = 20008, Q = 0.24},
    {name = "eq", gain = 1.6, frequency = 896, Q = 1.95},
    {name = "eq", gain = -1.6, frequency = 1337, Q = 1.30},
    {name = "eq", gain = 1.7, frequency = 2139, Q = 2.61},
    {name = "eq", gain = -3.9, frequency = 5625, Q = 4.42},
    {name = "eq", gain = 0.9, frequency = 11873, Q = 1.86},
}
