return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -4.8, frequency = 75, Q = 0.58},
    {name = "eq", gain = -4.4, frequency = 167, Q = 1.06},
    {name = "eq", gain = 5.4, frequency = 4212, Q = 0.66},
    {name = "eq", gain = -10.4, frequency = 6087, Q = 3.62},
    {name = "eq", gain = 5.7, frequency = 12168, Q = 0.92},
    {name = "eq", gain = 1.4, frequency = 633, Q = 1.42},
    {name = "eq", gain = -2.8, frequency = 1570, Q = 1.40},
    {name = "eq", gain = 3.5, frequency = 2011, Q = 2.44},
    {name = "eq", gain = -2.7, frequency = 3436, Q = 5.48},
    {name = "eq", gain = 2.0, frequency = 4109, Q = 4.90},
}
