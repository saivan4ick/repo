return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 1.7, frequency = 32, Q = 3.66},
    {name = "eq", gain = -4.7, frequency = 182, Q = 1.08},
    {name = "eq", gain = 3.1, frequency = 4364, Q = 4.62},
    {name = "eq", gain = 6.3, frequency = 6701, Q = 1.64},
    {name = "eq", gain = -7.8, frequency = 19346, Q = 0.47},
    {name = "eq", gain = -1.5, frequency = 263, Q = 2.89},
    {name = "eq", gain = 2.0, frequency = 592, Q = 0.75},
    {name = "eq", gain = -1.9, frequency = 1069, Q = 1.07},
    {name = "eq", gain = 1.2, frequency = 2863, Q = 1.30},
    {name = "eq", gain = -3.5, frequency = 2938, Q = 4.20},
}
