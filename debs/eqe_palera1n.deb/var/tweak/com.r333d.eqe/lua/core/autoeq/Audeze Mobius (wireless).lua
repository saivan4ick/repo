return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = -5.9, frequency = 27, Q = 0.32},
    {name = "eq", gain = -3.1, frequency = 126, Q = 2.23},
    {name = "eq", gain = -3.9, frequency = 221, Q = 2.55},
    {name = "eq", gain = 7.2, frequency = 6662, Q = 1.59},
    {name = "eq", gain = 1.7, frequency = 1487, Q = 1.78},
    {name = "eq", gain = -4.2, frequency = 3350, Q = 2.45},
    {name = "eq", gain = 3.9, frequency = 4807, Q = 4.56},
    {name = "eq", gain = 3.0, frequency = 10078, Q = 1.70},
    {name = "eq", gain = -10.5, frequency = 19547, Q = 0.38},
}
