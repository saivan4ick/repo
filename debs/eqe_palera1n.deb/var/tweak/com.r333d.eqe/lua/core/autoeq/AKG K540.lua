return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 6.4, frequency = 27, Q = 0.82},
    {name = "eq", gain = 6.9, frequency = 814, Q = 2.77},
    {name = "eq", gain = -5.5, frequency = 2914, Q = 1.68},
    {name = "eq", gain = -4.2, frequency = 5753, Q = 4.84},
    {name = "eq", gain = 4.1, frequency = 8077, Q = 2.36},
    {name = "eq", gain = -2.8, frequency = 215, Q = 1.50},
    {name = "eq", gain = 1.1, frequency = 584, Q = 2.92},
    {name = "eq", gain = 1.7, frequency = 966, Q = 6.27},
    {name = "eq", gain = -1.8, frequency = 1457, Q = 1.47},
    {name = "eq", gain = 1.5, frequency = 1944, Q = 2.44},
}
