return {
    {name = "preamp", gain = -2.6},
    {name = "eq", gain = -2.7, frequency = 27, Q = 0.35},
    {name = "eq", gain = 1.5, frequency = 3736, Q = 4.49},
    {name = "eq", gain = -3.7, frequency = 4832, Q = 5.85},
    {name = "eq", gain = 2.9, frequency = 9568, Q = 0.62},
    {name = "eq", gain = -10.0, frequency = 19630, Q = 0.38},
    {name = "eq", gain = -0.8, frequency = 326, Q = 1.89},
    {name = "eq", gain = 1.6, frequency = 945, Q = 2.86},
    {name = "eq", gain = -1.0, frequency = 2413, Q = 4.26},
    {name = "eq", gain = 1.8, frequency = 6430, Q = 3.69},
    {name = "eq", gain = -2.3, frequency = 7269, Q = 4.94},
}
