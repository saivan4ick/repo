return {
    {name = "preamp", gain = -4.2},
    {name = "eq", gain = 2.3, frequency = 21, Q = 0.82},
    {name = "eq", gain = -6.0, frequency = 290, Q = 0.54},
    {name = "eq", gain = 6.7, frequency = 558, Q = 0.95},
    {name = "eq", gain = 2.6, frequency = 3982, Q = 4.78},
    {name = "eq", gain = 3.9, frequency = 14334, Q = 0.54},
    {name = "eq", gain = -1.6, frequency = 843, Q = 3.20},
    {name = "eq", gain = 1.2, frequency = 1042, Q = 1.66},
    {name = "eq", gain = -0.5, frequency = 2524, Q = 3.03},
    {name = "eq", gain = -1.7, frequency = 6673, Q = 3.76},
    {name = "eq", gain = 1.0, frequency = 9539, Q = 2.10},
}
