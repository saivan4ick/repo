return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -3.9, frequency = 102, Q = 0.35},
    {name = "eq", gain = 3.5, frequency = 778, Q = 1.17},
    {name = "eq", gain = -4.7, frequency = 4746, Q = 4.41},
    {name = "eq", gain = 4.3, frequency = 10838, Q = 0.69},
    {name = "eq", gain = 5.7, frequency = 19400, Q = 0.30},
    {name = "eq", gain = -2.6, frequency = 2524, Q = 3.30},
    {name = "eq", gain = 1.9, frequency = 3396, Q = 4.42},
    {name = "eq", gain = -1.9, frequency = 5358, Q = 4.12},
    {name = "eq", gain = 3.6, frequency = 6477, Q = 2.96},
    {name = "eq", gain = -3.5, frequency = 7591, Q = 4.97},
}
