return {
    {name = "preamp", gain = -4.4},
    {name = "eq", gain = 4.2, frequency = 61, Q = 0.82},
    {name = "eq", gain = 3.3, frequency = 385, Q = 1.07},
    {name = "eq", gain = -10.8, frequency = 1117, Q = 1.32},
    {name = "eq", gain = 4.5, frequency = 2905, Q = 0.38},
    {name = "eq", gain = -5.5, frequency = 4816, Q = 1.65},
    {name = "eq", gain = -1.8, frequency = 18, Q = 2.34},
    {name = "eq", gain = 1.0, frequency = 674, Q = 7.94},
    {name = "eq", gain = 2.4, frequency = 6265, Q = 5.92},
    {name = "eq", gain = -2.0, frequency = 7105, Q = 1.66},
    {name = "eq", gain = 0.8, frequency = 11016, Q = 0.51},
}
