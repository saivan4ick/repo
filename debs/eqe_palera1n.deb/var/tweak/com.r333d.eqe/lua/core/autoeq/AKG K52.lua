return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -7.9, frequency = 29, Q = 0.72},
    {name = "eq", gain = -12.0, frequency = 146, Q = 1.40},
    {name = "eq", gain = 10.9, frequency = 2688, Q = 0.68},
    {name = "eq", gain = -9.2, frequency = 5431, Q = 0.60},
    {name = "eq", gain = 6.9, frequency = 10284, Q = 1.05},
    {name = "eq", gain = 3.9, frequency = 76, Q = 6.93},
    {name = "eq", gain = 4.7, frequency = 383, Q = 5.18},
    {name = "eq", gain = -5.7, frequency = 4226, Q = 5.63},
    {name = "eq", gain = 3.4, frequency = 5045, Q = 1.55},
    {name = "eq", gain = -4.1, frequency = 6427, Q = 5.01},
}
