return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.2, frequency = 25, Q = 0.84},
    {name = "eq", gain = 6.2, frequency = 2502, Q = 3.02},
    {name = "eq", gain = -6.6, frequency = 3926, Q = 3.44},
    {name = "eq", gain = 4.7, frequency = 4986, Q = 2.35},
    {name = "eq", gain = 3.2, frequency = 10920, Q = 0.77},
    {name = "eq", gain = 2.0, frequency = 66, Q = 1.96},
    {name = "eq", gain = -3.1, frequency = 229, Q = 0.61},
    {name = "eq", gain = -1.7, frequency = 1105, Q = 1.03},
    {name = "eq", gain = 0.6, frequency = 1969, Q = 2.57},
    {name = "eq", gain = 0.8, frequency = 1969, Q = 2.59},
}
