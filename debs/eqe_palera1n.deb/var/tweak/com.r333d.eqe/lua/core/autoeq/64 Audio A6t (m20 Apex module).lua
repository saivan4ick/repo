return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -1.2, frequency = 31, Q = 0.50},
    {name = "eq", gain = -4.8, frequency = 117, Q = 0.26},
    {name = "eq", gain = 5.1, frequency = 3541, Q = 1.12},
    {name = "eq", gain = 4.2, frequency = 6268, Q = 2.41},
    {name = "eq", gain = 3.7, frequency = 9234, Q = 2.94},
    {name = "eq", gain = -0.7, frequency = 560, Q = 1.67},
    {name = "eq", gain = 1.2, frequency = 976, Q = 1.94},
    {name = "eq", gain = 3.2, frequency = 11534, Q = 1.15},
    {name = "eq", gain = -12.3, frequency = 19681, Q = 0.37},
}
