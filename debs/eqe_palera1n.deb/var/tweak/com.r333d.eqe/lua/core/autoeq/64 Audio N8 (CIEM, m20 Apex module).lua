return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -3.5, frequency = 21, Q = 0.82},
    {name = "eq", gain = -1.9, frequency = 62, Q = 0.63},
    {name = "eq", gain = -3.6, frequency = 254, Q = 0.52},
    {name = "eq", gain = 4.3, frequency = 3451, Q = 1.92},
    {name = "eq", gain = 6.6, frequency = 7649, Q = 1.29},
    {name = "eq", gain = 1.1, frequency = 916, Q = 2.46},
    {name = "eq", gain = -2.1, frequency = 1500, Q = 2.72},
    {name = "eq", gain = 1.2, frequency = 10257, Q = 2.92},
    {name = "eq", gain = 2.2, frequency = 12101, Q = 1.17},
    {name = "eq", gain = -11.0, frequency = 19805, Q = 0.41},
}
