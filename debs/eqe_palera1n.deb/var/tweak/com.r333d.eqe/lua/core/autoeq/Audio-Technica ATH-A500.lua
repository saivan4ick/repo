return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = 6.8, frequency = 22, Q = 1.23},
    {name = "eq", gain = -3.8, frequency = 70, Q = 0.72},
    {name = "eq", gain = -3.3, frequency = 1025, Q = 0.59},
    {name = "eq", gain = 3.3, frequency = 1723, Q = 2.07},
    {name = "eq", gain = 4.4, frequency = 3571, Q = 1.02},
    {name = "eq", gain = 2.3, frequency = 314, Q = 3.01},
    {name = "eq", gain = -1.7, frequency = 465, Q = 2.95},
    {name = "eq", gain = 5.6, frequency = 6082, Q = 4.51},
    {name = "eq", gain = 2.7, frequency = 8277, Q = 2.34},
    {name = "eq", gain = -7.4, frequency = 19697, Q = 0.13},
}
