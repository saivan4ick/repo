return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 6.9, frequency = 37, Q = 0.64},
    {name = "eq", gain = 4.4, frequency = 936, Q = 0.58},
    {name = "eq", gain = 3.4, frequency = 3962, Q = 1.79},
    {name = "eq", gain = 4.5, frequency = 4346, Q = 1.90},
    {name = "eq", gain = -3.7, frequency = 11664, Q = 0.05},
    {name = "eq", gain = -4.0, frequency = 232, Q = 0.82},
    {name = "eq", gain = 3.2, frequency = 1312, Q = 8.95},
    {name = "eq", gain = 2.5, frequency = 1950, Q = 5.46},
    {name = "eq", gain = -3.8, frequency = 2470, Q = 5.02},
    {name = "eq", gain = 1.7, frequency = 10286, Q = 3.02},
}
