return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -6.7, frequency = 145, Q = 0.70},
    {name = "eq", gain = 11.3, frequency = 335, Q = 0.81},
    {name = "eq", gain = -9.1, frequency = 1151, Q = 0.66},
    {name = "eq", gain = 5.9, frequency = 3738, Q = 2.45},
    {name = "eq", gain = 3.2, frequency = 10568, Q = 2.38},
    {name = "eq", gain = -1.0, frequency = 18, Q = 1.48},
    {name = "eq", gain = 1.7, frequency = 461, Q = 6.01},
    {name = "eq", gain = -1.6, frequency = 623, Q = 5.03},
    {name = "eq", gain = 1.8, frequency = 2567, Q = 5.88},
    {name = "eq", gain = -1.9, frequency = 6468, Q = 5.18},
}
