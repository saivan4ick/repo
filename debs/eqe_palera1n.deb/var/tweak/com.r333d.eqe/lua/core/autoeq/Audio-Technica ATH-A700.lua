return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 6.7, frequency = 29, Q = 0.83},
    {name = "eq", gain = -2.5, frequency = 505, Q = 3.85},
    {name = "eq", gain = 9.0, frequency = 3171, Q = 2.18},
    {name = "eq", gain = 5.6, frequency = 5697, Q = 1.74},
    {name = "eq", gain = -4.6, frequency = 12233, Q = 0.08},
    {name = "eq", gain = 4.3, frequency = 304, Q = 2.63},
    {name = "eq", gain = -0.9, frequency = 377, Q = 0.20},
    {name = "eq", gain = 1.9, frequency = 1659, Q = 5.53},
    {name = "eq", gain = -3.2, frequency = 4379, Q = 6.60},
    {name = "eq", gain = 1.7, frequency = 4384, Q = 2.39},
}
