return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.3, frequency = 27, Q = 0.63},
    {name = "eq", gain = 2.1, frequency = 758, Q = 1.90},
    {name = "eq", gain = -6.1, frequency = 2464, Q = 1.87},
    {name = "eq", gain = 4.6, frequency = 3827, Q = 0.45},
    {name = "eq", gain = -8.7, frequency = 6162, Q = 2.03},
    {name = "eq", gain = -1.8, frequency = 213, Q = 1.57},
    {name = "eq", gain = -0.8, frequency = 1870, Q = 6.27},
    {name = "eq", gain = 1.7, frequency = 11680, Q = 1.97},
    {name = "eq", gain = -1.0, frequency = 19150, Q = 0.81},
    {name = "eq", gain = -5.0, frequency = 20256, Q = 0.43},
}
