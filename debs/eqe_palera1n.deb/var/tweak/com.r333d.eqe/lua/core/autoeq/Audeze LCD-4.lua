return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 3.0, frequency = 13, Q = 0.23},
    {name = "eq", gain = -3.0, frequency = 254, Q = 0.45},
    {name = "eq", gain = -4.0, frequency = 963, Q = 2.06},
    {name = "eq", gain = 5.8, frequency = 4271, Q = 1.50},
    {name = "eq", gain = 5.3, frequency = 8533, Q = 2.56},
    {name = "eq", gain = 2.2, frequency = 2050, Q = 4.34},
    {name = "eq", gain = 2.8, frequency = 11174, Q = 1.57},
    {name = "eq", gain = 2.4, frequency = 11589, Q = 0.90},
    {name = "eq", gain = -9.5, frequency = 19530, Q = 0.27},
    {name = "eq", gain = -8.9, frequency = 19767, Q = 0.60},
}
