return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -3.7, frequency = 87, Q = 0.54},
    {name = "eq", gain = -2.4, frequency = 211, Q = 1.31},
    {name = "eq", gain = 6.8, frequency = 3500, Q = 2.51},
    {name = "eq", gain = -5.3, frequency = 5563, Q = 6.45},
    {name = "eq", gain = 4.6, frequency = 10145, Q = 1.22},
    {name = "eq", gain = 2.1, frequency = 847, Q = 1.60},
    {name = "eq", gain = -3.0, frequency = 1871, Q = 1.39},
    {name = "eq", gain = 1.2, frequency = 2765, Q = 3.20},
    {name = "eq", gain = 1.5, frequency = 2883, Q = 4.49},
    {name = "eq", gain = -5.7, frequency = 19505, Q = 1.04},
}
