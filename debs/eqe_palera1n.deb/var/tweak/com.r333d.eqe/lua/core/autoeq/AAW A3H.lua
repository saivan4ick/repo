return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 3.5, frequency = 17, Q = 0.76},
    {name = "eq", gain = -1.5, frequency = 83, Q = 0.80},
    {name = "eq", gain = -4.7, frequency = 237, Q = 0.53},
    {name = "eq", gain = 4.4, frequency = 3388, Q = 2.84},
    {name = "eq", gain = 6.4, frequency = 15868, Q = 0.17},
    {name = "eq", gain = 1.2, frequency = 1038, Q = 2.09},
    {name = "eq", gain = -1.7, frequency = 1454, Q = 1.74},
    {name = "eq", gain = 0.9, frequency = 2209, Q = 2.66},
    {name = "eq", gain = -1.3, frequency = 5024, Q = 4.55},
    {name = "eq", gain = 1.1, frequency = 7593, Q = 2.87},
}
