return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -4.7, frequency = 20, Q = 0.31},
    {name = "eq", gain = -5.6, frequency = 142, Q = 0.29},
    {name = "eq", gain = 3.4, frequency = 825, Q = 0.86},
    {name = "eq", gain = 6.2, frequency = 4216, Q = 1.47},
    {name = "eq", gain = 3.5, frequency = 20025, Q = 0.11},
    {name = "eq", gain = -2.5, frequency = 2645, Q = 4.18},
    {name = "eq", gain = 1.3, frequency = 2728, Q = 1.88},
    {name = "eq", gain = -1.7, frequency = 6533, Q = 5.20},
    {name = "eq", gain = 1.3, frequency = 8777, Q = 2.17},
    {name = "eq", gain = -1.0, frequency = 11299, Q = 1.08},
}
