return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = 6.4, frequency = 22, Q = 1.23},
    {name = "eq", gain = -8.2, frequency = 173, Q = 0.62},
    {name = "eq", gain = 6.0, frequency = 2145, Q = 2.42},
    {name = "eq", gain = 5.6, frequency = 3924, Q = 1.78},
    {name = "eq", gain = 6.2, frequency = 11454, Q = 0.98},
    {name = "eq", gain = -2.1, frequency = 300, Q = 1.85},
    {name = "eq", gain = 3.7, frequency = 569, Q = 2.44},
    {name = "eq", gain = -4.2, frequency = 1033, Q = 2.17},
    {name = "eq", gain = 0.6, frequency = 1288, Q = 0.11},
    {name = "eq", gain = -3.0, frequency = 6121, Q = 5.96},
}
