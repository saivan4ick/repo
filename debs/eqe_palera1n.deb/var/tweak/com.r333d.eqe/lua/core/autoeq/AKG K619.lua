return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -9.5, frequency = 34, Q = 0.44},
    {name = "eq", gain = -5.1, frequency = 985, Q = 0.84},
    {name = "eq", gain = 6.6, frequency = 3469, Q = 1.48},
    {name = "eq", gain = 6.7, frequency = 9823, Q = 1.15},
    {name = "eq", gain = -10.9, frequency = 19694, Q = 0.59},
    {name = "eq", gain = 1.4, frequency = 187, Q = 2.34},
    {name = "eq", gain = 4.1, frequency = 4877, Q = 4.64},
    {name = "eq", gain = -6.8, frequency = 5540, Q = 4.69},
    {name = "eq", gain = 1.3, frequency = 6413, Q = 4.42},
    {name = "eq", gain = 1.2, frequency = 7418, Q = 3.71},
}
