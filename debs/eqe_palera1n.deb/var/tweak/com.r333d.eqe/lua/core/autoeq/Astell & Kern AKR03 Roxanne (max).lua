return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -4.4, frequency = 19, Q = 0.64},
    {name = "eq", gain = -6.0, frequency = 116, Q = 0.36},
    {name = "eq", gain = -5.2, frequency = 382, Q = 0.22},
    {name = "eq", gain = 7.6, frequency = 2960, Q = 0.35},
    {name = "eq", gain = 4.8, frequency = 11680, Q = 1.32},
    {name = "eq", gain = -1.8, frequency = 1395, Q = 3.72},
    {name = "eq", gain = 1.9, frequency = 1937, Q = 3.19},
    {name = "eq", gain = -0.7, frequency = 3553, Q = 2.76},
    {name = "eq", gain = 3.6, frequency = 14293, Q = 2.04},
    {name = "eq", gain = -11.0, frequency = 19611, Q = 0.70},
}
