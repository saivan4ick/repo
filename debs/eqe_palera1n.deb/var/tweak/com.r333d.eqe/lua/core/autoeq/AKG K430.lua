return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.1, frequency = 29, Q = 0.12},
    {name = "eq", gain = -7.6, frequency = 1080, Q = 2.04},
    {name = "eq", gain = -4.4, frequency = 3810, Q = 4.29},
    {name = "eq", gain = -10.4, frequency = 5927, Q = 3.41},
    {name = "eq", gain = 4.1, frequency = 8190, Q = 0.97},
    {name = "eq", gain = -4.7, frequency = 234, Q = 0.79},
    {name = "eq", gain = 4.2, frequency = 447, Q = 0.29},
    {name = "eq", gain = -3.3, frequency = 813, Q = 3.13},
    {name = "eq", gain = -3.6, frequency = 1832, Q = 0.77},
    {name = "eq", gain = 4.3, frequency = 2373, Q = 2.47},
}
