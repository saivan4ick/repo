return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -5.4, frequency = 24, Q = 1.71},
    {name = "eq", gain = -10.7, frequency = 156, Q = 1.07},
    {name = "eq", gain = 7.0, frequency = 2122, Q = 0.89},
    {name = "eq", gain = -7.2, frequency = 6452, Q = 3.19},
    {name = "eq", gain = 4.8, frequency = 10883, Q = 1.23},
    {name = "eq", gain = -2.9, frequency = 60, Q = 0.82},
    {name = "eq", gain = 8.1, frequency = 63, Q = 2.80},
    {name = "eq", gain = -2.3, frequency = 543, Q = 3.52},
    {name = "eq", gain = 3.5, frequency = 3579, Q = 3.54},
    {name = "eq", gain = -5.4, frequency = 4151, Q = 5.80},
}
