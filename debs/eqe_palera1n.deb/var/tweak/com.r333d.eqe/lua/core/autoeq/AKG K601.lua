return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.6, frequency = 34, Q = 0.48},
    {name = "eq", gain = 2.5, frequency = 699, Q = 1.60},
    {name = "eq", gain = -5.6, frequency = 2317, Q = 1.56},
    {name = "eq", gain = 2.5, frequency = 5091, Q = 4.12},
    {name = "eq", gain = 3.2, frequency = 9756, Q = 1.73},
    {name = "eq", gain = -0.7, frequency = 37, Q = 2.45},
    {name = "eq", gain = 1.3, frequency = 64, Q = 3.44},
    {name = "eq", gain = -1.0, frequency = 190, Q = 1.71},
    {name = "eq", gain = -0.1, frequency = 1628, Q = 2.41},
    {name = "eq", gain = 0.3, frequency = 7464, Q = 2.97},
}
