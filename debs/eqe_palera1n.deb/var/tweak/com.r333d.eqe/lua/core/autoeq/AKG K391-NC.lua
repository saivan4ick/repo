return {
    {name = "preamp", gain = -5.7},
    {name = "eq", gain = -6.4, frequency = 519, Q = 0.67},
    {name = "eq", gain = 6.2, frequency = 923, Q = 1.34},
    {name = "eq", gain = 5.1, frequency = 2579, Q = 2.21},
    {name = "eq", gain = 4.9, frequency = 6147, Q = 4.46},
    {name = "eq", gain = 1.6, frequency = 8147, Q = 3.65},
    {name = "eq", gain = -1.9, frequency = 37, Q = 1.08},
    {name = "eq", gain = 1.6, frequency = 3199, Q = 5.61},
    {name = "eq", gain = -2.3, frequency = 4368, Q = 2.38},
    {name = "eq", gain = 1.5, frequency = 5333, Q = 2.84},
    {name = "eq", gain = -1.4, frequency = 18048, Q = 0.49},
}
