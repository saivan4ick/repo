return {
    {name = "preamp", gain = -5.4},
    {name = "eq", gain = -3.0, frequency = 33, Q = 0.93},
    {name = "eq", gain = -1.6, frequency = 2416, Q = 0.00},
    {name = "eq", gain = 6.2, frequency = 3051, Q = 2.09},
    {name = "eq", gain = 5.1, frequency = 5955, Q = 2.67},
    {name = "eq", gain = 4.5, frequency = 9900, Q = 1.51},
    {name = "eq", gain = 1.5, frequency = 35, Q = 2.32},
    {name = "eq", gain = 2.0, frequency = 961, Q = 1.67},
    {name = "eq", gain = -1.3, frequency = 1592, Q = 1.72},
    {name = "eq", gain = 1.6, frequency = 4379, Q = 2.43},
    {name = "eq", gain = -3.2, frequency = 4624, Q = 6.16},
}
