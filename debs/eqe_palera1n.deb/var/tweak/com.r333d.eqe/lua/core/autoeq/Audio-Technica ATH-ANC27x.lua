return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -16.2, frequency = 10, Q = 0.08},
    {name = "eq", gain = 5.8, frequency = 1956, Q = 1.74},
    {name = "eq", gain = 6.4, frequency = 4178, Q = 1.33},
    {name = "eq", gain = -9.8, frequency = 6229, Q = 4.19},
    {name = "eq", gain = 3.1, frequency = 9535, Q = 3.00},
    {name = "eq", gain = -2.1, frequency = 26, Q = 1.97},
    {name = "eq", gain = 2.1, frequency = 84, Q = 0.71},
    {name = "eq", gain = -2.2, frequency = 274, Q = 0.66},
    {name = "eq", gain = 1.9, frequency = 831, Q = 2.35},
    {name = "eq", gain = -1.8, frequency = 1229, Q = 5.59},
}
