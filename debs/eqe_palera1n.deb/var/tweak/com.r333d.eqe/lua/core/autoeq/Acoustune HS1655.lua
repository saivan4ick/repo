return {
    {name = "preamp", gain = -5.9},
    {name = "eq", gain = -3.9, frequency = 50, Q = 0.43},
    {name = "eq", gain = -3.3, frequency = 147, Q = 1.13},
    {name = "eq", gain = 6.0, frequency = 3779, Q = 2.21},
    {name = "eq", gain = -6.3, frequency = 5389, Q = 6.38},
    {name = "eq", gain = 2.9, frequency = 8655, Q = 2.25},
    {name = "eq", gain = -1.5, frequency = 254, Q = 2.11},
    {name = "eq", gain = 2.6, frequency = 521, Q = 1.23},
    {name = "eq", gain = 1.4, frequency = 6636, Q = 5.93},
    {name = "eq", gain = 3.1, frequency = 11604, Q = 1.48},
    {name = "eq", gain = -12.3, frequency = 19760, Q = 0.39},
}
