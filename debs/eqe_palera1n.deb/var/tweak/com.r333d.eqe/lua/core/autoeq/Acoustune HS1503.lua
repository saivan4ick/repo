return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = -5.3, frequency = 16, Q = 0.55},
    {name = "eq", gain = -5.2, frequency = 99, Q = 0.31},
    {name = "eq", gain = 4.6, frequency = 849, Q = 0.68},
    {name = "eq", gain = 4.4, frequency = 2135, Q = 2.15},
    {name = "eq", gain = -7.9, frequency = 5795, Q = 4.00},
    {name = "eq", gain = 1.4, frequency = 2679, Q = 4.13},
    {name = "eq", gain = -2.0, frequency = 3228, Q = 2.74},
    {name = "eq", gain = 1.8, frequency = 4281, Q = 3.96},
    {name = "eq", gain = 1.2, frequency = 6622, Q = 4.63},
    {name = "eq", gain = -2.3, frequency = 7812, Q = 3.63},
}
