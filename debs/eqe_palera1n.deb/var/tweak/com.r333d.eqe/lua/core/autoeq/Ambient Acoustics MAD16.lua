return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -2.0, frequency = 84, Q = 1.06},
    {name = "eq", gain = -5.6, frequency = 226, Q = 0.53},
    {name = "eq", gain = -7.7, frequency = 1580, Q = 1.46},
    {name = "eq", gain = 6.9, frequency = 2588, Q = 0.39},
    {name = "eq", gain = 5.2, frequency = 10532, Q = 1.32},
    {name = "eq", gain = 0.5, frequency = 18, Q = 1.19},
    {name = "eq", gain = 0.9, frequency = 4469, Q = 3.88},
    {name = "eq", gain = -3.6, frequency = 5390, Q = 3.30},
    {name = "eq", gain = 2.2, frequency = 6237, Q = 1.60},
    {name = "eq", gain = -11.4, frequency = 19543, Q = 1.00},
}
