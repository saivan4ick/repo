return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.5, frequency = 29, Q = 0.58},
    {name = "eq", gain = -3.3, frequency = 165, Q = 1.42},
    {name = "eq", gain = 5.2, frequency = 3914, Q = 3.42},
    {name = "eq", gain = -3.2, frequency = 9687, Q = 0.42},
    {name = "eq", gain = 7.1, frequency = 18396, Q = 0.42},
    {name = "eq", gain = 2.2, frequency = 494, Q = 3.93},
    {name = "eq", gain = 2.8, frequency = 942, Q = 2.05},
    {name = "eq", gain = 3.9, frequency = 3623, Q = 1.44},
    {name = "eq", gain = -3.6, frequency = 4004, Q = 0.68},
    {name = "eq", gain = 3.9, frequency = 6910, Q = 5.37},
}
