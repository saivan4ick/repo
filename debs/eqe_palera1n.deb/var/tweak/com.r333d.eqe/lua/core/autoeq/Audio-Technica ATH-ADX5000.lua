return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.2, frequency = 23, Q = 1.07},
    {name = "eq", gain = 6.5, frequency = 2251, Q = 1.41},
    {name = "eq", gain = 7.1, frequency = 6209, Q = 1.64},
    {name = "eq", gain = 7.0, frequency = 10030, Q = 0.66},
    {name = "eq", gain = -9.2, frequency = 16839, Q = 0.06},
    {name = "eq", gain = -2.3, frequency = 155, Q = 1.42},
    {name = "eq", gain = 2.9, frequency = 3052, Q = 5.28},
    {name = "eq", gain = -5.1, frequency = 3564, Q = 6.23},
    {name = "eq", gain = 2.6, frequency = 5554, Q = 3.32},
    {name = "eq", gain = -3.5, frequency = 5967, Q = 7.56},
}
