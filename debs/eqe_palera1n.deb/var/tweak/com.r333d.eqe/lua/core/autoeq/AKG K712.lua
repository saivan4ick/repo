return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = 3.5, frequency = 20, Q = 0.90},
    {name = "eq", gain = -4.0, frequency = 250, Q = 0.57},
    {name = "eq", gain = 6.1, frequency = 1251, Q = 2.09},
    {name = "eq", gain = 5.2, frequency = 3134, Q = 2.94},
    {name = "eq", gain = -4.3, frequency = 5628, Q = 5.77},
    {name = "eq", gain = -3.3, frequency = 2255, Q = 5.22},
    {name = "eq", gain = 1.4, frequency = 2507, Q = 2.74},
    {name = "eq", gain = 2.9, frequency = 9801, Q = 2.87},
    {name = "eq", gain = 3.1, frequency = 12310, Q = 1.50},
    {name = "eq", gain = -8.9, frequency = 19946, Q = 0.46},
}
