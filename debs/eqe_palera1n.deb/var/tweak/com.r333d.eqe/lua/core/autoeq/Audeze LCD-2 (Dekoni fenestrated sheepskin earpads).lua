return {
    {name = "preamp", gain = -5.4},
    {name = "eq", gain = -2.6, frequency = 187, Q = 0.91},
    {name = "eq", gain = -3.8, frequency = 1043, Q = 0.61},
    {name = "eq", gain = 7.4, frequency = 1695, Q = 1.36},
    {name = "eq", gain = 5.9, frequency = 4214, Q = 1.92},
    {name = "eq", gain = -5.8, frequency = 5526, Q = 3.91},
    {name = "eq", gain = 1.6, frequency = 20, Q = 1.09},
    {name = "eq", gain = 0.7, frequency = 657, Q = 6.52},
    {name = "eq", gain = 3.4, frequency = 10229, Q = 1.49},
    {name = "eq", gain = 1.2, frequency = 13269, Q = 1.69},
    {name = "eq", gain = -12.2, frequency = 19719, Q = 0.36},
}
