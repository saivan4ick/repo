return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 7.3, frequency = 35, Q = 0.53},
    {name = "eq", gain = -1.9, frequency = 1149, Q = 0.04},
    {name = "eq", gain = 6.9, frequency = 3147, Q = 2.39},
    {name = "eq", gain = 7.0, frequency = 6284, Q = 3.49},
    {name = "eq", gain = 6.6, frequency = 18908, Q = 0.48},
    {name = "eq", gain = 1.2, frequency = 55, Q = 4.51},
    {name = "eq", gain = 1.3, frequency = 471, Q = 1.59},
    {name = "eq", gain = -2.1, frequency = 1251, Q = 2.33},
    {name = "eq", gain = 1.7, frequency = 2135, Q = 2.32},
    {name = "eq", gain = -0.9, frequency = 2684, Q = 3.18},
}
