return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 5.1, frequency = 21, Q = 0.72},
    {name = "eq", gain = 3.8, frequency = 49, Q = 0.97},
    {name = "eq", gain = 3.1, frequency = 514, Q = 3.21},
    {name = "eq", gain = -5.4, frequency = 5707, Q = 5.35},
    {name = "eq", gain = 3.6, frequency = 9985, Q = 1.45},
    {name = "eq", gain = 1.8, frequency = 97, Q = 3.82},
    {name = "eq", gain = -1.7, frequency = 204, Q = 1.49},
    {name = "eq", gain = -2.2, frequency = 1521, Q = 2.62},
    {name = "eq", gain = -2.5, frequency = 3084, Q = 1.72},
    {name = "eq", gain = 3.4, frequency = 4171, Q = 4.27},
}
