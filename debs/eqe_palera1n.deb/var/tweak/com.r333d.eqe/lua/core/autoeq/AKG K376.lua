return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = -7.6, frequency = 15, Q = 0.49},
    {name = "eq", gain = -6.8, frequency = 98, Q = 0.29},
    {name = "eq", gain = 3.9, frequency = 855, Q = 0.81},
    {name = "eq", gain = 4.3, frequency = 3858, Q = 4.48},
    {name = "eq", gain = 7.0, frequency = 10579, Q = 1.20},
    {name = "eq", gain = 1.2, frequency = 2030, Q = 2.48},
    {name = "eq", gain = -2.5, frequency = 2600, Q = 4.65},
    {name = "eq", gain = 2.5, frequency = 4648, Q = 3.52},
    {name = "eq", gain = -6.1, frequency = 5581, Q = 3.73},
    {name = "eq", gain = 2.6, frequency = 7058, Q = 2.69},
}
