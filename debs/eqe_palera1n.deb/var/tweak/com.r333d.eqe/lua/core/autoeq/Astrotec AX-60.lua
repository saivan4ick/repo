return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 16, Q = 0.64},
    {name = "eq", gain = -4.3, frequency = 120, Q = 0.63},
    {name = "eq", gain = -3.1, frequency = 288, Q = 1.04},
    {name = "eq", gain = 5.5, frequency = 3112, Q = 1.04},
    {name = "eq", gain = 4.6, frequency = 5327, Q = 3.09},
    {name = "eq", gain = 1.8, frequency = 1840, Q = 3.51},
    {name = "eq", gain = 2.3, frequency = 4104, Q = 2.91},
    {name = "eq", gain = 3.6, frequency = 6156, Q = 7.55},
    {name = "eq", gain = -1.8, frequency = 17390, Q = 0.07},
    {name = "eq", gain = -3.8, frequency = 19244, Q = 0.48},
}
