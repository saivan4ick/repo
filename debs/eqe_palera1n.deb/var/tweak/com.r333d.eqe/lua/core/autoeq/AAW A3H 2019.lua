return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.5, frequency = 27, Q = 0.63},
    {name = "eq", gain = -5.4, frequency = 268, Q = 0.52},
    {name = "eq", gain = 5.0, frequency = 3066, Q = 1.76},
    {name = "eq", gain = 5.4, frequency = 3869, Q = 0.09},
    {name = "eq", gain = -6.9, frequency = 17234, Q = 0.05},
    {name = "eq", gain = 2.6, frequency = 4341, Q = 5.19},
    {name = "eq", gain = -3.3, frequency = 5172, Q = 7.98},
    {name = "eq", gain = 1.3, frequency = 10081, Q = 3.73},
    {name = "eq", gain = 1.2, frequency = 12453, Q = 1.73},
    {name = "eq", gain = -0.6, frequency = 16274, Q = 0.07},
}
