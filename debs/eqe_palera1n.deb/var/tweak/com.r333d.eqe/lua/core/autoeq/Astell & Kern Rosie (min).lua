return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -5.7, frequency = 202, Q = 0.56},
    {name = "eq", gain = 2.5, frequency = 900, Q = 1.85},
    {name = "eq", gain = 5.2, frequency = 2716, Q = 1.75},
    {name = "eq", gain = 4.6, frequency = 4373, Q = 1.77},
    {name = "eq", gain = 2.5, frequency = 22050, Q = 2.35},
    {name = "eq", gain = 2.3, frequency = 26, Q = 1.53},
    {name = "eq", gain = -2.9, frequency = 5355, Q = 7.51},
    {name = "eq", gain = 3.9, frequency = 6056, Q = 3.58},
    {name = "eq", gain = -2.9, frequency = 8049, Q = 1.76},
    {name = "eq", gain = 2.1, frequency = 10467, Q = 2.43},
}
