return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -2.9, frequency = 86, Q = 0.63},
    {name = "eq", gain = -6.6, frequency = 260, Q = 0.52},
    {name = "eq", gain = 5.4, frequency = 2093, Q = 0.89},
    {name = "eq", gain = 4.5, frequency = 5182, Q = 0.85},
    {name = "eq", gain = 1.6, frequency = 10970, Q = 1.79},
    {name = "eq", gain = 1.1, frequency = 15, Q = 1.53},
    {name = "eq", gain = -0.2, frequency = 511, Q = 4.29},
    {name = "eq", gain = 0.6, frequency = 14573, Q = 1.09},
    {name = "eq", gain = -1.8, frequency = 19830, Q = 0.42},
}
