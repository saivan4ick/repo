return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 6.4, frequency = 30, Q = 0.52},
    {name = "eq", gain = -9.7, frequency = 1853, Q = 1.88},
    {name = "eq", gain = -4.6, frequency = 3306, Q = 7.16},
    {name = "eq", gain = 6.5, frequency = 4635, Q = 1.76},
    {name = "eq", gain = 6.7, frequency = 10860, Q = 1.40},
    {name = "eq", gain = 2.6, frequency = 6025, Q = 4.53},
    {name = "eq", gain = -3.3, frequency = 6745, Q = 3.18},
    {name = "eq", gain = 2.3, frequency = 8376, Q = 4.07},
    {name = "eq", gain = 3.3, frequency = 13893, Q = 2.16},
    {name = "eq", gain = -10.2, frequency = 19740, Q = 0.64},
}
