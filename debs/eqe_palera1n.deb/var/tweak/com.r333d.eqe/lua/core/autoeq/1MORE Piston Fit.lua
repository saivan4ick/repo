return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 7.3, frequency = 41, Q = 0.34},
    {name = "eq", gain = -5.0, frequency = 211, Q = 0.40},
    {name = "eq", gain = 2.7, frequency = 948, Q = 1.14},
    {name = "eq", gain = -5.9, frequency = 5478, Q = 1.16},
    {name = "eq", gain = 5.0, frequency = 17888, Q = 0.05},
    {name = "eq", gain = -2.7, frequency = 2263, Q = 3.06},
    {name = "eq", gain = 2.5, frequency = 2689, Q = 5.69},
    {name = "eq", gain = 2.0, frequency = 2810, Q = 0.95},
    {name = "eq", gain = -3.0, frequency = 3264, Q = 4.14},
    {name = "eq", gain = -0.4, frequency = 3417, Q = 0.23},
}
