return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.7, frequency = 24, Q = 0.87},
    {name = "eq", gain = -4.1, frequency = 65, Q = 1.06},
    {name = "eq", gain = 6.9, frequency = 4601, Q = 2.82},
    {name = "eq", gain = -12.1, frequency = 5892, Q = 4.57},
    {name = "eq", gain = -5.6, frequency = 20063, Q = 0.09},
    {name = "eq", gain = -1.5, frequency = 158, Q = 3.07},
    {name = "eq", gain = 1.7, frequency = 298, Q = 4.21},
    {name = "eq", gain = 2.3, frequency = 576, Q = 1.39},
    {name = "eq", gain = -3.0, frequency = 1932, Q = 1.57},
    {name = "eq", gain = 2.2, frequency = 3065, Q = 4.30},
}
