return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 6.8, frequency = 33, Q = 0.65},
    {name = "eq", gain = 3.2, frequency = 660, Q = 0.69},
    {name = "eq", gain = -2.8, frequency = 2006, Q = 2.22},
    {name = "eq", gain = 8.2, frequency = 3229, Q = 2.33},
    {name = "eq", gain = -4.1, frequency = 18693, Q = 0.02},
    {name = "eq", gain = 3.0, frequency = 63, Q = 3.46},
    {name = "eq", gain = -2.4, frequency = 101, Q = 1.74},
    {name = "eq", gain = 2.3, frequency = 4650, Q = 4.26},
    {name = "eq", gain = -4.6, frequency = 5919, Q = 4.01},
    {name = "eq", gain = 2.5, frequency = 10751, Q = 1.64},
}
