return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 3.9, frequency = 31, Q = 0.44},
    {name = "eq", gain = -1.5, frequency = 341, Q = 0.15},
    {name = "eq", gain = -2.1, frequency = 1105, Q = 1.87},
    {name = "eq", gain = -4.7, frequency = 5155, Q = 5.79},
    {name = "eq", gain = 7.0, frequency = 8201, Q = 1.92},
    {name = "eq", gain = 1.3, frequency = 1718, Q = 5.02},
    {name = "eq", gain = -2.2, frequency = 2342, Q = 3.10},
    {name = "eq", gain = 3.5, frequency = 3977, Q = 2.93},
    {name = "eq", gain = -2.4, frequency = 4539, Q = 5.08},
    {name = "eq", gain = -11.6, frequency = 19328, Q = 0.73},
}
