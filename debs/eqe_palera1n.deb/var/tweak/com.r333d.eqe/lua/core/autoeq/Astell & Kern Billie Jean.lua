return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -3.4, frequency = 23, Q = 0.27},
    {name = "eq", gain = -3.8, frequency = 101, Q = 0.72},
    {name = "eq", gain = -4.9, frequency = 244, Q = 0.76},
    {name = "eq", gain = 4.5, frequency = 2606, Q = 2.54},
    {name = "eq", gain = 6.2, frequency = 5379, Q = 0.79},
    {name = "eq", gain = 1.5, frequency = 899, Q = 2.15},
    {name = "eq", gain = -3.4, frequency = 1596, Q = 1.99},
    {name = "eq", gain = 0.9, frequency = 1970, Q = 2.59},
    {name = "eq", gain = 2.0, frequency = 2131, Q = 5.15},
    {name = "eq", gain = 1.1, frequency = 9985, Q = 4.02},
}
