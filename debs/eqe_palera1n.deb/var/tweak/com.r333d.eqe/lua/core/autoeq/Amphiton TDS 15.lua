return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 6.1, frequency = 27, Q = 0.35},
    {name = "eq", gain = -3.7, frequency = 1240, Q = 0.52},
    {name = "eq", gain = 4.7, frequency = 3269, Q = 1.37},
    {name = "eq", gain = 2.5, frequency = 5808, Q = 2.74},
    {name = "eq", gain = 4.7, frequency = 10041, Q = 2.28},
    {name = "eq", gain = 0.7, frequency = 110, Q = 3.54},
    {name = "eq", gain = -1.0, frequency = 220, Q = 2.39},
    {name = "eq", gain = 0.4, frequency = 768, Q = 0.91},
    {name = "eq", gain = -0.6, frequency = 1029, Q = 2.59},
}
