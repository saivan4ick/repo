return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -2.5, frequency = 69, Q = 0.26},
    {name = "eq", gain = -5.0, frequency = 219, Q = 0.40},
    {name = "eq", gain = 3.0, frequency = 946, Q = 1.00},
    {name = "eq", gain = 4.1, frequency = 2003, Q = 2.20},
    {name = "eq", gain = 6.8, frequency = 7798, Q = 1.25},
    {name = "eq", gain = 2.5, frequency = 3479, Q = 4.32},
    {name = "eq", gain = -5.1, frequency = 4133, Q = 3.68},
    {name = "eq", gain = 2.6, frequency = 5695, Q = 2.37},
    {name = "eq", gain = -1.5, frequency = 7430, Q = 5.68},
    {name = "eq", gain = -6.3, frequency = 19340, Q = 0.82},
}
