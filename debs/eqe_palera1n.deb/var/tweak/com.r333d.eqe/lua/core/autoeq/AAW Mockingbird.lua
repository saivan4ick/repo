return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 2.8, frequency = 15, Q = 0.32},
    {name = "eq", gain = -4.3, frequency = 283, Q = 0.36},
    {name = "eq", gain = 3.8, frequency = 2922, Q = 2.12},
    {name = "eq", gain = 5.9, frequency = 4643, Q = 1.88},
    {name = "eq", gain = 3.0, frequency = 7562, Q = 3.07},
    {name = "eq", gain = -1.1, frequency = 1797, Q = 4.63},
    {name = "eq", gain = 1.4, frequency = 9658, Q = 0.45},
    {name = "eq", gain = 3.0, frequency = 10352, Q = 1.57},
    {name = "eq", gain = -8.8, frequency = 19458, Q = 0.24},
    {name = "eq", gain = -8.6, frequency = 19775, Q = 0.43},
}
