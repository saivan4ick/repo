return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 6.3, frequency = 27, Q = 0.36},
    {name = "eq", gain = -1.9, frequency = 421, Q = 0.16},
    {name = "eq", gain = 4.4, frequency = 2096, Q = 3.18},
    {name = "eq", gain = 6.1, frequency = 3699, Q = 2.97},
    {name = "eq", gain = -3.2, frequency = 11678, Q = 1.08},
    {name = "eq", gain = 2.0, frequency = 674, Q = 6.02},
    {name = "eq", gain = 0.7, frequency = 828, Q = 2.63},
    {name = "eq", gain = -1.3, frequency = 906, Q = 2.01},
    {name = "eq", gain = 3.7, frequency = 6093, Q = 3.05},
    {name = "eq", gain = -1.8, frequency = 6260, Q = 1.29},
}
