local page = {}
page.title = 'AutoEq'
page.icon = IMG('jaakkopasanen.jpg', false):retain()
page.hide_nav_button = true

function page:init()
    local function push(f, title)
        self.nav:pushViewController_animated(VIEWCONTROLLER(f, title), true)
    end

    local vc = VIEWCONTROLLER(function(m)
        local target = ns.target:new()
        target.onaction = function()
            TOGGLE_NAV()
        end

        local nav_button = new_nav_button(0, 0)
        nav_button.ontoggle = TOGGLE_NAV

        local item = objc.UIBarButtonItem:alloc():initWithCustomView(nav_button.m)
        m:navigationItem():setLeftBarButtonItem(item)

        local presets = io.ls(LUA_PATH..'/../core/autoeq')
        table.sort(presets, function(a, b)
            return a < b
        end)
        local githubUrl = 'github.com/jaakkopasanen/AutoEq'
        table.insert(presets, 1, githubUrl)

        local tbl = ui.filtertable:new()
        tbl.deblist = presets

        tbl.searchbar.m:setPlaceholder('Search for your headphones')
        tbl.searchbar.m:setBarStyle(1)

        function page:navpressed(hiding)
            tbl.searchbar.m:resignFirstResponder()
        end

        tbl.section = {#presets}
        tbl.m:setFrame(m:view():bounds())
        local super = tbl.cell.mnew
        local font
        function tbl.cell.onshow(_, m, section, row)
            local self = objc.getref(m)
            local item = tbl:list()[row]
            font = font or m:textLabel():font():retain()

            if item == githubUrl then
                m:textLabel():setText(item)
                m:imageView():setImage(page.icon)
                m:textLabel():setFont(font:fontWithSize(13))
                m:detailTextLabel():setNumberOfLines(0)
                m:detailTextLabel():setFont(font:fontWithSize(10))
                m:detailTextLabel():setText('Conversion script in /var/tweak/com.r333d.eqe/lua/misc/convert_autoeq.lua')
            else
                if item == nil or #item < 4 or string.sub(item, #item - 3, #item) ~= '.lua' then
                    m:textLabel():setText(item)
                else
                    m:textLabel():setText(string.sub(item, 1, #item - 4))
                end
                m:imageView():setImage(nil)
                m:textLabel():setFont(font)
                m:detailTextLabel():setText(nil)
            end
        end
        function tbl.cell.onselect(_, section, row)
            local item = tbl:list()[row]
            if item == githubUrl then
                objc.UIApplication:sharedApplication():openURL(objc.NSURL:URLWithString('https://'..githubUrl))
            elseif item ~= nil then
                IPC('eqe.loadraw(LUA_PATH.."/autoeq/'..item..'")')
            end
        end
        function tbl:search(text, item)
            return string.find(string.lower(item), string.lower(text))
        end

        m:view():addSubview(tbl.m)

    end, page.title)
    self.nav = objc.UINavigationController:alloc():initWithRootViewController(vc)

    self.nav:navigationBar():setBarTintColor(objc.EQEMainView:themeColor())
    self.nav:navigationBar():setTintColor(objc.UIColor:whiteColor())
    self.nav:navigationBar():setTitleTextAttributes{[C.NSForegroundColorAttributeName] = objc.UIColor:whiteColor()}
    self.view = self.nav:view()
end
return page
