return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 5.4, frequency = 22, Q = 0.41},
    {name = "eq", gain = -2.0, frequency = 600, Q = 0.08},
    {name = "eq", gain = 8.4, frequency = 2943, Q = 1.94},
    {name = "eq", gain = 8.3, frequency = 5520, Q = 2.13},
    {name = "eq", gain = -2.9, frequency = 9863, Q = 0.56},
    {name = "eq", gain = -1.3, frequency = 234, Q = 1.77},
    {name = "eq", gain = 2.3, frequency = 876, Q = 1.07},
    {name = "eq", gain = -3.7, frequency = 1684, Q = 1.29},
    {name = "eq", gain = 3.7, frequency = 2466, Q = 1.91},
    {name = "eq", gain = -3.0, frequency = 2947, Q = 6.09},
}
