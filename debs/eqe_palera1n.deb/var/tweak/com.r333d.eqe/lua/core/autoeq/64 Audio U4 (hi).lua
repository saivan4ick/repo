return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = 6.1, frequency = 54, Q = 0.06},
    {name = "eq", gain = 7.3, frequency = 721, Q = 0.53},
    {name = "eq", gain = 8.5, frequency = 1161, Q = 0.99},
    {name = "eq", gain = -18.9, frequency = 5430, Q = 0.13},
    {name = "eq", gain = -28.6, frequency = 19563, Q = 0.35},
    {name = "eq", gain = 3.0, frequency = 1927, Q = 3.50},
    {name = "eq", gain = -5.6, frequency = 2650, Q = 2.89},
    {name = "eq", gain = 5.4, frequency = 3788, Q = 2.88},
    {name = "eq", gain = -3.1, frequency = 7106, Q = 1.40},
    {name = "eq", gain = 2.9, frequency = 10125, Q = 1.70},
}
