return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 6.3, frequency = 22, Q = 0.61},
    {name = "eq", gain = -6.5, frequency = 315, Q = 0.33},
    {name = "eq", gain = 7.1, frequency = 998, Q = 1.60},
    {name = "eq", gain = 6.6, frequency = 2874, Q = 1.50},
    {name = "eq", gain = 6.7, frequency = 16742, Q = 0.29},
    {name = "eq", gain = 3.3, frequency = 1242, Q = 5.01},
    {name = "eq", gain = -3.1, frequency = 1558, Q = 2.41},
    {name = "eq", gain = 2.6, frequency = 2142, Q = 5.01},
    {name = "eq", gain = 2.1, frequency = 4227, Q = 4.18},
    {name = "eq", gain = -2.8, frequency = 5560, Q = 3.67},
}
