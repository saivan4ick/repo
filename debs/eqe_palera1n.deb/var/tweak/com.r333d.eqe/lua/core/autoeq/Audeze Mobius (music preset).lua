return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -2.2, frequency = 21, Q = 1.61},
    {name = "eq", gain = -2.7, frequency = 68, Q = 0.56},
    {name = "eq", gain = -4.0, frequency = 204, Q = 1.64},
    {name = "eq", gain = 3.2, frequency = 4326, Q = 4.18},
    {name = "eq", gain = 6.2, frequency = 6499, Q = 2.50},
    {name = "eq", gain = 1.4, frequency = 429, Q = 4.00},
    {name = "eq", gain = 1.3, frequency = 2379, Q = 3.85},
    {name = "eq", gain = -2.3, frequency = 2917, Q = 4.94},
    {name = "eq", gain = 2.3, frequency = 9358, Q = 1.53},
    {name = "eq", gain = -8.1, frequency = 19470, Q = 0.32},
}
