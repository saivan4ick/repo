return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -1.9, frequency = 84, Q = 1.13},
    {name = "eq", gain = -5.6, frequency = 243, Q = 0.66},
    {name = "eq", gain = 5.7, frequency = 2135, Q = 1.15},
    {name = "eq", gain = 5.7, frequency = 4834, Q = 2.29},
    {name = "eq", gain = 6.8, frequency = 18349, Q = 0.60},
    {name = "eq", gain = -1.5, frequency = 1742, Q = 1.76},
    {name = "eq", gain = -2.2, frequency = 3123, Q = 5.50},
    {name = "eq", gain = 2.4, frequency = 5332, Q = 0.30},
    {name = "eq", gain = 4.8, frequency = 6034, Q = 4.34},
    {name = "eq", gain = -5.8, frequency = 6924, Q = 1.14},
}
