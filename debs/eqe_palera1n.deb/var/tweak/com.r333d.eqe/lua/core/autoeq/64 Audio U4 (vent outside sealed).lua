return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -5.3, frequency = 15, Q = 0.23},
    {name = "eq", gain = -3.9, frequency = 174, Q = 0.39},
    {name = "eq", gain = 3.3, frequency = 1283, Q = 0.90},
    {name = "eq", gain = 3.5, frequency = 3842, Q = 2.41},
    {name = "eq", gain = 6.4, frequency = 12104, Q = 0.74},
    {name = "eq", gain = -5.0, frequency = 1854, Q = 4.85},
    {name = "eq", gain = 3.6, frequency = 1904, Q = 1.56},
    {name = "eq", gain = -1.0, frequency = 3115, Q = 0.35},
    {name = "eq", gain = 1.1, frequency = 4291, Q = 4.35},
    {name = "eq", gain = 1.5, frequency = 9382, Q = 4.54},
}
