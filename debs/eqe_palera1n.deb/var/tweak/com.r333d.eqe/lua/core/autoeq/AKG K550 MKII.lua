return {
    {name = "preamp", gain = -5.6},
    {name = "eq", gain = -4.0, frequency = 23, Q = 1.65},
    {name = "eq", gain = -4.3, frequency = 132, Q = 1.78},
    {name = "eq", gain = 7.2, frequency = 4223, Q = 2.38},
    {name = "eq", gain = -3.9, frequency = 6232, Q = 1.56},
    {name = "eq", gain = -4.1, frequency = 19832, Q = 0.14},
    {name = "eq", gain = 4.6, frequency = 60, Q = 2.13},
    {name = "eq", gain = -2.1, frequency = 62, Q = 0.82},
    {name = "eq", gain = 2.9, frequency = 1154, Q = 1.61},
    {name = "eq", gain = 1.9, frequency = 2193, Q = 1.67},
    {name = "eq", gain = -3.3, frequency = 2748, Q = 3.24},
}
