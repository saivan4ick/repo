return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -6.1, frequency = 51, Q = 0.16},
    {name = "eq", gain = 3.4, frequency = 778, Q = 0.94},
    {name = "eq", gain = -5.0, frequency = 2238, Q = 2.38},
    {name = "eq", gain = -6.0, frequency = 4565, Q = 4.50},
    {name = "eq", gain = 6.9, frequency = 8207, Q = 0.71},
    {name = "eq", gain = 2.2, frequency = 993, Q = 4.26},
    {name = "eq", gain = -1.0, frequency = 1055, Q = 1.42},
    {name = "eq", gain = 2.5, frequency = 3366, Q = 3.89},
    {name = "eq", gain = -1.0, frequency = 3569, Q = 1.45},
    {name = "eq", gain = 2.0, frequency = 12063, Q = 4.25},
}
