return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -5.6, frequency = 16, Q = 0.13},
    {name = "eq", gain = -7.3, frequency = 256, Q = 0.31},
    {name = "eq", gain = 8.0, frequency = 1325, Q = 0.31},
    {name = "eq", gain = -10.3, frequency = 6264, Q = 2.92},
    {name = "eq", gain = 3.5, frequency = 10529, Q = 1.52},
    {name = "eq", gain = 1.8, frequency = 2921, Q = 3.81},
    {name = "eq", gain = -1.5, frequency = 3533, Q = 1.91},
    {name = "eq", gain = 1.2, frequency = 4591, Q = 4.62},
    {name = "eq", gain = 1.3, frequency = 13729, Q = 1.74},
    {name = "eq", gain = -5.5, frequency = 19647, Q = 0.67},
}
