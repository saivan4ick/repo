return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 7.2, frequency = 35, Q = 0.41},
    {name = "eq", gain = -6.0, frequency = 149, Q = 0.58},
    {name = "eq", gain = 4.4, frequency = 1627, Q = 2.25},
    {name = "eq", gain = 3.8, frequency = 4382, Q = 1.81},
    {name = "eq", gain = 6.6, frequency = 19150, Q = 0.85},
    {name = "eq", gain = 0.9, frequency = 578, Q = 3.62},
    {name = "eq", gain = -3.9, frequency = 2702, Q = 4.19},
    {name = "eq", gain = 1.9, frequency = 3036, Q = 1.73},
    {name = "eq", gain = -1.8, frequency = 10460, Q = 2.31},
    {name = "eq", gain = 1.2, frequency = 16385, Q = 1.97},
}
