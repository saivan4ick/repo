return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 3.1, frequency = 22, Q = 0.61},
    {name = "eq", gain = -2.0, frequency = 199, Q = 0.96},
    {name = "eq", gain = -2.0, frequency = 778, Q = 0.54},
    {name = "eq", gain = 6.6, frequency = 4176, Q = 3.18},
    {name = "eq", gain = 5.0, frequency = 8179, Q = 2.22},
    {name = "eq", gain = 1.9, frequency = 6643, Q = 4.80},
    {name = "eq", gain = 3.2, frequency = 10184, Q = 2.83},
    {name = "eq", gain = 3.0, frequency = 12505, Q = 1.60},
    {name = "eq", gain = -8.9, frequency = 19050, Q = 0.31},
    {name = "eq", gain = -8.3, frequency = 19731, Q = 0.60},
}
