return {
    {name = "preamp", gain = -7.4},
    {name = "eq", gain = 7.6, frequency = 105, Q = 0.16},
    {name = "eq", gain = -22.4, frequency = 687, Q = 1.31},
    {name = "eq", gain = 3.2, frequency = 2126, Q = 4.57},
    {name = "eq", gain = -5.7, frequency = 7610, Q = 1.59},
    {name = "eq", gain = 4.9, frequency = 9277, Q = 0.63},
    {name = "eq", gain = 1.3, frequency = 20, Q = 2.59},
    {name = "eq", gain = 3.3, frequency = 268, Q = 2.62},
    {name = "eq", gain = -2.5, frequency = 544, Q = 5.11},
    {name = "eq", gain = -1.4, frequency = 1281, Q = 3.64},
}
