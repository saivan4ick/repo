return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 2.5, frequency = 18, Q = 0.63},
    {name = "eq", gain = -5.5, frequency = 220, Q = 0.47},
    {name = "eq", gain = 3.6, frequency = 2491, Q = 1.78},
    {name = "eq", gain = 5.1, frequency = 4153, Q = 1.41},
    {name = "eq", gain = 6.0, frequency = 10936, Q = 0.98},
    {name = "eq", gain = 0.9, frequency = 918, Q = 2.99},
    {name = "eq", gain = -0.9, frequency = 1357, Q = 3.54},
    {name = "eq", gain = 1.1, frequency = 5240, Q = 5.78},
    {name = "eq", gain = -2.5, frequency = 7150, Q = 3.66},
    {name = "eq", gain = 2.1, frequency = 7984, Q = 3.92},
}
