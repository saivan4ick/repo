return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -4.3, frequency = 233, Q = 0.37},
    {name = "eq", gain = 5.8, frequency = 2704, Q = 2.45},
    {name = "eq", gain = 6.6, frequency = 5202, Q = 1.36},
    {name = "eq", gain = -8.8, frequency = 6631, Q = 5.74},
    {name = "eq", gain = 2.8, frequency = 10505, Q = 1.63},
    {name = "eq", gain = 1.8, frequency = 20, Q = 1.31},
    {name = "eq", gain = 2.1, frequency = 1230, Q = 0.69},
    {name = "eq", gain = -4.8, frequency = 1473, Q = 1.47},
    {name = "eq", gain = 2.4, frequency = 2182, Q = 5.55},
    {name = "eq", gain = -0.2, frequency = 4902, Q = 3.37},
}
