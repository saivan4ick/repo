return {
    {name = "preamp", gain = -3.1},
    {name = "eq", gain = 2.9, frequency = 53, Q = 0.82},
    {name = "eq", gain = 4.2, frequency = 1843, Q = 1.34},
    {name = "eq", gain = -4.7, frequency = 2951, Q = 1.13},
    {name = "eq", gain = 3.1, frequency = 7295, Q = 3.12},
    {name = "eq", gain = -6.5, frequency = 19247, Q = 0.19},
    {name = "eq", gain = 0.9, frequency = 357, Q = 3.44},
    {name = "eq", gain = 2.4, frequency = 5038, Q = 5.56},
    {name = "eq", gain = -2.3, frequency = 5606, Q = 2.51},
    {name = "eq", gain = 1.2, frequency = 6488, Q = 2.03},
    {name = "eq", gain = 0.3, frequency = 13093, Q = 0.77},
}
