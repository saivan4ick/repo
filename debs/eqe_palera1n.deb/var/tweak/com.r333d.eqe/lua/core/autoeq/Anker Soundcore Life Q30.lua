return {
    {name = "preamp", gain = -4.6},
    {name = "eq", gain = -7.1, frequency = 17, Q = 0.73},
    {name = "eq", gain = -8.2, frequency = 56, Q = 0.82},
    {name = "eq", gain = -6.2, frequency = 126, Q = 1.61},
    {name = "eq", gain = 4.3, frequency = 1009, Q = 1.08},
    {name = "eq", gain = 4.1, frequency = 3797, Q = 3.20},
    {name = "eq", gain = 1.2, frequency = 256, Q = 3.19},
    {name = "eq", gain = -3.0, frequency = 493, Q = 4.56},
    {name = "eq", gain = 1.8, frequency = 634, Q = 4.39},
    {name = "eq", gain = 2.5, frequency = 4893, Q = 3.35},
    {name = "eq", gain = -12.5, frequency = 19305, Q = 0.29},
}
