return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -6.2, frequency = 53, Q = 0.34},
    {name = "eq", gain = -7.5, frequency = 197, Q = 0.40},
    {name = "eq", gain = 7.0, frequency = 1426, Q = 0.47},
    {name = "eq", gain = 3.5, frequency = 4143, Q = 2.27},
    {name = "eq", gain = 6.4, frequency = 11098, Q = 1.48},
    {name = "eq", gain = 1.8, frequency = 5037, Q = 6.58},
    {name = "eq", gain = 0.9, frequency = 5775, Q = 3.74},
    {name = "eq", gain = -4.2, frequency = 5984, Q = 5.67},
    {name = "eq", gain = 2.0, frequency = 14547, Q = 1.20},
    {name = "eq", gain = -6.8, frequency = 19904, Q = 0.59},
}
