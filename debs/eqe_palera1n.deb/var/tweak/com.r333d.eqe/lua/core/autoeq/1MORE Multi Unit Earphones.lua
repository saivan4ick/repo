return {
    {name = "preamp", gain = -7.5},
    {name = "eq", gain = -4.4, frequency = 98, Q = 0.75},
    {name = "eq", gain = -3.7, frequency = 230, Q = 1.11},
    {name = "eq", gain = -2.4, frequency = 2022, Q = 2.47},
    {name = "eq", gain = 2.5, frequency = 2983, Q = 4.39},
    {name = "eq", gain = 7.2, frequency = 6678, Q = 1.87},
    {name = "eq", gain = 1.5, frequency = 19, Q = 2.00},
    {name = "eq", gain = 1.7, frequency = 857, Q = 2.82},
    {name = "eq", gain = 4.2, frequency = 8980, Q = 2.21},
    {name = "eq", gain = 1.4, frequency = 10346, Q = 0.64},
    {name = "eq", gain = -14.6, frequency = 19176, Q = 0.32},
}
