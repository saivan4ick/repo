return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.5, frequency = 27, Q = 0.81},
    {name = "eq", gain = 6.8, frequency = 2974, Q = 2.22},
    {name = "eq", gain = 4.8, frequency = 5933, Q = 1.25},
    {name = "eq", gain = 5.8, frequency = 7895, Q = 0.50},
    {name = "eq", gain = -8.4, frequency = 15606, Q = 0.06},
    {name = "eq", gain = 2.4, frequency = 257, Q = 2.90},
    {name = "eq", gain = -2.7, frequency = 4175, Q = 6.07},
    {name = "eq", gain = 3.1, frequency = 5213, Q = 3.06},
    {name = "eq", gain = -3.8, frequency = 6035, Q = 4.16},
    {name = "eq", gain = 2.1, frequency = 6893, Q = 6.21},
}
