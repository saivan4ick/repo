return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -3.0, frequency = 71, Q = 0.46},
    {name = "eq", gain = -2.3, frequency = 196, Q = 1.22},
    {name = "eq", gain = -5.1, frequency = 2060, Q = 2.61},
    {name = "eq", gain = 5.1, frequency = 3284, Q = 3.73},
    {name = "eq", gain = 7.0, frequency = 9411, Q = 0.92},
    {name = "eq", gain = 1.9, frequency = 791, Q = 2.13},
    {name = "eq", gain = 2.5, frequency = 3929, Q = 4.93},
    {name = "eq", gain = 1.0, frequency = 4247, Q = 3.38},
    {name = "eq", gain = -7.6, frequency = 4785, Q = 3.44},
    {name = "eq", gain = 4.9, frequency = 5872, Q = 3.54},
}
