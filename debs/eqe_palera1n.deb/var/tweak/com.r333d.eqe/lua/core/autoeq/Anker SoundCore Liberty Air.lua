return {
    {name = "preamp", gain = -5.3},
    {name = "eq", gain = -4.0, frequency = 22, Q = 0.39},
    {name = "eq", gain = -4.3, frequency = 77, Q = 0.88},
    {name = "eq", gain = -2.7, frequency = 309, Q = 1.98},
    {name = "eq", gain = 3.3, frequency = 2329, Q = 3.21},
    {name = "eq", gain = 5.0, frequency = 5065, Q = 2.25},
    {name = "eq", gain = 1.5, frequency = 890, Q = 2.17},
    {name = "eq", gain = -1.7, frequency = 1445, Q = 4.23},
    {name = "eq", gain = -1.0, frequency = 7410, Q = 3.17},
    {name = "eq", gain = 3.3, frequency = 19518, Q = 0.37},
}
