return {
    {name = "preamp", gain = -7.5},
    {name = "eq", gain = 6.6, frequency = 26, Q = 1.05},
    {name = "eq", gain = 4.8, frequency = 2575, Q = 1.51},
    {name = "eq", gain = -3.0, frequency = 2793, Q = 0.07},
    {name = "eq", gain = 8.1, frequency = 4596, Q = 1.50},
    {name = "eq", gain = 8.5, frequency = 17769, Q = 0.72},
    {name = "eq", gain = -2.8, frequency = 83, Q = 2.99},
    {name = "eq", gain = 4.2, frequency = 108, Q = 5.98},
    {name = "eq", gain = 2.1, frequency = 880, Q = 3.72},
    {name = "eq", gain = -1.7, frequency = 1578, Q = 5.23},
    {name = "eq", gain = -2.2, frequency = 9732, Q = 2.95},
}
