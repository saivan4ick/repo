return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = -6.9, frequency = 80, Q = 0.09},
    {name = "eq", gain = 4.6, frequency = 799, Q = 0.90},
    {name = "eq", gain = 5.8, frequency = 2804, Q = 1.45},
    {name = "eq", gain = 5.8, frequency = 8966, Q = 1.25},
    {name = "eq", gain = 5.1, frequency = 13366, Q = 2.21},
    {name = "eq", gain = 1.0, frequency = 3279, Q = 4.62},
    {name = "eq", gain = -3.7, frequency = 3692, Q = 4.19},
    {name = "eq", gain = 4.5, frequency = 4653, Q = 2.93},
    {name = "eq", gain = -6.7, frequency = 5957, Q = 5.16},
    {name = "eq", gain = 3.2, frequency = 6721, Q = 5.24},
}
