return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.7, frequency = 29, Q = 0.56},
    {name = "eq", gain = -5.9, frequency = 306, Q = 0.37},
    {name = "eq", gain = 2.7, frequency = 945, Q = 1.35},
    {name = "eq", gain = 4.4, frequency = 1996, Q = 0.74},
    {name = "eq", gain = 5.4, frequency = 5594, Q = 1.88},
    {name = "eq", gain = 1.3, frequency = 6371, Q = 0.73},
    {name = "eq", gain = 2.0, frequency = 9113, Q = 2.73},
    {name = "eq", gain = 1.2, frequency = 11675, Q = 1.32},
    {name = "eq", gain = -4.3, frequency = 17708, Q = 0.22},
    {name = "eq", gain = -5.2, frequency = 19820, Q = 0.46},
}
