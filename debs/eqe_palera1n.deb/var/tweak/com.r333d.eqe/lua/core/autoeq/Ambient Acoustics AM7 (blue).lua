return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -4.8, frequency = 164, Q = 0.72},
    {name = "eq", gain = 4.6, frequency = 4477, Q = 4.69},
    {name = "eq", gain = 2.5, frequency = 5132, Q = 4.22},
    {name = "eq", gain = 8.0, frequency = 11558, Q = 1.09},
    {name = "eq", gain = -12.0, frequency = 19731, Q = 0.59},
    {name = "eq", gain = 2.1, frequency = 21, Q = 1.87},
    {name = "eq", gain = 3.7, frequency = 896, Q = 1.77},
    {name = "eq", gain = -7.3, frequency = 1992, Q = 3.87},
    {name = "eq", gain = 4.0, frequency = 2766, Q = 2.53},
    {name = "eq", gain = -3.7, frequency = 3287, Q = 5.23},
}
