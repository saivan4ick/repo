return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -3.6, frequency = 54, Q = 0.05},
    {name = "eq", gain = -3.4, frequency = 676, Q = 1.37},
    {name = "eq", gain = 7.7, frequency = 1111, Q = 1.43},
    {name = "eq", gain = 5.0, frequency = 3519, Q = 1.76},
    {name = "eq", gain = 2.4, frequency = 4423, Q = 2.35},
    {name = "eq", gain = 3.9, frequency = 9792, Q = 0.66},
    {name = "eq", gain = -6.4, frequency = 18727, Q = 0.18},
    {name = "eq", gain = -2.0, frequency = 18913, Q = 0.41},
    {name = "eq", gain = -5.8, frequency = 20460, Q = 0.42},
}
