return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -4.4, frequency = 85, Q = 0.44},
    {name = "eq", gain = -2.6, frequency = 231, Q = 1.05},
    {name = "eq", gain = 3.8, frequency = 4645, Q = 0.47},
    {name = "eq", gain = 3.5, frequency = 13228, Q = 1.12},
    {name = "eq", gain = 5.9, frequency = 19100, Q = 0.47},
    {name = "eq", gain = 2.5, frequency = 949, Q = 2.75},
    {name = "eq", gain = -1.6, frequency = 3044, Q = 1.05},
    {name = "eq", gain = 1.9, frequency = 3721, Q = 2.60},
    {name = "eq", gain = 2.4, frequency = 6210, Q = 5.17},
    {name = "eq", gain = -1.8, frequency = 7371, Q = 4.41},
}
