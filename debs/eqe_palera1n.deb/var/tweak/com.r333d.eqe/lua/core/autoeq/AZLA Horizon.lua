return {
    {name = "preamp", gain = -5.1},
    {name = "eq", gain = -4.6, frequency = 37, Q = 0.08},
    {name = "eq", gain = 3.9, frequency = 756, Q = 0.73},
    {name = "eq", gain = 4.0, frequency = 3946, Q = 2.14},
    {name = "eq", gain = -4.0, frequency = 5732, Q = 2.79},
    {name = "eq", gain = 4.8, frequency = 10211, Q = 1.92},
    {name = "eq", gain = 0.3, frequency = 969, Q = 4.67},
    {name = "eq", gain = 2.2, frequency = 13292, Q = 1.51},
    {name = "eq", gain = -4.0, frequency = 19492, Q = 0.47},
    {name = "eq", gain = -5.0, frequency = 19976, Q = 0.70},
}
