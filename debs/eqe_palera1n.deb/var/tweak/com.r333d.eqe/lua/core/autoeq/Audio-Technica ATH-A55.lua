return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.5, frequency = 86, Q = 0.10},
    {name = "eq", gain = -5.7, frequency = 323, Q = 3.26},
    {name = "eq", gain = -4.4, frequency = 432, Q = 1.83},
    {name = "eq", gain = -5.0, frequency = 956, Q = 0.59},
    {name = "eq", gain = -0.7, frequency = 8970, Q = 2.89},
    {name = "eq", gain = 1.9, frequency = 209, Q = 5.37},
    {name = "eq", gain = 2.3, frequency = 1862, Q = 4.34},
    {name = "eq", gain = -2.2, frequency = 2443, Q = 5.73},
    {name = "eq", gain = -5.2, frequency = 4320, Q = 6.62},
    {name = "eq", gain = 2.9, frequency = 5474, Q = 5.54},
}
