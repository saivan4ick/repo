return {
    {name = "preamp", gain = -5.9},
    {name = "eq", gain = -2.6, frequency = 131, Q = 1.33},
    {name = "eq", gain = -2.8, frequency = 1540, Q = 1.41},
    {name = "eq", gain = 5.7, frequency = 4098, Q = 2.85},
    {name = "eq", gain = 2.3, frequency = 8453, Q = 1.42},
    {name = "eq", gain = 1.7, frequency = 22050, Q = 2.26},
    {name = "eq", gain = -2.5, frequency = 34, Q = 1.40},
    {name = "eq", gain = 1.5, frequency = 368, Q = 1.96},
    {name = "eq", gain = 1.2, frequency = 11684, Q = 1.92},
    {name = "eq", gain = 0.4, frequency = 14470, Q = 1.07},
    {name = "eq", gain = -4.6, frequency = 19983, Q = 0.38},
}
