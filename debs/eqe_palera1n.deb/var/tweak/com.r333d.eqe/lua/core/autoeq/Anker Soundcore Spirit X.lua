return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -8.3, frequency = 29, Q = 0.18},
    {name = "eq", gain = 3.7, frequency = 263, Q = 1.63},
    {name = "eq", gain = 1.8, frequency = 3865, Q = 0.76},
    {name = "eq", gain = -5.8, frequency = 5895, Q = 1.87},
    {name = "eq", gain = 6.3, frequency = 17200, Q = 0.17},
    {name = "eq", gain = 2.5, frequency = 877, Q = 1.73},
    {name = "eq", gain = -1.5, frequency = 1091, Q = 0.73},
    {name = "eq", gain = 1.0, frequency = 2184, Q = 3.06},
    {name = "eq", gain = -0.3, frequency = 8026, Q = 5.22},
    {name = "eq", gain = 0.4, frequency = 12350, Q = 3.77},
}
