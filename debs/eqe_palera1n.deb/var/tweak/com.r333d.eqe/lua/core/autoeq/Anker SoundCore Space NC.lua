return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -11.9, frequency = 25, Q = 0.40},
    {name = "eq", gain = -6.2, frequency = 102, Q = 1.13},
    {name = "eq", gain = -4.2, frequency = 2841, Q = 2.36},
    {name = "eq", gain = 6.2, frequency = 4922, Q = 4.02},
    {name = "eq", gain = 4.6, frequency = 8244, Q = 2.11},
    {name = "eq", gain = -1.0, frequency = 59, Q = 3.90},
    {name = "eq", gain = -2.6, frequency = 175, Q = 2.01},
    {name = "eq", gain = 4.6, frequency = 524, Q = 0.60},
    {name = "eq", gain = -2.6, frequency = 4231, Q = 0.13},
    {name = "eq", gain = 2.5, frequency = 10410, Q = 0.15},
}
