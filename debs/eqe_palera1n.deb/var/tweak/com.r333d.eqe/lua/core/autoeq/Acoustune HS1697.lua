return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 2.1, frequency = 22, Q = 0.98},
    {name = "eq", gain = -4.2, frequency = 152, Q = 0.82},
    {name = "eq", gain = 6.8, frequency = 3706, Q = 1.61},
    {name = "eq", gain = -7.6, frequency = 5506, Q = 6.16},
    {name = "eq", gain = 3.6, frequency = 9501, Q = 2.49},
    {name = "eq", gain = -1.4, frequency = 263, Q = 2.58},
    {name = "eq", gain = 2.6, frequency = 481, Q = 1.71},
    {name = "eq", gain = -1.3, frequency = 837, Q = 1.74},
    {name = "eq", gain = -1.5, frequency = 1334, Q = 2.96},
    {name = "eq", gain = 0.3, frequency = 2256, Q = 1.51},
}
