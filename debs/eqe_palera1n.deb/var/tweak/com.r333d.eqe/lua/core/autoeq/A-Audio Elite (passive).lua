return {
    {name = "preamp", gain = -4.4},
    {name = "eq", gain = -3.3, frequency = 35, Q = 0.34},
    {name = "eq", gain = -3.3, frequency = 142, Q = 1.55},
    {name = "eq", gain = 3.1, frequency = 2204, Q = 3.36},
    {name = "eq", gain = 2.1, frequency = 2931, Q = 3.42},
    {name = "eq", gain = 4.0, frequency = 11228, Q = 0.88},
    {name = "eq", gain = 1.9, frequency = 334, Q = 3.00},
    {name = "eq", gain = -2.4, frequency = 913, Q = 1.84},
    {name = "eq", gain = 0.8, frequency = 3836, Q = 0.53},
    {name = "eq", gain = -3.3, frequency = 4981, Q = 2.40},
    {name = "eq", gain = 1.6, frequency = 6273, Q = 3.81},
}
