return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = -5.5, frequency = 44, Q = 0.22},
    {name = "eq", gain = -8.2, frequency = 182, Q = 0.89},
    {name = "eq", gain = 14.2, frequency = 362, Q = 0.72},
    {name = "eq", gain = -11.9, frequency = 2101, Q = 0.27},
    {name = "eq", gain = 17.3, frequency = 3426, Q = 0.92},
    {name = "eq", gain = -1.2, frequency = 1294, Q = 2.88},
    {name = "eq", gain = 0.4, frequency = 1740, Q = 0.34},
    {name = "eq", gain = -1.1, frequency = 3472, Q = 6.19},
    {name = "eq", gain = 1.3, frequency = 6518, Q = 3.45},
    {name = "eq", gain = -2.0, frequency = 7497, Q = 4.28},
}
