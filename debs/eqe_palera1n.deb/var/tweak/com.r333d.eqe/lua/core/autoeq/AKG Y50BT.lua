return {
    {name = "preamp", gain = -5.9},
    {name = "eq", gain = 5.9, frequency = 22, Q = 1.14},
    {name = "eq", gain = 5.6, frequency = 183, Q = 3.39},
    {name = "eq", gain = -3.5, frequency = 1324, Q = 0.73},
    {name = "eq", gain = 5.5, frequency = 2528, Q = 2.92},
    {name = "eq", gain = -3.5, frequency = 5574, Q = 5.78},
    {name = "eq", gain = 1.4, frequency = 342, Q = 1.11},
    {name = "eq", gain = -3.5, frequency = 345, Q = 2.54},
    {name = "eq", gain = 1.2, frequency = 3919, Q = 7.29},
    {name = "eq", gain = 4.2, frequency = 10060, Q = 1.49},
    {name = "eq", gain = -10.7, frequency = 19688, Q = 0.50},
}
