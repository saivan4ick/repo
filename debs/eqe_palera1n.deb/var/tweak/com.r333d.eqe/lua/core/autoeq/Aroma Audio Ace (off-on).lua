return {
    {name = "preamp", gain = -8.0},
    {name = "eq", gain = 4.4, frequency = 12, Q = 0.28},
    {name = "eq", gain = -4.0, frequency = 222, Q = 0.32},
    {name = "eq", gain = 6.4, frequency = 2492, Q = 2.10},
    {name = "eq", gain = 3.6, frequency = 4569, Q = 1.36},
    {name = "eq", gain = 1.8, frequency = 9765, Q = 2.11},
    {name = "eq", gain = -6.3, frequency = 1384, Q = 2.32},
    {name = "eq", gain = 2.9, frequency = 1386, Q = 0.87},
    {name = "eq", gain = -3.0, frequency = 4012, Q = 7.26},
    {name = "eq", gain = 1.7, frequency = 4846, Q = 2.00},
    {name = "eq", gain = -2.7, frequency = 5526, Q = 6.16},
}
