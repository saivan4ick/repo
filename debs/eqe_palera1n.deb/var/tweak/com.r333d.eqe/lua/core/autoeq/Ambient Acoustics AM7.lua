return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = 5.9, frequency = 21, Q = 0.60},
    {name = "eq", gain = -3.2, frequency = 204, Q = 1.00},
    {name = "eq", gain = -7.6, frequency = 1972, Q = 5.53},
    {name = "eq", gain = 6.2, frequency = 4577, Q = 3.92},
    {name = "eq", gain = 6.8, frequency = 10890, Q = 1.98},
    {name = "eq", gain = 2.7, frequency = 885, Q = 2.29},
    {name = "eq", gain = 2.3, frequency = 2703, Q = 9.27},
    {name = "eq", gain = -3.1, frequency = 6859, Q = 9.19},
    {name = "eq", gain = 2.5, frequency = 13809, Q = 1.56},
    {name = "eq", gain = -9.3, frequency = 19751, Q = 0.65},
}
