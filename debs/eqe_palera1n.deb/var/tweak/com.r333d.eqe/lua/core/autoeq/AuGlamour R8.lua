return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = -7.1, frequency = 60, Q = 0.13},
    {name = "eq", gain = 8.4, frequency = 922, Q = 0.58},
    {name = "eq", gain = -11.5, frequency = 2736, Q = 0.51},
    {name = "eq", gain = 12.4, frequency = 3071, Q = 2.59},
    {name = "eq", gain = 10.6, frequency = 7112, Q = 1.06},
    {name = "eq", gain = 1.0, frequency = 1551, Q = 2.60},
    {name = "eq", gain = -2.0, frequency = 2196, Q = 1.85},
    {name = "eq", gain = 1.8, frequency = 2504, Q = 4.04},
    {name = "eq", gain = 1.5, frequency = 4332, Q = 1.54},
    {name = "eq", gain = -3.1, frequency = 4373, Q = 4.84},
}
