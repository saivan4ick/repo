return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -1.9, frequency = 181, Q = 1.31},
    {name = "eq", gain = 6.3, frequency = 4448, Q = 3.71},
    {name = "eq", gain = 7.9, frequency = 8042, Q = 0.65},
    {name = "eq", gain = -5.7, frequency = 16894, Q = 0.07},
    {name = "eq", gain = -8.4, frequency = 19653, Q = 0.49},
    {name = "eq", gain = -1.1, frequency = 17, Q = 1.07},
    {name = "eq", gain = -1.1, frequency = 44, Q = 2.32},
    {name = "eq", gain = 1.9, frequency = 2142, Q = 3.32},
    {name = "eq", gain = -2.8, frequency = 3219, Q = 2.52},
    {name = "eq", gain = 2.2, frequency = 3821, Q = 3.78},
}
