return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -3.1, frequency = 175, Q = 0.46},
    {name = "eq", gain = -2.6, frequency = 534, Q = 1.33},
    {name = "eq", gain = 4.6, frequency = 3006, Q = 2.21},
    {name = "eq", gain = 2.1, frequency = 4345, Q = 1.82},
    {name = "eq", gain = 2.9, frequency = 4430, Q = 1.63},
    {name = "eq", gain = 1.1, frequency = 17, Q = 1.52},
    {name = "eq", gain = 1.1, frequency = 1091, Q = 5.09},
    {name = "eq", gain = 2.6, frequency = 8237, Q = 1.75},
    {name = "eq", gain = 3.9, frequency = 10910, Q = 1.16},
    {name = "eq", gain = -17.5, frequency = 19664, Q = 0.32},
}
