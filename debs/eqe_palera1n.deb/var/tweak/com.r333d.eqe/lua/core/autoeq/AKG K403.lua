return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 6.6, frequency = 36, Q = 0.44},
    {name = "eq", gain = 3.0, frequency = 789, Q = 0.75},
    {name = "eq", gain = -12.9, frequency = 3047, Q = 2.40},
    {name = "eq", gain = 2.2, frequency = 8405, Q = 2.54},
    {name = "eq", gain = -4.0, frequency = 19598, Q = 0.48},
    {name = "eq", gain = 1.5, frequency = 74, Q = 3.36},
    {name = "eq", gain = -1.2, frequency = 172, Q = 1.70},
    {name = "eq", gain = 3.0, frequency = 4970, Q = 5.33},
    {name = "eq", gain = -3.5, frequency = 5852, Q = 3.59},
    {name = "eq", gain = 1.7, frequency = 7215, Q = 5.05},
}
