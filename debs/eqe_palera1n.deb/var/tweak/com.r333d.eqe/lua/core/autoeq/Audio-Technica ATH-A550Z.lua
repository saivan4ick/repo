return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 5.4, frequency = 21, Q = 1.10},
    {name = "eq", gain = -11.2, frequency = 2223, Q = 0.64},
    {name = "eq", gain = 10.2, frequency = 3220, Q = 1.28},
    {name = "eq", gain = 6.4, frequency = 5537, Q = 0.29},
    {name = "eq", gain = -16.3, frequency = 19341, Q = 0.29},
    {name = "eq", gain = -3.2, frequency = 154, Q = 1.22},
    {name = "eq", gain = 3.5, frequency = 287, Q = 3.12},
    {name = "eq", gain = -1.4, frequency = 511, Q = 2.49},
    {name = "eq", gain = -0.7, frequency = 13597, Q = 1.62},
    {name = "eq", gain = -1.1, frequency = 20098, Q = 2.18},
}
