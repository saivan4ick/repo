return {
    {name = "preamp", gain = -2.7},
    {name = "eq", gain = -6.2, frequency = 21, Q = 0.46},
    {name = "eq", gain = -5.8, frequency = 67, Q = 1.16},
    {name = "eq", gain = 4.8, frequency = 154, Q = 0.85},
    {name = "eq", gain = -1.8, frequency = 6303, Q = 0.03},
    {name = "eq", gain = 4.3, frequency = 6555, Q = 1.08},
    {name = "eq", gain = 0.2, frequency = 42, Q = 0.95},
    {name = "eq", gain = 0.8, frequency = 110, Q = 5.45},
    {name = "eq", gain = 1.7, frequency = 1779, Q = 2.47},
    {name = "eq", gain = -3.2, frequency = 2338, Q = 3.27},
    {name = "eq", gain = 1.0, frequency = 2884, Q = 3.00},
}
