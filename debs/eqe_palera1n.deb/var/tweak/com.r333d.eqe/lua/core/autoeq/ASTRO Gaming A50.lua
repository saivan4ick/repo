return {
    {name = "preamp", gain = -5.1},
    {name = "eq", gain = 4.4, frequency = 22, Q = 1.65},
    {name = "eq", gain = 4.3, frequency = 625, Q = 4.43},
    {name = "eq", gain = 3.0, frequency = 2181, Q = 3.17},
    {name = "eq", gain = 7.1, frequency = 4292, Q = 1.90},
    {name = "eq", gain = -6.9, frequency = 5839, Q = 1.60},
    {name = "eq", gain = -3.0, frequency = 168, Q = 0.79},
    {name = "eq", gain = 1.8, frequency = 922, Q = 0.66},
    {name = "eq", gain = -4.7, frequency = 1115, Q = 2.41},
    {name = "eq", gain = 0.6, frequency = 10597, Q = 1.09},
    {name = "eq", gain = -4.0, frequency = 19720, Q = 0.39},
}
