return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -2.6, frequency = 76, Q = 0.29},
    {name = "eq", gain = -3.0, frequency = 250, Q = 0.63},
    {name = "eq", gain = 4.4, frequency = 2450, Q = 1.00},
    {name = "eq", gain = 4.8, frequency = 3844, Q = 2.42},
    {name = "eq", gain = -15.1, frequency = 19397, Q = 0.38},
    {name = "eq", gain = 2.0, frequency = 2984, Q = 4.37},
    {name = "eq", gain = -1.3, frequency = 3673, Q = 1.34},
    {name = "eq", gain = 2.3, frequency = 4419, Q = 5.06},
    {name = "eq", gain = -2.1, frequency = 7195, Q = 2.64},
    {name = "eq", gain = 2.0, frequency = 10497, Q = 2.04},
}
