return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = 7.1, frequency = 31, Q = 1.01},
    {name = "eq", gain = -7.5, frequency = 674, Q = 2.88},
    {name = "eq", gain = -7.8, frequency = 1402, Q = 0.99},
    {name = "eq", gain = 5.9, frequency = 3027, Q = 1.21},
    {name = "eq", gain = 5.9, frequency = 10438, Q = 0.32},
    {name = "eq", gain = 5.0, frequency = 57, Q = 2.30},
    {name = "eq", gain = -6.8, frequency = 153, Q = 0.71},
    {name = "eq", gain = 9.4, frequency = 338, Q = 2.22},
    {name = "eq", gain = -2.2, frequency = 536, Q = 4.16},
    {name = "eq", gain = 0.5, frequency = 5035, Q = 4.15},
}
