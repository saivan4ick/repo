return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = -2.6, frequency = 117, Q = 0.12},
    {name = "eq", gain = 3.6, frequency = 3011, Q = 4.68},
    {name = "eq", gain = 3.9, frequency = 3550, Q = 3.58},
    {name = "eq", gain = 9.4, frequency = 9752, Q = 0.89},
    {name = "eq", gain = -19.3, frequency = 19662, Q = 0.38},
    {name = "eq", gain = 1.7, frequency = 976, Q = 2.34},
    {name = "eq", gain = -0.7, frequency = 1362, Q = 0.89},
    {name = "eq", gain = -2.5, frequency = 2236, Q = 2.80},
    {name = "eq", gain = 2.2, frequency = 2574, Q = 3.40},
    {name = "eq", gain = -0.7, frequency = 20456, Q = 0.14},
}
