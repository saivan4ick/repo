return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -8.9, frequency = 36, Q = 0.09},
    {name = "eq", gain = 5.2, frequency = 1182, Q = 0.29},
    {name = "eq", gain = 6.5, frequency = 4349, Q = 1.42},
    {name = "eq", gain = -10.0, frequency = 5963, Q = 1.56},
    {name = "eq", gain = 6.6, frequency = 17863, Q = 0.36},
    {name = "eq", gain = -1.0, frequency = 1356, Q = 4.45},
    {name = "eq", gain = -1.1, frequency = 10302, Q = 2.94},
    {name = "eq", gain = -0.7, frequency = 12188, Q = 2.04},
    {name = "eq", gain = 1.5, frequency = 14227, Q = 0.80},
    {name = "eq", gain = -1.3, frequency = 17159, Q = 1.43},
}
