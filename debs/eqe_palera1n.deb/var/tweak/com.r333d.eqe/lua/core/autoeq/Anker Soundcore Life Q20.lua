return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -8.8, frequency = 17, Q = 0.33},
    {name = "eq", gain = -8.4, frequency = 79, Q = 1.05},
    {name = "eq", gain = 3.5, frequency = 1748, Q = 3.45},
    {name = "eq", gain = 5.8, frequency = 4838, Q = 3.39},
    {name = "eq", gain = 6.9, frequency = 18135, Q = 0.57},
    {name = "eq", gain = 2.7, frequency = 418, Q = 1.46},
    {name = "eq", gain = -2.2, frequency = 2872, Q = 4.02},
    {name = "eq", gain = -2.2, frequency = 7119, Q = 5.06},
    {name = "eq", gain = 1.8, frequency = 8514, Q = 0.67},
    {name = "eq", gain = -2.9, frequency = 9203, Q = 1.91},
}
