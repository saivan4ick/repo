return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 41, Q = 0.28},
    {name = "eq", gain = 1.8, frequency = 728, Q = 1.13},
    {name = "eq", gain = -10.3, frequency = 2717, Q = 1.46},
    {name = "eq", gain = 6.3, frequency = 4843, Q = 2.75},
    {name = "eq", gain = -9.7, frequency = 19241, Q = 0.38},
    {name = "eq", gain = 1.2, frequency = 100, Q = 3.31},
    {name = "eq", gain = -1.0, frequency = 211, Q = 2.77},
    {name = "eq", gain = -1.0, frequency = 5980, Q = 5.52},
    {name = "eq", gain = 0.6, frequency = 7963, Q = 1.14},
}
