return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -4.7, frequency = 194, Q = 0.51},
    {name = "eq", gain = -7.4, frequency = 1749, Q = 2.00},
    {name = "eq", gain = 5.2, frequency = 2384, Q = 2.39},
    {name = "eq", gain = 4.7, frequency = 6666, Q = 0.22},
    {name = "eq", gain = 4.9, frequency = 20002, Q = 0.22},
    {name = "eq", gain = 0.9, frequency = 23, Q = 1.23},
    {name = "eq", gain = -2.2, frequency = 3901, Q = 5.53},
    {name = "eq", gain = 2.2, frequency = 5035, Q = 1.69},
    {name = "eq", gain = -3.4, frequency = 6597, Q = 3.26},
    {name = "eq", gain = 1.0, frequency = 8236, Q = 2.91},
}
