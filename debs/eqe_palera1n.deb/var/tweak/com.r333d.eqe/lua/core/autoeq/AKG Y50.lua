return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 7.7, frequency = 184, Q = 2.04},
    {name = "eq", gain = -3.2, frequency = 336, Q = 1.26},
    {name = "eq", gain = -5.3, frequency = 1106, Q = 0.77},
    {name = "eq", gain = 5.1, frequency = 3722, Q = 0.98},
    {name = "eq", gain = 3.1, frequency = 10667, Q = 2.25},
    {name = "eq", gain = 2.0, frequency = 16, Q = 1.19},
    {name = "eq", gain = -2.1, frequency = 41, Q = 0.92},
    {name = "eq", gain = 1.2, frequency = 146, Q = 5.46},
    {name = "eq", gain = 1.4, frequency = 4989, Q = 6.09},
    {name = "eq", gain = -1.1, frequency = 6390, Q = 3.65},
}
