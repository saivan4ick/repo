return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = 2.9, frequency = 20, Q = 0.71},
    {name = "eq", gain = -3.3, frequency = 143, Q = 0.75},
    {name = "eq", gain = 6.9, frequency = 3741, Q = 2.01},
    {name = "eq", gain = -7.2, frequency = 5475, Q = 6.75},
    {name = "eq", gain = 2.3, frequency = 8668, Q = 2.58},
    {name = "eq", gain = 1.2, frequency = 419, Q = 3.35},
    {name = "eq", gain = -0.2, frequency = 1415, Q = 1.97},
    {name = "eq", gain = -1.1, frequency = 1912, Q = 0.82},
    {name = "eq", gain = 0.4, frequency = 2862, Q = 2.15},
    {name = "eq", gain = 1.0, frequency = 2882, Q = 2.43},
}
