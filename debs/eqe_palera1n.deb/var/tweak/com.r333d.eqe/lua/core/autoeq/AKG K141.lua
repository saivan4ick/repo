return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 6.5, frequency = 32, Q = 0.50},
    {name = "eq", gain = 4.8, frequency = 1109, Q = 0.47},
    {name = "eq", gain = -12.3, frequency = 3257, Q = 0.54},
    {name = "eq", gain = 9.4, frequency = 4405, Q = 1.36},
    {name = "eq", gain = 7.0, frequency = 17254, Q = 0.35},
    {name = "eq", gain = 1.1, frequency = 55, Q = 5.40},
    {name = "eq", gain = 1.0, frequency = 3865, Q = 7.24},
    {name = "eq", gain = 1.9, frequency = 5863, Q = 3.58},
    {name = "eq", gain = -1.0, frequency = 11551, Q = 0.32},
    {name = "eq", gain = 2.3, frequency = 13280, Q = 1.70},
}
