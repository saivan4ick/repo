return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = -3.4, frequency = 42, Q = 0.41},
    {name = "eq", gain = -3.2, frequency = 129, Q = 1.04},
    {name = "eq", gain = -2.4, frequency = 2335, Q = 3.12},
    {name = "eq", gain = 6.1, frequency = 3731, Q = 2.47},
    {name = "eq", gain = 3.6, frequency = 9027, Q = 2.34},
    {name = "eq", gain = 1.8, frequency = 465, Q = 1.84},
    {name = "eq", gain = 0.3, frequency = 3101, Q = 4.14},
    {name = "eq", gain = 1.3, frequency = 7112, Q = 4.65},
    {name = "eq", gain = 3.0, frequency = 12028, Q = 1.64},
    {name = "eq", gain = -11.0, frequency = 19957, Q = 0.36},
}
