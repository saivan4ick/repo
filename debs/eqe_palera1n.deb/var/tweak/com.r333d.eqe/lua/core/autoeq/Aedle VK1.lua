return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 9.4, frequency = 36, Q = 0.51},
    {name = "eq", gain = -9.2, frequency = 90, Q = 0.64},
    {name = "eq", gain = 6.3, frequency = 4144, Q = 2.82},
    {name = "eq", gain = 3.3, frequency = 10084, Q = 1.08},
    {name = "eq", gain = 5.6, frequency = 18108, Q = 0.35},
    {name = "eq", gain = 3.5, frequency = 878, Q = 1.24},
    {name = "eq", gain = -5.8, frequency = 1429, Q = 1.18},
    {name = "eq", gain = 3.2, frequency = 3394, Q = 3.27},
    {name = "eq", gain = -2.2, frequency = 4462, Q = 2.06},
    {name = "eq", gain = 3.6, frequency = 4849, Q = 6.05},
}
