return {
    {name = "preamp", gain = -5.3},
    {name = "eq", gain = 2.9, frequency = 13, Q = 0.35},
    {name = "eq", gain = -3.2, frequency = 201, Q = 0.78},
    {name = "eq", gain = 5.1, frequency = 2048, Q = 1.67},
    {name = "eq", gain = -8.9, frequency = 5785, Q = 5.75},
    {name = "eq", gain = 3.0, frequency = 9938, Q = 2.32},
    {name = "eq", gain = 0.8, frequency = 1062, Q = 2.53},
    {name = "eq", gain = -3.3, frequency = 3873, Q = 9.15},
    {name = "eq", gain = 1.9, frequency = 6891, Q = 5.91},
    {name = "eq", gain = 2.1, frequency = 12572, Q = 1.77},
    {name = "eq", gain = -9.4, frequency = 19790, Q = 0.48},
}
