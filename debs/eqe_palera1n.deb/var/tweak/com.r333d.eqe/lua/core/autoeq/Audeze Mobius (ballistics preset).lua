return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = -3.1, frequency = 75, Q = 0.79},
    {name = "eq", gain = -4.0, frequency = 214, Q = 1.28},
    {name = "eq", gain = 3.8, frequency = 4553, Q = 4.34},
    {name = "eq", gain = 6.5, frequency = 7182, Q = 1.34},
    {name = "eq", gain = -8.2, frequency = 19452, Q = 0.50},
    {name = "eq", gain = -0.9, frequency = 1252, Q = 2.83},
    {name = "eq", gain = -3.6, frequency = 3015, Q = 3.74},
    {name = "eq", gain = 1.0, frequency = 3257, Q = 1.25},
    {name = "eq", gain = 1.1, frequency = 10798, Q = 4.27},
}
