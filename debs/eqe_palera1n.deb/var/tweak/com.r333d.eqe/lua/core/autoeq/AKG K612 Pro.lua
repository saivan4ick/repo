return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 6.1, frequency = 24, Q = 0.80},
    {name = "eq", gain = 2.4, frequency = 84, Q = 5.65},
    {name = "eq", gain = 2.9, frequency = 776, Q = 2.65},
    {name = "eq", gain = 8.0, frequency = 11624, Q = 0.72},
    {name = "eq", gain = -4.8, frequency = 18839, Q = 0.08},
    {name = "eq", gain = -2.1, frequency = 214, Q = 1.47},
    {name = "eq", gain = 1.6, frequency = 1549, Q = 2.99},
    {name = "eq", gain = -2.6, frequency = 2614, Q = 1.53},
    {name = "eq", gain = 2.5, frequency = 4185, Q = 1.22},
    {name = "eq", gain = -3.6, frequency = 5928, Q = 4.13},
}
