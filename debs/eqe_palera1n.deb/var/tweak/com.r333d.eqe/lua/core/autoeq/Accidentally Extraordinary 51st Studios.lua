return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 4.8, frequency = 21, Q = 1.29},
    {name = "eq", gain = -4.3, frequency = 100, Q = 0.69},
    {name = "eq", gain = -4.3, frequency = 196, Q = 1.58},
    {name = "eq", gain = 4.6, frequency = 5375, Q = 0.74},
    {name = "eq", gain = 4.4, frequency = 19852, Q = 0.13},
    {name = "eq", gain = 2.6, frequency = 522, Q = 1.46},
    {name = "eq", gain = -3.9, frequency = 1239, Q = 0.78},
    {name = "eq", gain = 3.1, frequency = 3033, Q = 0.94},
    {name = "eq", gain = -3.4, frequency = 4594, Q = 3.55},
    {name = "eq", gain = 0.5, frequency = 6254, Q = 4.08},
}
