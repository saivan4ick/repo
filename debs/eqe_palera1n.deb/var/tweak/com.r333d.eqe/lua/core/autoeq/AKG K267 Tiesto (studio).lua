return {
    {name = "preamp", gain = -4.5},
    {name = "eq", gain = 4.6, frequency = 70, Q = 0.44},
    {name = "eq", gain = -5.0, frequency = 142, Q = 0.85},
    {name = "eq", gain = -3.5, frequency = 1217, Q = 1.45},
    {name = "eq", gain = 4.3, frequency = 3849, Q = 2.10},
    {name = "eq", gain = 1.6, frequency = 20867, Q = 0.05},
    {name = "eq", gain = 3.6, frequency = 342, Q = 2.83},
    {name = "eq", gain = -2.0, frequency = 382, Q = 1.07},
    {name = "eq", gain = 1.4, frequency = 2196, Q = 4.46},
    {name = "eq", gain = -3.6, frequency = 5379, Q = 7.16},
    {name = "eq", gain = 2.3, frequency = 6824, Q = 5.75},
}
