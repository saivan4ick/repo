return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -2.4, frequency = 94, Q = 0.56},
    {name = "eq", gain = -6.7, frequency = 330, Q = 0.39},
    {name = "eq", gain = -5.4, frequency = 1527, Q = 1.15},
    {name = "eq", gain = 4.5, frequency = 2296, Q = 1.15},
    {name = "eq", gain = 6.1, frequency = 14892, Q = 0.08},
    {name = "eq", gain = 0.7, frequency = 15, Q = 1.35},
    {name = "eq", gain = 0.4, frequency = 2653, Q = 3.78},
    {name = "eq", gain = -1.5, frequency = 3327, Q = 3.87},
    {name = "eq", gain = 0.9, frequency = 3797, Q = 1.95},
}
