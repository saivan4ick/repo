return {
    {name = "preamp", gain = -7.6},
    {name = "eq", gain = -3.7, frequency = 21, Q = 0.27},
    {name = "eq", gain = -5.6, frequency = 278, Q = 0.35},
    {name = "eq", gain = 6.3, frequency = 2651, Q = 1.26},
    {name = "eq", gain = 5.4, frequency = 6440, Q = 1.26},
    {name = "eq", gain = 5.1, frequency = 10408, Q = 2.46},
    {name = "eq", gain = -0.8, frequency = 1362, Q = 4.93},
    {name = "eq", gain = 2.1, frequency = 12709, Q = 2.63},
    {name = "eq", gain = 2.3, frequency = 13261, Q = 0.65},
    {name = "eq", gain = -7.0, frequency = 19539, Q = 0.41},
    {name = "eq", gain = -7.8, frequency = 20024, Q = 0.52},
}
