return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -5.0, frequency = 215, Q = 0.55},
    {name = "eq", gain = 4.1, frequency = 2927, Q = 2.43},
    {name = "eq", gain = 5.9, frequency = 5671, Q = 1.06},
    {name = "eq", gain = 3.9, frequency = 15889, Q = 1.30},
    {name = "eq", gain = 5.7, frequency = 19462, Q = 0.65},
    {name = "eq", gain = 2.3, frequency = 21, Q = 1.20},
    {name = "eq", gain = 1.9, frequency = 1355, Q = 0.84},
    {name = "eq", gain = -4.1, frequency = 1444, Q = 2.04},
    {name = "eq", gain = 1.3, frequency = 8620, Q = 4.58},
    {name = "eq", gain = -1.2, frequency = 9718, Q = 3.26},
}
