return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = -3.7, frequency = 104, Q = 0.92},
    {name = "eq", gain = -3.0, frequency = 219, Q = 1.63},
    {name = "eq", gain = 6.0, frequency = 6231, Q = 3.66},
    {name = "eq", gain = 5.5, frequency = 8229, Q = 2.48},
    {name = "eq", gain = -3.8, frequency = 17851, Q = 0.21},
    {name = "eq", gain = 1.4, frequency = 21, Q = 1.70},
    {name = "eq", gain = -1.0, frequency = 348, Q = 1.93},
    {name = "eq", gain = 2.3, frequency = 861, Q = 1.03},
    {name = "eq", gain = 1.8, frequency = 3882, Q = 2.29},
    {name = "eq", gain = -4.1, frequency = 4188, Q = 4.77},
}
