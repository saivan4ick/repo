return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = 5.1, frequency = 20, Q = 0.60},
    {name = "eq", gain = 3.7, frequency = 60, Q = 0.81},
    {name = "eq", gain = -7.5, frequency = 139, Q = 0.82},
    {name = "eq", gain = 6.7, frequency = 2385, Q = 3.81},
    {name = "eq", gain = 6.7, frequency = 16552, Q = 0.43},
    {name = "eq", gain = -2.1, frequency = 4188, Q = 1.80},
    {name = "eq", gain = -1.8, frequency = 5281, Q = 1.74},
    {name = "eq", gain = 1.1, frequency = 10759, Q = 1.93},
    {name = "eq", gain = 0.8, frequency = 14169, Q = 0.03},
    {name = "eq", gain = -1.8, frequency = 16558, Q = 1.24},
}
