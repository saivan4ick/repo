return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.5, frequency = 34, Q = 0.42},
    {name = "eq", gain = 3.7, frequency = 737, Q = 0.85},
    {name = "eq", gain = -3.1, frequency = 1110, Q = 0.69},
    {name = "eq", gain = -6.7, frequency = 6270, Q = 6.12},
    {name = "eq", gain = -6.4, frequency = 19331, Q = 0.71},
    {name = "eq", gain = 0.7, frequency = 64, Q = 3.48},
    {name = "eq", gain = 1.8, frequency = 2123, Q = 3.30},
    {name = "eq", gain = -2.0, frequency = 3661, Q = 0.95},
    {name = "eq", gain = 3.3, frequency = 4432, Q = 3.12},
    {name = "eq", gain = 1.4, frequency = 10865, Q = 2.90},
}
