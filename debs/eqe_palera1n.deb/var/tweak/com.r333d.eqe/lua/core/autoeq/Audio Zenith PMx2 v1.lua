return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.0, frequency = 23, Q = 0.49},
    {name = "eq", gain = -2.6, frequency = 197, Q = 1.00},
    {name = "eq", gain = -2.8, frequency = 1009, Q = 0.70},
    {name = "eq", gain = 4.4, frequency = 2454, Q = 1.04},
    {name = "eq", gain = 2.2, frequency = 13508, Q = 0.49},
    {name = "eq", gain = -0.4, frequency = 714, Q = 4.00},
    {name = "eq", gain = -0.7, frequency = 3097, Q = 3.51},
    {name = "eq", gain = 1.7, frequency = 4365, Q = 2.06},
    {name = "eq", gain = -3.1, frequency = 5637, Q = 3.10},
    {name = "eq", gain = 1.5, frequency = 7121, Q = 3.62},
}
