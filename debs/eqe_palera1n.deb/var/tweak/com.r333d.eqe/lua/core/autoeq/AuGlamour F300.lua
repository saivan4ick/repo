return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -2.2, frequency = 22, Q = 0.51},
    {name = "eq", gain = -3.4, frequency = 84, Q = 0.69},
    {name = "eq", gain = -3.5, frequency = 212, Q = 0.71},
    {name = "eq", gain = 1.0, frequency = 975, Q = 1.58},
    {name = "eq", gain = 6.9, frequency = 11813, Q = 0.46},
    {name = "eq", gain = -3.5, frequency = 3481, Q = 0.81},
    {name = "eq", gain = -3.8, frequency = 4403, Q = 3.06},
    {name = "eq", gain = 4.2, frequency = 5392, Q = 2.27},
    {name = "eq", gain = 2.3, frequency = 6794, Q = 0.22},
    {name = "eq", gain = -2.8, frequency = 11484, Q = 1.01},
}
