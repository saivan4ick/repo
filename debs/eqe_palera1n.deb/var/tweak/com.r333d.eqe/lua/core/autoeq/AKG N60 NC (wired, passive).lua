return {
    {name = "preamp", gain = -7.2},
    {name = "eq", gain = -2.5, frequency = 17, Q = 0.36},
    {name = "eq", gain = -1.9, frequency = 99, Q = 1.24},
    {name = "eq", gain = -3.1, frequency = 172, Q = 0.88},
    {name = "eq", gain = -2.8, frequency = 3066, Q = 1.85},
    {name = "eq", gain = 7.0, frequency = 9780, Q = 0.88},
    {name = "eq", gain = 2.1, frequency = 4683, Q = 3.27},
    {name = "eq", gain = -4.9, frequency = 5401, Q = 4.52},
    {name = "eq", gain = 3.0, frequency = 6757, Q = 5.01},
    {name = "eq", gain = 2.8, frequency = 13696, Q = 2.46},
    {name = "eq", gain = -7.6, frequency = 19856, Q = 0.66},
}
