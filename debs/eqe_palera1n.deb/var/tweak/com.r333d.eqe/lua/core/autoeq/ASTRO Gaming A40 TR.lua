return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 4.8, frequency = 10, Q = 0.22},
    {name = "eq", gain = -3.6, frequency = 180, Q = 0.53},
    {name = "eq", gain = -11.2, frequency = 6074, Q = 4.03},
    {name = "eq", gain = 5.1, frequency = 6177, Q = 0.72},
    {name = "eq", gain = 5.1, frequency = 12080, Q = 1.18},
    {name = "eq", gain = 1.4, frequency = 930, Q = 3.21},
    {name = "eq", gain = -2.0, frequency = 1563, Q = 1.51},
    {name = "eq", gain = 2.3, frequency = 2391, Q = 1.52},
    {name = "eq", gain = -2.2, frequency = 3353, Q = 2.69},
    {name = "eq", gain = 1.3, frequency = 4489, Q = 5.11},
}
