return {
    {name = "preamp", gain = -6.8},
    {name = "eq", gain = 4.3, frequency = 16, Q = 0.53},
    {name = "eq", gain = -4.0, frequency = 968, Q = 0.14},
    {name = "eq", gain = 5.3, frequency = 2472, Q = 2.44},
    {name = "eq", gain = 7.9, frequency = 4128, Q = 1.16},
    {name = "eq", gain = 6.4, frequency = 9403, Q = 1.07},
    {name = "eq", gain = 1.5, frequency = 605, Q = 1.18},
    {name = "eq", gain = -2.1, frequency = 1174, Q = 1.47},
    {name = "eq", gain = 1.6, frequency = 2034, Q = 4.54},
    {name = "eq", gain = -0.4, frequency = 2208, Q = 2.12},
    {name = "eq", gain = 0.4, frequency = 5342, Q = 3.24},
}
