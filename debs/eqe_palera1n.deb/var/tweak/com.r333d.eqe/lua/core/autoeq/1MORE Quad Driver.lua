return {
    {name = "preamp", gain = -7.3},
    {name = "eq", gain = 6.6, frequency = 19, Q = 0.54},
    {name = "eq", gain = -7.2, frequency = 211, Q = 0.34},
    {name = "eq", gain = 4.0, frequency = 982, Q = 0.49},
    {name = "eq", gain = 1.5, frequency = 3142, Q = 1.46},
    {name = "eq", gain = 6.5, frequency = 7749, Q = 1.66},
    {name = "eq", gain = 0.6, frequency = 2019, Q = 6.00},
    {name = "eq", gain = 4.1, frequency = 11068, Q = 1.35},
    {name = "eq", gain = 3.0, frequency = 11750, Q = 0.47},
    {name = "eq", gain = -8.6, frequency = 19237, Q = 0.18},
    {name = "eq", gain = -9.7, frequency = 19799, Q = 0.52},
}
