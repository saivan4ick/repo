return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = 6.4, frequency = 24, Q = 0.66},
    {name = "eq", gain = -6.4, frequency = 297, Q = 0.36},
    {name = "eq", gain = 3.4, frequency = 957, Q = 1.24},
    {name = "eq", gain = 4.3, frequency = 2063, Q = 1.07},
    {name = "eq", gain = 6.3, frequency = 5515, Q = 1.35},
    {name = "eq", gain = 2.2, frequency = 4336, Q = 5.30},
    {name = "eq", gain = -1.6, frequency = 4918, Q = 1.61},
    {name = "eq", gain = 1.3, frequency = 6807, Q = 1.34},
    {name = "eq", gain = 1.4, frequency = 9716, Q = 1.66},
    {name = "eq", gain = -7.1, frequency = 19891, Q = 0.30},
}
