return {
    {name = "preamp", gain = -6.1},
    {name = "eq", gain = 4.9, frequency = 27, Q = 0.74},
    {name = "eq", gain = 7.3, frequency = 1709, Q = 1.04},
    {name = "eq", gain = 7.4, frequency = 6175, Q = 0.99},
    {name = "eq", gain = 6.3, frequency = 9337, Q = 1.32},
    {name = "eq", gain = -5.5, frequency = 16808, Q = 0.01},
    {name = "eq", gain = -1.9, frequency = 209, Q = 1.16},
    {name = "eq", gain = -1.8, frequency = 1163, Q = 3.61},
    {name = "eq", gain = 3.0, frequency = 2178, Q = 4.20},
    {name = "eq", gain = -2.9, frequency = 2930, Q = 2.86},
    {name = "eq", gain = 1.3, frequency = 6164, Q = 2.75},
}
