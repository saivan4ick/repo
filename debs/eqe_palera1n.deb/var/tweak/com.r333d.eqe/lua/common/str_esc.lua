local conv = {}

local function serialize(v, indent)
    return conv[type(v)](v, indent)
end

conv.string = function(s)
    return '[['..string.gsub(s, '%]', "]]..']'..[[")..']]'
end
conv.boolean = tostring
conv['nil'] = tostring
conv.number = tostring

conv.table = function(t)
    local s = {}
    table.insert(s, '{')
    for k,v in pairs(t) do
        table.insert(s, '[ '..serialize(k)..' ] = '..serialize(v)..',')
    end
    table.insert(s, '}')

    return table.concat(s)
end

return serialize
