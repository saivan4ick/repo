return {
    {name = "preamp", gain = -4.6},
    {name = "eq", gain = 3.2, frequency = 28, Q = 0.64},
    {name = "eq", gain = -4.1, frequency = 3601, Q = 0.65},
    {name = "eq", gain = 3.5, frequency = 4522, Q = 3.41},
    {name = "eq", gain = 6.7, frequency = 6658, Q = 1.08},
    {name = "eq", gain = -10.8, frequency = 19655, Q = 0.35},
    {name = "eq", gain = -0.9, frequency = 212, Q = 1.25},
    {name = "eq", gain = 0.7, frequency = 700, Q = 3.87},
    {name = "eq", gain = 0.9, frequency = 6965, Q = 5.98},
    {name = "eq", gain = -1.0, frequency = 7620, Q = 4.16},
    {name = "eq", gain = -0.7, frequency = 15639, Q = 1.79},
}
