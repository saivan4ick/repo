return {
    {name = "preamp", gain = -2.6},
    {name = "eq", gain = -2.6, frequency = 17, Q = 0.15},
    {name = "eq", gain = 1.5, frequency = 3402, Q = 4.58},
    {name = "eq", gain = 2.4, frequency = 8731, Q = 1.44},
    {name = "eq", gain = 2.0, frequency = 11311, Q = 1.52},
    {name = "eq", gain = -10.4, frequency = 19688, Q = 0.42},
    {name = "eq", gain = -0.8, frequency = 321, Q = 1.86},
    {name = "eq", gain = 1.4, frequency = 933, Q = 2.81},
    {name = "eq", gain = -2.6, frequency = 4918, Q = 4.95},
    {name = "eq", gain = 2.5, frequency = 6251, Q = 2.81},
    {name = "eq", gain = -1.9, frequency = 7083, Q = 4.54},
}
