return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -4.7, frequency = 23, Q = 0.16},
    {name = "eq", gain = -6.9, frequency = 218, Q = 0.36},
    {name = "eq", gain = 7.1, frequency = 1202, Q = 0.56},
    {name = "eq", gain = 4.5, frequency = 4064, Q = 2.66},
    {name = "eq", gain = 6.5, frequency = 10947, Q = 1.50},
    {name = "eq", gain = -1.0, frequency = 1832, Q = 4.45},
    {name = "eq", gain = 0.9, frequency = 2400, Q = 3.27},
    {name = "eq", gain = 2.3, frequency = 5088, Q = 5.01},
    {name = "eq", gain = -4.2, frequency = 5829, Q = 3.94},
    {name = "eq", gain = 1.1, frequency = 7147, Q = 2.11},
}
