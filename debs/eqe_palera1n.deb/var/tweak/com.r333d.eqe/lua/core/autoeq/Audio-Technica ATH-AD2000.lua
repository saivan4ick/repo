return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = 6.3, frequency = 35, Q = 0.24},
    {name = "eq", gain = -2.7, frequency = 193, Q = 0.63},
    {name = "eq", gain = -1.3, frequency = 1388, Q = 1.68},
    {name = "eq", gain = -6.7, frequency = 3808, Q = 3.78},
    {name = "eq", gain = 5.5, frequency = 7522, Q = 1.84},
    {name = "eq", gain = 0.3, frequency = 692, Q = 3.88},
    {name = "eq", gain = 0.5, frequency = 5530, Q = 2.18},
    {name = "eq", gain = 1.4, frequency = 9691, Q = 3.32},
    {name = "eq", gain = 2.5, frequency = 11975, Q = 1.35},
    {name = "eq", gain = -11.6, frequency = 19733, Q = 0.40},
}
