return {
    {name = "preamp", gain = -7.1},
    {name = "eq", gain = -7.3, frequency = 51, Q = 0.22},
    {name = "eq", gain = 1.4, frequency = 581, Q = 0.30},
    {name = "eq", gain = 5.8, frequency = 3960, Q = 2.67},
    {name = "eq", gain = 4.9, frequency = 5177, Q = 4.90},
    {name = "eq", gain = -3.1, frequency = 19424, Q = 0.24},
    {name = "eq", gain = 1.5, frequency = 242, Q = 4.71},
    {name = "eq", gain = 2.4, frequency = 5922, Q = 5.27},
    {name = "eq", gain = -5.2, frequency = 6578, Q = 5.52},
    {name = "eq", gain = 1.2, frequency = 8136, Q = 2.19},
}
