return {
    {name = "preamp", gain = -6.7},
    {name = "eq", gain = -4.4, frequency = 63, Q = 0.39},
    {name = "eq", gain = -3.6, frequency = 184, Q = 0.72},
    {name = "eq", gain = 6.9, frequency = 3121, Q = 1.55},
    {name = "eq", gain = 4.8, frequency = 9533, Q = 2.06},
    {name = "eq", gain = 5.5, frequency = 13045, Q = 1.71},
    {name = "eq", gain = -3.0, frequency = 1551, Q = 3.04},
    {name = "eq", gain = 2.7, frequency = 2333, Q = 3.56},
    {name = "eq", gain = -1.9, frequency = 3132, Q = 3.05},
    {name = "eq", gain = 2.5, frequency = 4107, Q = 3.15},
    {name = "eq", gain = -2.0, frequency = 4860, Q = 4.74},
}
