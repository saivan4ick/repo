return {
    {name = "preamp", gain = -6.5},
    {name = "eq", gain = 6.2, frequency = 24, Q = 0.59},
    {name = "eq", gain = -4.8, frequency = 301, Q = 0.48},
    {name = "eq", gain = 3.8, frequency = 1038, Q = 1.42},
    {name = "eq", gain = 5.4, frequency = 2752, Q = 1.59},
    {name = "eq", gain = 6.9, frequency = 17014, Q = 0.41},
    {name = "eq", gain = -0.7, frequency = 1626, Q = 5.75},
    {name = "eq", gain = 3.9, frequency = 4382, Q = 2.89},
    {name = "eq", gain = -4.5, frequency = 5633, Q = 1.90},
    {name = "eq", gain = 2.1, frequency = 11177, Q = 1.85},
    {name = "eq", gain = -1.2, frequency = 16691, Q = 2.05},
}
