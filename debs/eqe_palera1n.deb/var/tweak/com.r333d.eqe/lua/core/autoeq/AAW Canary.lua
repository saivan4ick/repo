return {
    {name = "preamp", gain = -6.3},
    {name = "eq", gain = -2.3, frequency = 75, Q = 0.49},
    {name = "eq", gain = -4.0, frequency = 216, Q = 0.48},
    {name = "eq", gain = -4.6, frequency = 1482, Q = 1.72},
    {name = "eq", gain = 5.8, frequency = 3424, Q = 0.83},
    {name = "eq", gain = 3.6, frequency = 7216, Q = 1.34},
    {name = "eq", gain = -0.7, frequency = 5475, Q = 4.11},
    {name = "eq", gain = 0.4, frequency = 5978, Q = 0.66},
    {name = "eq", gain = 1.6, frequency = 11576, Q = 1.52},
    {name = "eq", gain = 1.2, frequency = 15588, Q = 1.00},
    {name = "eq", gain = -3.8, frequency = 19420, Q = 0.25},
}
