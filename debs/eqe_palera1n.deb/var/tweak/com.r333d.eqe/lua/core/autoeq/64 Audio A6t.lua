return {
    {name = "preamp", gain = -6.4},
    {name = "eq", gain = -5.1, frequency = 52, Q = 0.20},
    {name = "eq", gain = -1.6, frequency = 340, Q = 0.89},
    {name = "eq", gain = 4.9, frequency = 3487, Q = 1.14},
    {name = "eq", gain = 3.7, frequency = 5978, Q = 3.30},
    {name = "eq", gain = 5.4, frequency = 9157, Q = 2.60},
    {name = "eq", gain = 1.1, frequency = 1007, Q = 3.39},
    {name = "eq", gain = 1.1, frequency = 11511, Q = 1.11},
    {name = "eq", gain = 2.0, frequency = 11872, Q = 1.54},
    {name = "eq", gain = -6.4, frequency = 19355, Q = 0.35},
    {name = "eq", gain = -6.6, frequency = 19595, Q = 0.61},
}
