return {
    {name = "preamp", gain = -6.6},
    {name = "eq", gain = 6.4, frequency = 40, Q = 0.28},
    {name = "eq", gain = 2.5, frequency = 723, Q = 1.20},
    {name = "eq", gain = -12.4, frequency = 3011, Q = 2.08},
    {name = "eq", gain = -5.8, frequency = 5991, Q = 3.74},
    {name = "eq", gain = 3.5, frequency = 8926, Q = 3.13},
    {name = "eq", gain = 1.1, frequency = 95, Q = 4.65},
    {name = "eq", gain = -0.2, frequency = 2034, Q = 3.10},
    {name = "eq", gain = -1.0, frequency = 3494, Q = 6.00},
    {name = "eq", gain = 2.3, frequency = 4528, Q = 5.91},
    {name = "eq", gain = -12.1, frequency = 19438, Q = 0.72},
}
