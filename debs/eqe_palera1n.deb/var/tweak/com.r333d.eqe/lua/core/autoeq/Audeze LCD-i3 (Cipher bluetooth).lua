return {
    {name = "preamp", gain = -6.0},
    {name = "eq", gain = -3.8, frequency = 263, Q = 0.65},
    {name = "eq", gain = -5.7, frequency = 850, Q = 1.33},
    {name = "eq", gain = -4.7, frequency = 1511, Q = 2.68},
    {name = "eq", gain = 3.9, frequency = 4215, Q = 0.54},
    {name = "eq", gain = 3.0, frequency = 6976, Q = 0.57},
    {name = "eq", gain = -3.3, frequency = 2922, Q = 5.01},
    {name = "eq", gain = 1.3, frequency = 2939, Q = 2.04},
    {name = "eq", gain = -2.0, frequency = 6170, Q = 2.81},
    {name = "eq", gain = -3.0, frequency = 11743, Q = 1.72},
    {name = "eq", gain = 1.7, frequency = 19522, Q = 0.13},
}
