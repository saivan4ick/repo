return {
    {name = "preamp", gain = -6.9},
    {name = "eq", gain = 7.2, frequency = 33, Q = 0.63},
    {name = "eq", gain = -10.0, frequency = 129, Q = 1.29},
    {name = "eq", gain = -7.2, frequency = 1068, Q = 0.94},
    {name = "eq", gain = 5.9, frequency = 3153, Q = 1.29},
    {name = "eq", gain = 6.0, frequency = 12913, Q = 0.28},
    {name = "eq", gain = 3.9, frequency = 134, Q = 2.91},
    {name = "eq", gain = -4.6, frequency = 188, Q = 0.96},
    {name = "eq", gain = 9.8, frequency = 349, Q = 2.05},
    {name = "eq", gain = -5.1, frequency = 626, Q = 3.16},
}
