return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 6.3, frequency = 27, Q = 0.27},
    {name = "eq", gain = -2.8, frequency = 147, Q = 0.50},
    {name = "eq", gain = 2.0, frequency = 722, Q = 1.12},
    {name = "eq", gain = -4.6, frequency = 2250, Q = 3.26},
    {name = "eq", gain = 4.0, frequency = 10168, Q = 2.23},
    {name = "eq", gain = -0.4, frequency = 1064, Q = 5.29},
    {name = "eq", gain = -0.8, frequency = 2752, Q = 4.93},
    {name = "eq", gain = 1.3, frequency = 4014, Q = 2.49},
    {name = "eq", gain = 2.4, frequency = 13055, Q = 1.51},
    {name = "eq", gain = -8.4, frequency = 19758, Q = 0.44},
}
