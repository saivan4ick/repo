return {
    {name = "preamp", gain = -7.0},
    {name = "eq", gain = -3.7, frequency = 70, Q = 0.71},
    {name = "eq", gain = -7.9, frequency = 199, Q = 0.40},
    {name = "eq", gain = 5.5, frequency = 992, Q = 1.10},
    {name = "eq", gain = 4.1, frequency = 3466, Q = 3.67},
    {name = "eq", gain = 6.5, frequency = 15702, Q = 0.18},
    {name = "eq", gain = 1.1, frequency = 16, Q = 2.00},
    {name = "eq", gain = -1.1, frequency = 2384, Q = 5.16},
    {name = "eq", gain = 1.6, frequency = 4167, Q = 2.71},
    {name = "eq", gain = -5.5, frequency = 5062, Q = 3.47},
    {name = "eq", gain = 3.1, frequency = 6102, Q = 2.25},
}
