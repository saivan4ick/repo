return {
    {name = "preamp", gain = -6.2},
    {name = "eq", gain = 5.6, frequency = 22, Q = 1.06},
    {name = "eq", gain = 2.6, frequency = 45, Q = 1.46},
    {name = "eq", gain = 2.9, frequency = 1852, Q = 0.77},
    {name = "eq", gain = -6.7, frequency = 19363, Q = 0.18},
    {name = "eq", gain = -6.9, frequency = 19524, Q = 0.62},
    {name = "eq", gain = -2.2, frequency = 267, Q = 1.07},
    {name = "eq", gain = 1.5, frequency = 877, Q = 2.78},
    {name = "eq", gain = 1.1, frequency = 5458, Q = 4.27},
    {name = "eq", gain = -2.2, frequency = 6143, Q = 3.11},
    {name = "eq", gain = 1.3, frequency = 10474, Q = 2.75},
}
